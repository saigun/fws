#pragma once

void FindFile(std::string path);
void FindLinkattrFile(std::string path);
void FindLinkFile(std::string path);
void FindNodeFile(std::string path);
void FindWaterFile(std::string path);

