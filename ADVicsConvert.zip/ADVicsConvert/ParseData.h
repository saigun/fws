#pragma once

#include <stdio.h>
#include <string>
#include <vector>
#include <exception>
#include <sstream>

#include "define.h"
#include "DBSetting.h"

using namespace std;

class ParseData
{

public:

	ParseData(void);
	~ParseData(void);

public:
	bool connect();
	bool disconnect();

	// EBCDIC -> CHARコード変換
	static char ebcdic2char(const char ch);

	//基本道路ノードデータ読込
	bool readdata_21(std::string path,int mesh_no);
	//基本道路リンクデータ読込
	bool readdata_22(std::string path,int mesh_no);
	//基本道路リンク内属性データ読込
	bool readdata_23(std::string path,int mesh_no);
	//水系データ読込
	bool readdata_41(std::string path,int mesh_no);


	//ADVICSデータ読込
	bool readdata_81(std::string path,int mesh_no);

	int	collect(char *buf);		//キャラクターコード変更
	int	collect_21(char *buf);	//キャラクターコード変更（基本ノード用）
	int	collect_23(char *buf);	//キャラクターコード変更（基本リンク内属性用）

	bool saveadvicsfiledata();

	bool createtmpTable();
	bool createtmpTable(string tableName, string createtableSql);//add by cuijun
	bool droptmpTable();
	bool insertadvicsdata();	//ADVICS DB登録
	bool insertbasicnodedata(); //基本ノード DB登録
	bool insertbasiclinkdata(); //基本リンク DB登録
	bool insertlinkattrdata();  //基本リンク内属性 DB登録

	bool createTmpView(string viewName, string createViewSql);//add by cuijun


	bool insertwaterdata();  //基本リンク内属性 DB登録

	bool insertmakedata_adf();  //リンクデータ生成
	bool execmakedata_adf();  //リンクデータ調整

	bool executSql(string sql);//add by cuijun
	bool cleartable(string tableName);//add by cuijun
	bool isTableExist(string tableName);//add by cuijun

	std::vector<linkdata>	ldata;
	std::vector<vicslinedata>	vicsdata;
	std::vector<posdata>	nodedata;
	std::vector<link_attr>	lattr;

	std::vector<suidata>	sdata;

	char*	fdata;		// 取得する一時バッファ
	static const unsigned int	READ_BUFFER_SIZE = 204800;	// 200k
	int loop_flg;
	int con_link_num;
	int write_flg;

private:

	

};
