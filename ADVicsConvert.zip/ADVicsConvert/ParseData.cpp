#include "StdAfx.h"
#include "ParseData.h"
#include <iostream>
#include <fstream>
#include "shlwapi.h"
#include "math.h"
#include <algorithm>
#include "common.h"

#pragma warning (disable : 4996)
#pragma warning (disable : 4101)


#define ADVICS_FILE "d:\\crossdata\\advics.csv"  //CSV出力 借り設定
#define WATER_FILE "d:\\crossdata\\water.csv"  //CSV出力 借り設定

DBSetting mdb;

/**
 * コンストラクタ
 *
 */
ParseData::ParseData(void)
{
	write_flg=0;
	// 取得バッファを確保
	fdata = new char[READ_BUFFER_SIZE];
	if(fdata == NULL)
	{
		return;
	}

}

/**
 * デストラクタ
 *
 */
ParseData::~ParseData(void)
{
	//バッファ削除
	if(fdata != NULL)
	{
		delete fdata;
		fdata=NULL;
	}
	//DB切断
	mdb.disconnect();
}


bool ParseData::connect()
{
	if( 0 !=mdb.Connection() )
	{
		return false;
	}
	return true;
}

bool ParseData::disconnect()
{
	//DB切断
	mdb.disconnect();
	return true;
}


/**
 * EBCDIC -> キャラクタコード変換
 *
 * @param [in]	ch	EBCDIC文字
 *
 * @return ASCII文字
 */
char ParseData::ebcdic2char(const char ch)
{
	static int tbl[256] = 
	{
		/* 0    1    2    3    4    5    6    7    8    9    A    B    C    D    E    F*/
		0x00,0x01,0x02,0x03,0x00,0x09,0x00,0x7F,0x00,0x00,0x00,0x0B,0x0C,0x0D,0x0E,0x0F,	// 0
		0x10,0x11,0x12,0x13,0x00,0x00,0x08,0x00,0x18,0x19,0x00,0x00,0x1C,0x1D,0x1E,0x1F,	// 1
		0x00,0x00,0x1C,0x00,0x00,0x0A,0x17,0x1B,0x00,0x00,0x00,0x00,0x00,0x05,0x06,0x07,	// 2
		0x00,0x00,0x16,0x00,0x00,0x00,0x00,0x04,0x00,0x00,0x00,0x00,0x14,0x15,0x00,0x1A,	// 3
		0x20,0xA1,0xA2,0xA3,0xA4,0xA5,0xA6,0xA7,0xA8,0xA9,0x00,0x2E,0x3C,0x28,0x2B,0x7C,	// 4
		0x26,0xAA,0xAB,0xAC,0xAD,0xAE,0xAF,0x00,0x2D,0x00,0x21,0x24,0x2A,0x29,0x3B,0x5E,	// 5
		0x2D,0x2F,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x2C,0x25,0x5F,0x3E,0x3F,	// 6
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x60,0x3A,0x23,0x40,0x27,0x3D,0x22,	// 7
		0x00,0xB1,0xB2,0xB3,0xB4,0xB5,0xB6,0xB7,0xB8,0xB9,0xBA,0x00,0xBB,0xBC,0xBD,0xBE,	// 8
		0xBF,0xC0,0xC1,0xC2,0xC3,0xC4,0xC5,0xC6,0xC7,0xC8,0xC9,0x00,0x00,0xCA,0xCB,0xCC,	// 9
		0x00,0x7E,0xCD,0xCE,0xCF,0xD0,0xD1,0xD2,0xD3,0xD4,0xD5,0x00,0xD6,0xD7,0xD8,0xD9,	// A
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xDA,0xDB,0xDC,0xDD,0xDE,0xDF,	// B
		0x7B,0x41,0x42,0x43,0x44,0x45,0x46,0x47,0x48,0x49,0x00,0x00,0x00,0x00,0x00,0x00,	// C
		0x7D,0x4A,0x4B,0x4C,0x4D,0x4E,0x4F,0x50,0x51,0x52,0x00,0x00,0x00,0x00,0x00,0x00,	// D
		0x5C,0x00,0x53,0x54,0x55,0x56,0x57,0x58,0x59,0x5A,0x00,0x00,0x00,0x00,0x00,0x00,	// E
		0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x00,0x00,0x00,0x00,0x00,0x00		// F
	};

	return tbl[ (unsigned char)ch ];
}

/**
 * 一時テーブル作成処理
 * @retval true	  正常
 * @retval false  エラー
 */
bool ParseData::createtmpTable()
{
	//一時テーブル作成
	if( false ==mdb.createtable())
	{
		return false;
	}

	return true;
}

//add by cuijun on 2012/12/1
/**
 * 一時テーブル作成処理
 * param [in] tableName 
 * param [in] createtableSql 
 * @retval true	  正常
 * @retval false  エラー
 */
bool ParseData::createtmpTable(string tableName, string createtableSql)//add by cuijun
{
	return mdb.createtable(tableName, createtableSql);
}

bool ParseData::cleartable(string tableName)
{
	return mdb.cleartable(tableName);
}

bool ParseData::isTableExist(string tableName)
{
	return mdb.isTableExist(tableName);
}

bool ParseData::createTmpView(string viewName, string createViewSql)//add by cuijun
{
	return mdb.createTmpView(viewName, createViewSql);
}

/**
 * SQL文を実行する
 * param [in] tableName 
 * @retval true	  正常
 * @retval false  エラー
 */
bool ParseData::executSql(string sql)
{
	return mdb.executSql(sql);
}
//add by cuijun on 2012/12/1

/**
 * 一時テーブル削除処理
 *
 * @retval true	  正常
 * @retval false  エラー
 */
bool ParseData::droptmpTable()
{
	//一時テーブル作成
	if( false ==mdb.droptable())
	{
		return false;
	}


	return true;
}
/**
 * 基本道路ノードデータ読み込み処理
 *
 * @param [in]	path	ファイル名（フルパス）
 * @param [in]	mesh_no	2次メッシュ番号
 *
 * @retval true	  正常
 * @retval false  エラー
 */
bool ParseData::readdata_21(std::string path,int mesh_no)
{
using namespace std;

	char node_no[5];
	char posx[6];
	char posy[6];
	char node_type[2];

	char mesh2nd[7];
	char node2nd[5];

	char link_num[2];

	char con_node_no[8][5];
	char con_cress_code[8][9];
	char con_ang[8][4];

	char name_len[3];
	char kana_len[3];
	//管理データ読み込
	// ファイルを開く

	char file_name[256];
	memset(file_name,NULL,sizeof(file_name));
	sprintf_s(file_name,sizeof(file_name),"%s",path.c_str());


	nodedata.clear();
	if(fdata!=NULL)
	{
		delete fdata;	
		fdata=NULL;
		fdata = new char[READ_BUFFER_SIZE];
	}

	std::ifstream fs(file_name, std::ios::binary | std::ios::in);
	if( fs.fail() )	return false;

	// ファイルデータがなくなるまで取得する
	std::streamsize data_size = 0;
	std::streamsize now_pos = 0;
	int record_size = 1;	// 初回だけ読み取らせるため設定
	std::fill(fdata, fdata+READ_BUFFER_SIZE, 0);

	while( true )
	{
		if( static_cast<std::streamsize>(now_pos + record_size) > data_size )
		{

			// 使用していないデータを前に移動させる
			if( (data_size - now_pos) < static_cast<int>(record_size) && data_size > 0 )
			{
				if( (data_size - now_pos) > 0 )
					std::copy((fdata + now_pos), (fdata + READ_BUFFER_SIZE), fdata);

				now_pos = (data_size - now_pos);
			}

			fs.read(&fdata[now_pos], READ_BUFFER_SIZE-now_pos);
	

			if( fs.bad() )
			{
				fs.close();	
				return false;
			}

			// 読み取ったデータ数
			data_size = fs.gcount() + now_pos;
			now_pos = 0;
		}
		
		// データ数の確認
		if( data_size == 0 )
		{
			fs.close();	
			return false;
		}
	
		record_size = collect_21(&fdata[now_pos]);


		//POINT pos;
		posdata pdata;
		memset(&pdata,NULL,sizeof(pdata));

		memset(node_no,NULL,sizeof(node_no));
		memset(posx,NULL,sizeof(posx));
		memset(posy,NULL,sizeof(posy));
		memset(node_type,NULL,sizeof(node_type));
		memset(mesh2nd,NULL,sizeof(mesh2nd));
		memset(node2nd,NULL,sizeof(node2nd));

		memset(link_num,NULL,sizeof(link_num));

		memset(con_node_no,NULL,sizeof(con_node_no));
		memset(con_cress_code,NULL,sizeof(con_cress_code));
		memset(con_ang,NULL,sizeof(con_ang));

		memset(name_len,NULL,sizeof(name_len));
		memset(kana_len,NULL,sizeof(kana_len));

		copy(fdata+2+ now_pos,fdata+6+now_pos,node_no);
		copy(fdata+8+ now_pos,fdata+13+now_pos,posx);
		copy(fdata+13+now_pos,fdata+18+now_pos,posy);
		copy(fdata+21+now_pos,fdata+22+now_pos,node_type);

		copy(fdata+22+now_pos,fdata+28+now_pos,mesh2nd);
		copy(fdata+28+now_pos,fdata+32+now_pos,node2nd);

		copy(fdata+32+now_pos,fdata+33+now_pos,link_num);

		int j=0;
		int lnkpos=0;
		for(j=0;j < 8;j++)
		{
			copy(fdata+33+now_pos+lnkpos,fdata+37+now_pos+lnkpos,con_node_no[j]);
			copy(fdata+37+now_pos+lnkpos,fdata+45+now_pos+lnkpos,con_cress_code[j]);
			copy(fdata+45+now_pos+lnkpos,fdata+48+now_pos+lnkpos,con_ang[j]);
			lnkpos=lnkpos+15;
		}


		copy(fdata+153+now_pos,fdata+155+now_pos,name_len);
		copy(fdata+175+now_pos,fdata+177+now_pos,kana_len);

		int tes_x = strtol(posx, NULL, 10);
		int tes_y = strtol(posy, NULL, 10);
		int n_type = strtol(node_type, NULL, 10);

		int  mesh_code2 = strtol(mesh2nd, NULL, 10);


		int l_num = strtol(link_num, NULL, 10);
		int n_len = strtol(name_len, NULL, 10);
		int k_len = strtol(kana_len, NULL, 10);

//		if ( n_type == 1)
		{
			pdata.mesh_code =mesh_no;
			//pos.x = tes_x;
			//pos.y = tes_y;
			//pnt.push_back( pos );

			strncpy_s(pdata.node_id,sizeof(pdata.node_id),node_no,_TRUNCATE);
			pdata.seiki_pos_x = tes_x;
			pdata.seiki_pos_y = tes_y;
			pdata.node_type = n_type;

			pdata.mesh_code_2nd = mesh_code2;
			strncpy_s(pdata.node_id_2nd,sizeof(pdata.node_id_2nd),node2nd,_TRUNCATE);

			pdata.link_num = l_num;

			memset(pdata.jt_point,NULL,sizeof(pdata.jt_point));
			memset(pdata.jt_code,NULL,sizeof(pdata.jt_code));


			int cnt = 0;
			if( pdata.link_num > 0)
			{
				for (int i = 0;i < pdata.link_num ; i++)
				{

					char jt_node_no[5];
					char jt_node_code[9];
					char jt_node_ang[9];
					memset(jt_node_no,NULL,sizeof(jt_node_no));
					memset(jt_node_code,NULL,sizeof(jt_node_code));
					memset(jt_node_ang,NULL,sizeof(jt_node_ang));
				
					copy(fdata+33+now_pos+cnt,fdata+37+now_pos+cnt,jt_node_no);
					copy(fdata+37+now_pos+cnt,fdata+45+now_pos+cnt,jt_node_code);
					copy(fdata+45+now_pos+cnt,fdata+48+now_pos+cnt,jt_node_ang);

					strncpy_s(&pdata.jt_point[i][0],sizeof(pdata.jt_point[i]),jt_node_no,_TRUNCATE);
					strncpy_s(&pdata.jt_code[i][0],sizeof(pdata.jt_code[i]),jt_node_code,_TRUNCATE);
					pdata.jt_ang[i] = strtol(jt_node_code, NULL, 10);

					cnt+=15;

				}
			}



			pdata.cross_name_len = n_len;
			pdata.cross_kana_len = k_len;
			
			memset(pdata.cross_name,NULL,sizeof(pdata.cross_name));
			memset(pdata.cross_kana_name,NULL,sizeof(pdata.cross_kana_name));

			if ( n_len > 0)
			{
				char kanji_data[21];
					memset(kanji_data,NULL,sizeof(kanji_data));
					copy(fdata+155+now_pos,fdata+155 + (n_len*2) +now_pos,kanji_data);
					
					jis_to_sjis(kanji_data, (n_len*2));
					if( ( (n_len*2) % 2) )
					{
						strncpy_s(pdata.cross_name,(n_len*2)+1,kanji_data,_TRUNCATE);
					}
					else
					{
						strncpy_s(pdata.cross_name,(n_len*2),kanji_data, _TRUNCATE);
					}
					
			}
			if ( k_len > 0)
			{
				char kana_data[21];
					memset(kana_data,NULL,sizeof(kana_data));
					copy(fdata+177+now_pos,fdata+177 + k_len +now_pos,kana_data);
					
					//jis_to_sjis(kana_data, k_len);
					strncpy_s(pdata.cross_kana_name,k_len,kana_data,_TRUNCATE);
			}


			nodedata.push_back(pdata);

		}


		now_pos += record_size;
	
	}
	fs.close();	

	return true;
}



/**
 * 基本道路リンクデータ読み込み処理
 *
 * @param [in]	path	ファイル名（フルパス）
 * @param [in]	mesh_no	2次メッシュ番号
 *
 * @retval true	  正常
 * @retval false  エラー
 */
bool ParseData::readdata_22(std::string path,int mesh_no)
{

using namespace std;


	char node_1_data[5];
	char node_2_data[5];

	char link_num[4];
	char posx[6];
	char posy[6];
	char posex[6];
	char posey[6];
	char ccode[2];
	char r_code[2];
	char r_no[5];
	char m_code[2];

	char l_size[6];
	char l_code[2];

	char onlycode[2];
	char tollcode[2];
	char	hukuin_code[2];
	char	syasen[2];
	char	hukuin[4];
	char	traf[5];
	char	r_speed[5];

	//管理データ読み込
	// ファイルを開く
	char file_name[256];
	memset(file_name,NULL,sizeof(file_name));
	sprintf_s(file_name,sizeof(file_name),"%s",path.c_str());

	ldata.clear();
	if(fdata!=NULL)
	{
		fdata=NULL;
		fdata = new char[READ_BUFFER_SIZE];
	}

	std::ifstream fs(file_name, std::ios::binary | std::ios::in);
	if( fs.fail() )	return false;

	// ファイルデータがなくなるまで取得する
	std::streamsize data_size = 0;
	std::streamsize now_pos = 0;
	int record_size = 1;	// 初回だけ読み取らせるため設定
	std::fill(fdata, fdata+READ_BUFFER_SIZE, 0);
	int con_code;
	loop_flg = 0;
	con_link_num = 0;
	while( true )
	{
		if( static_cast<std::streamsize>(now_pos + record_size) > data_size )
		{

			// 使用していないデータを前に移動させる
			if( (data_size - now_pos) < static_cast<int>(record_size) && data_size > 0 )
			{
				if( (data_size - now_pos) > 0 )
					copy((fdata + now_pos), (fdata + READ_BUFFER_SIZE), fdata);

				now_pos = (data_size - now_pos);
			}

			fs.read(&fdata[now_pos], READ_BUFFER_SIZE-now_pos);
	

			if( fs.bad() )
			{
				fs.close();	
				return false;
			}

			// 読み取ったデータ数
			data_size = fs.gcount() + now_pos;
			now_pos = 0;
		}
		
		// データ数の確認
		if( data_size == 0 )
		{
			fs.close();	
			return false;
		}
	
		record_size = collect(&fdata[now_pos]);

		linkdata ld;

		memset(&ld,NULL,sizeof(ld));

		memset(node_1_data,NULL,sizeof(node_1_data));
		memset(node_2_data,NULL,sizeof(node_2_data));

		memset(link_num,NULL,sizeof(link_num));
		memset(posx,NULL,sizeof(posx));
		memset(posy,NULL,sizeof(posy));
		memset(posex,NULL,sizeof(posex));
		memset(posey,NULL,sizeof(posey));
		memset(ccode,NULL,sizeof(ccode));
		memset(r_code,NULL,sizeof(r_code));
		memset(r_no,NULL,sizeof(r_no));
		memset(m_code,NULL,sizeof(m_code));
		memset(l_code,NULL,sizeof(l_code));

		memset(onlycode,NULL,sizeof(onlycode));
		memset(tollcode,NULL,sizeof(tollcode));

		memset(hukuin_code,NULL,sizeof(hukuin_code));
		memset(syasen,NULL,sizeof(syasen));
		memset(hukuin,NULL,sizeof(hukuin));
		memset(traf,NULL,sizeof(traf));
		memset(r_speed,NULL,sizeof(r_speed));


		copy(fdata+2+ now_pos,fdata+6+now_pos,node_1_data);
		copy(fdata+6+ now_pos,fdata+10+now_pos,node_2_data);

		copy(fdata+13+ now_pos,fdata+14+now_pos,r_code);
		copy(fdata+14+ now_pos,fdata+18+now_pos,r_no);
		copy(fdata+18+ now_pos,fdata+19+now_pos,m_code);

		copy(fdata+44+ now_pos,fdata+49+now_pos,l_size);
		copy(fdata+49+ now_pos,fdata+50+now_pos,l_code);
		copy(fdata+51+ now_pos,fdata+52+now_pos,onlycode);
		copy(fdata+52+ now_pos,fdata+53+now_pos,tollcode);


		copy(fdata+58+ now_pos,fdata+59+now_pos,hukuin_code);
		copy(fdata+59+ now_pos,fdata+60+now_pos,syasen);
		copy(fdata+60+ now_pos,fdata+63+now_pos,hukuin);

		copy(fdata+74+ now_pos,fdata+78+now_pos,traf);
		copy(fdata+78+ now_pos,fdata+82+now_pos,r_speed);



		copy(fdata+88+ now_pos,fdata+91+now_pos,link_num);

		copy(fdata+91+ now_pos,fdata+96+now_pos,posx);
		copy(fdata+96+now_pos,fdata+101+now_pos,posy);

		copy(fdata+255+now_pos,fdata+256+now_pos,ccode);

		strncpy_s(ld.node_1,sizeof(ld.node_1),node_1_data,_TRUNCATE);
		strncpy_s(ld.node_2,sizeof(ld.node_2),node_2_data,_TRUNCATE);

		ld.mesh_code = mesh_no;
		ld.road_code = strtol(r_code, NULL, 10);
		ld.road_no = strtol(r_no, NULL, 10);
		ld.master_code = strtol(m_code, NULL, 10);
		ld.link_length = strtol(l_size, NULL, 10);
		ld.link_type = strtol(l_code, NULL, 10);
		ld.line_num = strtol(link_num, NULL, 10);
		ld.startpos_x = strtol(posx, NULL, 10);
		ld.startpos_y = strtol(posy, NULL, 10);

		ld.road_hukuin_code=strtol(hukuin_code, NULL, 10);
		ld.road_syasen=strtol(syasen, NULL, 10);
		ld.road_hukuin=strtol(hukuin, NULL, 10);
		ld.traffic_data=strtol(traf, NULL, 10);
		ld.ryoko_speed=strtol(r_speed, NULL, 10);
		ld.road_only_flg =strtol(onlycode, NULL, 10);
		ld.toll_flg =strtol(tollcode, NULL, 10);
		con_code =strtol(ccode, NULL, 10);

//		if (loop_flg == 1)
//		{
//			ld.cont_flg = 1;
//		}
//		else
//		{
//			ld.cont_flg = 0;
//		}
		if(con_code == 1 && loop_flg==1)
		{
			now_pos += record_size;
			continue;
		}
		
		if( con_code == 1)
		{
			loop_flg = 1;
			
			if ( con_link_num == 0)
				con_link_num = ld.line_num;
		}
		
#if 0 //補完点情報は今回不要

		int cnt=0;
//		if( ld.line_num > 2 || (loop_flg == 1 &&con_link_num > 2) )
		{
			int loopnum=0;
			//継続テーブルの場合
			if ( loop_flg == 1 ) 
			{
				loopnum = con_link_num-2;
			}
			else
			{
				loopnum =  ld.line_num-2;
			}
			
			
			for (int i=0;i < loopnum;i++)
			{
				if ( i > 13)
				{
					ld.line_num = 16;
					break;
				}
				char hose_posx[6];
				char hose_posy[6];
				memset(hose_posx,NULL,sizeof(hose_posx));
				memset(hose_posy,NULL,sizeof(hose_posy));
			
				copy(fdata+101+now_pos+cnt,fdata+106+now_pos+cnt,hose_posx);
				copy(fdata+106+now_pos+cnt,fdata+111+now_pos+cnt,hose_posy);

				ld.hosepas[i].x = strtol(hose_posx, NULL, 10);
				ld.hosepas[i].y = strtol(hose_posy, NULL, 10);


				cnt+=10;
			}

			copy(fdata+101+now_pos+cnt,fdata+106+now_pos+cnt,posex);
			copy(fdata+106+now_pos+cnt,fdata+111+now_pos+cnt,posey);

			ld.endpos.x = strtol(posex, NULL, 10);
			ld.endpos.y = strtol(posey, NULL, 10);




		}else
		{
			copy(fdata+101+ now_pos,fdata+106+now_pos,posex);
			copy(fdata+106+now_pos,fdata+111+now_pos,posey);
			ld.endpos.x = strtol(posex, NULL, 10);
			ld.endpos.y = strtol(posey, NULL, 10);

		}
#endif

		if ( loop_flg == 1 ) 
		{
			if ( con_link_num > 15)
			{
				ld.line_num = 16;
			}
			else
			{
				ld.line_num = con_link_num;
			}

			con_link_num -= 16;
		}

		if ( con_code == 0 && loop_flg == 1)
		{
			loop_flg=0;
			con_link_num = 0;
			//ld.line_num = 16;

			//継続レコードは今回いれない
			now_pos += record_size;

			continue;
		}
		ldata.push_back( ld );

		now_pos += record_size;


	}
	fs.close();	

	return true;

}

/**
 * 基本道路リンク内属性データ読み込み処理
 *
 * @param [in]	path	ファイル名（フルパス）
 * @param [in]	mesh_no	2次メッシュ番号
 *
 * @retval true	  正常
 * @retval false  エラー
 */
bool ParseData::readdata_23(std::string path,int mesh_no)
{

using namespace std;

		char node_1_data[5];
		char node_2_data[5];

		char recordno[3];
		char attrtypenum[3];

		char attr1typecode[3];
		char attr1levelcode[2];
		char attr1startnodeno[4];
		char attr1startconcode[2];
		char attr1endnodeno[4];
		char attr1endconcode[2];
		char attr1namelen[3];
		char attr1name[21];
		char attr1kanalen[3];
		char attr1kana[21];

		char attr2typecode[3];
		char attr2levelcode[2];
		char attr2startnodeno[4];
		char attr2startconcode[2];
		char attr2endnodeno[4];
		char attr2endconcode[2];
		char attr2namelen[3];
		char attr2name[21];
		char attr2kanalen[3];
		char attr2kana[21];

		char attr3typecode[3];
		char attr3levelcode[2];
		char attr3startnodeno[4];
		char attr3startconcode[2];
		char attr3endnodeno[4];
		char attr3endconcode[2];
		char attr3namelen[3];
		char attr3name[21];
		char attr3kanalen[3];
		char attr3kana[21];

		char   contflg[2];


	//管理データ読み込
	// ファイルを開く
	char file_name[256];
	memset(file_name,NULL,sizeof(file_name));
	sprintf_s(file_name,sizeof(file_name),"%s",path.c_str());

	lattr.clear();
	if(fdata!=NULL)
	{
		fdata=NULL;
		fdata = new char[READ_BUFFER_SIZE];
	}

	std::ifstream fs(file_name, std::ios::binary | std::ios::in);
	if( fs.fail() )	return false;

	// ファイルデータがなくなるまで取得する
	std::streamsize data_size = 0;
	std::streamsize now_pos = 0;
	int record_size = 1;	// 初回だけ読み取らせるため設定
	std::fill(fdata, fdata+READ_BUFFER_SIZE, 0);
	int con_code;
	loop_flg = 0;
	con_link_num = 0;
	while( true )
	{
		if( static_cast<std::streamsize>(now_pos + record_size) > data_size )
		{

			// 使用していないデータを前に移動させる
			if( (data_size - now_pos) < static_cast<int>(record_size) && data_size > 0 )
			{
				if( (data_size - now_pos) > 0 )
					copy((fdata + now_pos), (fdata + READ_BUFFER_SIZE), fdata);

				now_pos = (data_size - now_pos);
			}

			fs.read(&fdata[now_pos], READ_BUFFER_SIZE-now_pos);
	

			if( fs.bad() )
			{
				fs.close();	
				return false;
			}

			// 読み取ったデータ数
			data_size = fs.gcount() + now_pos;
			now_pos = 0;
		}
		
		// データ数の確認
		if( data_size == 0 )
		{
			fs.close();	
			return false;
		}
		//キャラクターコード変更
		record_size = collect_23(&fdata[now_pos]);

		link_attr la;

		memset(&la,NULL,sizeof(la));

		memset(node_1_data,NULL,sizeof(node_1_data));
		memset(node_2_data,NULL,sizeof(node_2_data));
		memset(recordno,NULL,sizeof(recordno));
		memset(attrtypenum,NULL,sizeof(attrtypenum));
		memset(attr1typecode,NULL,sizeof(attr1typecode));
		memset(attr1levelcode,NULL,sizeof(attr1levelcode));
		memset(attr1startnodeno,NULL,sizeof(attr1startnodeno));
		memset(attr1startconcode,NULL,sizeof(attr1startconcode));
		memset(attr1endnodeno,NULL,sizeof(attr1endnodeno));
		memset(attr1endconcode,NULL,sizeof(attr1endconcode));
		memset(attr1namelen,NULL,sizeof(attr1namelen));
		memset(attr1name,NULL,sizeof(attr1name));
		memset(attr1kanalen,NULL,sizeof(attr1kanalen));
		memset(attr1kana,NULL,sizeof(attr1kana));
		memset(attr2typecode,NULL,sizeof(attr2typecode));
		memset(attr2levelcode,NULL,sizeof(attr2levelcode));
		memset(attr2startnodeno,NULL,sizeof(attr2startnodeno));
		memset(attr2startconcode,NULL,sizeof(attr2startconcode));
		memset(attr2endnodeno,NULL,sizeof(attr2endnodeno));
		memset(attr2endconcode,NULL,sizeof(attr2endconcode));
		memset(attr2namelen,NULL,sizeof(attr2namelen));
		memset(attr2name,NULL,sizeof(attr2name));
		memset(attr2kanalen,NULL,sizeof(attr2kanalen));
		memset(attr2kana,NULL,sizeof(attr2kana));
		memset(attr3typecode,NULL,sizeof(attr3typecode));
		memset(attr3levelcode,NULL,sizeof(attr3levelcode));
		memset(attr3startnodeno,NULL,sizeof(attr3startnodeno));
		memset(attr3startconcode,NULL,sizeof(attr3startconcode));
		memset(attr3endnodeno,NULL,sizeof(attr3endnodeno));
		memset(attr3endconcode,NULL,sizeof(attr3endconcode));
		memset(attr3namelen,NULL,sizeof(attr3namelen));
		memset(attr3name,NULL,sizeof(attr3name));
		memset(attr3kanalen,NULL,sizeof(attr3kanalen));
		memset(attr3kana,NULL,sizeof(attr3kana));
		memset(contflg,NULL,sizeof(contflg));



		copy(fdata+2+ now_pos,fdata+6+now_pos,node_1_data);
		copy(fdata+6+ now_pos,fdata+10+now_pos,node_2_data);
		copy(fdata+12+ now_pos,fdata+14+now_pos,recordno);
		copy(fdata+14+ now_pos,fdata+16+now_pos,attrtypenum);


		copy(fdata+16+ now_pos,fdata+18+now_pos,attr1typecode);
		copy(fdata+18+ now_pos,fdata+19+now_pos,attr1levelcode);
		copy(fdata+19+ now_pos,fdata+22+now_pos,attr1startnodeno);
		copy(fdata+22+ now_pos,fdata+23+now_pos,attr1startconcode);
		copy(fdata+23+ now_pos,fdata+26+now_pos,attr1endnodeno);
		copy(fdata+26+ now_pos,fdata+27+now_pos,attr1endconcode);
		copy(fdata+42+ now_pos,fdata+44+now_pos,attr1namelen);
//		copy(fdata+44+ now_pos,fdata+64+now_pos,attr1name);
		copy(fdata+64+ now_pos,fdata+66+now_pos,attr1kanalen);
//		copy(fdata+66+ now_pos,fdata+86+now_pos,attr1kana);

		copy(fdata+86+ now_pos,fdata+88+now_pos,attr2typecode);
		copy(fdata+88+ now_pos,fdata+89+now_pos,attr2levelcode);
		copy(fdata+89+ now_pos,fdata+92+now_pos,attr2startnodeno);
		copy(fdata+92+ now_pos,fdata+93+now_pos,attr2startconcode);
		copy(fdata+93+ now_pos,fdata+96+now_pos,attr2endnodeno);
		copy(fdata+96+ now_pos,fdata+97+now_pos,attr2endconcode);
		copy(fdata+112+ now_pos,fdata+114+now_pos,attr2namelen);
//		copy(fdata+114+ now_pos,fdata+134+now_pos,attr2name);
		copy(fdata+134+ now_pos,fdata+136+now_pos,attr2kanalen);
//		copy(fdata+136+ now_pos,fdata+156+now_pos,attr2kana);

		copy(fdata+156+ now_pos,fdata+158+now_pos,attr3typecode);
		copy(fdata+158+ now_pos,fdata+159+now_pos,attr3levelcode);
		copy(fdata+159+ now_pos,fdata+162+now_pos,attr3startnodeno);
		copy(fdata+162+ now_pos,fdata+163+now_pos,attr3startconcode);
		copy(fdata+163+ now_pos,fdata+166+now_pos,attr3endnodeno);
		copy(fdata+166+ now_pos,fdata+167+now_pos,attr3endconcode);
		copy(fdata+182+ now_pos,fdata+184+now_pos,attr3namelen);
//		copy(fdata+184+ now_pos,fdata+204+now_pos,attr3name);
		copy(fdata+204+ now_pos,fdata+206+now_pos,attr3kanalen);
//		copy(fdata+206+ now_pos,fdata+226+now_pos,attr3kana);

		copy(fdata+255+now_pos,fdata+256+now_pos,contflg);

		strncpy_s(la.node_1,sizeof(la.node_1),node_1_data,_TRUNCATE);
		strncpy_s(la.node_2,sizeof(la.node_2),node_2_data,_TRUNCATE);

		la.mesh_code = mesh_no;

		la.record_no = strtol(recordno, NULL, 10);
		la.attr_type_num = strtol(attrtypenum, NULL, 10);

		la.atdata[0].attr_type_code = strtol(attr1typecode, NULL, 10);
		la.atdata[0].attr_level_code= strtol(attr1levelcode, NULL, 10);
		la.atdata[0].attr_start_node_no= strtol(attr1startnodeno, NULL, 10);
		la.atdata[0].attr_start_con_code= strtol(attr1startconcode, NULL, 10);
		la.atdata[0].attr_end_node_no= strtol(attr1endnodeno, NULL, 10);
		la.atdata[0].attr_end_con_code= strtol(attr1endconcode, NULL, 10);
		la.atdata[0].attr_name_len= strtol(attr1namelen, NULL, 10);
		la.atdata[0].attr_kana_len= strtol(attr1kanalen, NULL, 10);

		if ( la.atdata[0].attr_name_len > 0)
		{
			copy(fdata+44+ now_pos,fdata+44+ (la.atdata[0].attr_name_len*2) +now_pos,attr1name);
			jis_to_sjis(attr1name, (la.atdata[0].attr_name_len*2));
			if( ( (la.atdata[0].attr_name_len*2) % 2) )
			{
				strncpy_s(la.atdata[0].attr_name,(la.atdata[0].attr_name_len*2)+1,attr1name,_TRUNCATE);
			}
			else
			{
				strncpy_s(la.atdata[0].attr_name,(la.atdata[0].attr_name_len*2),attr1name,_TRUNCATE);
			}
				
		}
		if ( la.atdata[0].attr_kana_len > 0)
		{
			copy(fdata+66+now_pos,fdata+66 + la.atdata[0].attr_kana_len +now_pos,attr1kana);
				
			//jis_to_sjis(kana_data, k_len);
			strncpy_s(la.atdata[0].attr_kana,la.atdata[0].attr_kana_len,attr1kana,_TRUNCATE);
		}

		la.atdata[1].attr_type_code = strtol(attr2typecode, NULL, 10);
		la.atdata[1].attr_level_code= strtol(attr2levelcode, NULL, 10);
		la.atdata[1].attr_start_node_no= strtol(attr2startnodeno, NULL, 10);
		la.atdata[1].attr_start_con_code= strtol(attr2startconcode, NULL, 10);
		la.atdata[1].attr_end_node_no= strtol(attr2endnodeno, NULL, 10);
		la.atdata[1].attr_end_con_code= strtol(attr2endconcode, NULL, 10);
		la.atdata[1].attr_name_len= strtol(attr2namelen, NULL, 10);
		la.atdata[1].attr_kana_len= strtol(attr2kanalen, NULL, 10);

		if ( la.atdata[1].attr_name_len > 0)
		{
			copy(fdata+114+ now_pos,fdata+114+ (la.atdata[1].attr_name_len*2) +now_pos,attr2name);
			jis_to_sjis(attr2name, (la.atdata[1].attr_name_len*2));
			if( ( (la.atdata[1].attr_name_len*2) % 2) )
			{
				strncpy_s(la.atdata[1].attr_name,(la.atdata[1].attr_name_len*2)+1,attr2name,_TRUNCATE);
			}
			else
			{
				strncpy_s(la.atdata[1].attr_name,(la.atdata[1].attr_name_len*2),attr2name,_TRUNCATE);
			}
				
		}
		if ( la.atdata[1].attr_kana_len > 0)
		{
			copy(fdata+136+now_pos,fdata+136 + la.atdata[1].attr_kana_len +now_pos,attr2kana);
				
			//jis_to_sjis(kana_data, k_len);
			strncpy_s(la.atdata[1].attr_kana,la.atdata[1].attr_kana_len,attr2kana,_TRUNCATE);
		}

		la.atdata[2].attr_type_code = strtol(attr3typecode, NULL, 10);
		la.atdata[2].attr_level_code= strtol(attr3levelcode, NULL, 10);
		la.atdata[2].attr_start_node_no= strtol(attr3startnodeno, NULL, 10);
		la.atdata[2].attr_start_con_code= strtol(attr3startconcode, NULL, 10);
		la.atdata[2].attr_end_node_no= strtol(attr3endnodeno, NULL, 10);
		la.atdata[2].attr_end_con_code= strtol(attr3endconcode, NULL, 10);
		la.atdata[2].attr_name_len= strtol(attr3namelen, NULL, 10);
		la.atdata[2].attr_kana_len= strtol(attr3kanalen, NULL, 10);

		if ( la.atdata[2].attr_name_len > 0)
		{
			copy(fdata+184+ now_pos,fdata+184+ (la.atdata[2].attr_name_len*2) +now_pos,attr3name);
			jis_to_sjis(attr3name, (la.atdata[2].attr_name_len*2));
			if( ( (la.atdata[2].attr_name_len*2) % 2) )
			{
				strncpy_s(la.atdata[2].attr_name,(la.atdata[2].attr_name_len*2)+1,attr3name,_TRUNCATE);
			}
			else
			{
				strncpy_s(la.atdata[2].attr_name,(la.atdata[2].attr_name_len*2),attr3name,_TRUNCATE);
			}
				
		}
		if ( la.atdata[2].attr_kana_len > 0)
		{
			copy(fdata+206+now_pos,fdata+206 + la.atdata[2].attr_kana_len +now_pos,attr3kana);
				
			//jis_to_sjis(kana_data, k_len);
			strncpy_s(la.atdata[2].attr_kana,la.atdata[2].attr_kana_len,attr3kana,_TRUNCATE);
		}

		la.cont_flg= strtol(contflg, NULL, 10);


//		if (loop_flg == 1)
//		{
//			ld.cont_flg = 1;
//		}
//		else
//		{
//			ld.cont_flg = 0;
//		}
		if(la.cont_flg == 1 && loop_flg==1)
		{
			//途中情報
			now_pos += record_size;
			continue;
		}
		
		if( la.cont_flg == 1)
		{
			loop_flg = 1;
			
//			if ( con_link_num == 0)
//				con_link_num = ld.line_num;
		}
		

		if ( la.cont_flg == 0 && loop_flg == 1)
		{
			//終了状態
			loop_flg=0;
			//con_link_num = 0;
			//ld.line_num = 16;

			//継続レコードは今回いれない
			now_pos += record_size;

			continue;
		}
		lattr.push_back( la );

		now_pos += record_size;


	}
	fs.close();	

	return true;

}

/**
 * 水系データ読み込み処理
 *
 * @param [in]	path	ファイル名（フルパス）
 * @param [in]	mesh_no	2次メッシュ番号
 *
 * @retval true	  正常
 * @retval false  エラー
 */
bool ParseData::readdata_41(std::string path,int mesh_no)
{
using namespace std;

	char item_no[5];
	char item_record[3];
	char sui_code[2];
	char sui_num[4];
	char ccode[2];


	//管理データ読み込
	// ファイルを開く
	char file_name[256];
	memset(file_name,NULL,sizeof(file_name));
//	sprintf(file_name,"%s%d\\%d.41",E_DIR,mesh_code,mesh_code);
	sprintf_s(file_name,sizeof(file_name),"%s",path.c_str());

	sdata.clear();
	if(fdata!=NULL)
	{
		delete fdata;
		fdata=NULL;
		fdata = new char[READ_BUFFER_SIZE];
	}


	std::ifstream fs(file_name, std::ios::binary | std::ios::in);
	if( fs.fail() )	return false;

	// ファイルデータがなくなるまで取得する
	std::streamsize data_size = 0;
	std::streamsize now_pos = 0;
	int record_size = 1;	// 初回だけ読み取らせるため設定
	std::fill(fdata, fdata+READ_BUFFER_SIZE, 0);
	int con_code;
	loop_flg = 0;
	con_link_num = 0;
	while( true )
	{
		if( static_cast<std::streamsize>(now_pos + record_size) > data_size )
		{

			// 使用していないデータを前に移動させる
			if( (data_size - now_pos) < static_cast<int>(record_size) && data_size > 0 )
			{
				if( (data_size - now_pos) > 0 )
					copy((fdata + now_pos), (fdata + READ_BUFFER_SIZE), fdata);

				now_pos = (data_size - now_pos);
			}

			fs.read(&fdata[now_pos], READ_BUFFER_SIZE-now_pos);
	

			if( fs.bad() )
			{
				fs.close();	
				return false;
			}

			// 読み取ったデータ数
			data_size = fs.gcount() + now_pos;
			now_pos = 0;
		}
		
		// データ数の確認
		if( data_size == 0 )
		{
			fs.close();	
			return false;
		}
	
		record_size = collect(&fdata[now_pos]);



		suidata sd;
		memset(&sd,NULL,sizeof(sd));

		memset(item_no,NULL,sizeof(item_no));
		memset(item_record,NULL,sizeof(item_record));
		memset(sui_code,NULL,sizeof(sui_code));
		memset(sui_num,NULL,sizeof(sui_num));
		memset(ccode,NULL,sizeof(ccode));

		copy(fdata+9+ now_pos,fdata+13+now_pos,item_no);
		copy(fdata+13+ now_pos,fdata+15+now_pos,item_record);
		copy(fdata+15+ now_pos,fdata+16+now_pos,sui_code);
		copy(fdata+16+ now_pos,fdata+19+now_pos,sui_num);
		copy(fdata+255+now_pos,fdata+256+now_pos,ccode);

		sd.mesh_code = mesh_no;
		sd.item_no = strtol(item_no, NULL, 10);
		sd.item_record = strtol(item_record, NULL, 10);
		sd.sui_type = strtol(sui_code, NULL, 10);
		sd.sui_num = strtol(sui_num, NULL, 10);
		con_code =strtol(ccode, NULL, 10);

//		if (loop_flg == 1)
//		{
///			sd.cont_flg = 1;
//		}
//		else
//		{
//			sd.cont_flg = 0;
//		}
sd.cont_flg = con_code;

		if( con_code == 1)
		{
			loop_flg = 1;
			
			if ( con_link_num == 0)
				con_link_num = sd.sui_num;
		}
		

		int cnt=0;
//		if( sd.sui_num > 2 || (loop_flg == 1 &&con_link_num > 2) )
//		if( sd.sui_num > 2 || (loop_flg == 1 &&con_link_num > 2) )
		{
			int loopnum=0;
			if ( loop_flg == 1 ) 
			{
				loopnum = con_link_num;
			}
			else
			{
				loopnum =  sd.sui_num;
			}
			
			
			for (int i=0;i < loopnum;i++)
			{
				if ( i > 20)
				{
//					sd.sui_num = 21;
					break;
				}
				char linecode[2];
				char sui_posx[6];
				char sui_posy[6];
				memset(linecode,NULL,sizeof(linecode));
				memset(sui_posx,NULL,sizeof(sui_posx));
				memset(sui_posy,NULL,sizeof(sui_posy));

				copy(fdata+19+now_pos+cnt,fdata+20+now_pos+cnt,linecode);
				copy(fdata+20+now_pos+cnt,fdata+25+now_pos+cnt,sui_posx);
				copy(fdata+25+now_pos+cnt,fdata+30+now_pos+cnt,sui_posy);

				sd.sui_code[i] = strtol(linecode, NULL, 10);
				sd.sui_pos[i].x = strtol(sui_posx, NULL, 10);
				sd.sui_pos[i].y = strtol(sui_posy, NULL, 10);

				cnt+=11;
			}



//		}else
//		{
//			copy(fdata+51+ now_pos,fdata+56+now_pos,posex);
//			copy(fdata+56+now_pos,fdata+61+now_pos,posey);
//			ld.endpos.x = strtol(posex, NULL, 10);
//			ld.endpos.y = strtol(posey, NULL, 10);
		}


//		copy(fdata+101+ now_pos,fdata+106+now_pos,posex);
//		copy(fdata+106+now_pos,fdata+111+now_pos,posey);
//		ld.endpos.x = strtol(posex, NULL, 10);
//		ld.endpos.y = strtol(posey, NULL, 10);




		if ( loop_flg == 1 ) 
		{
			if ( con_link_num > 20)
			{
				sd.sui_num = 21;
			}
			else
			{
				sd.sui_num = con_link_num;
			}

			con_link_num -= 21;
		}

		if ( con_code == 0 && loop_flg == 1)
		{
			loop_flg=0;
			con_link_num = 0;
			//ld.line_num = 16;
		}
		sdata.push_back( sd );
		now_pos += record_size;

	}
			fs.close();	

	if(fdata!=NULL)
	{
		delete fdata;
		fdata=NULL;
	}
}



/**
 * ADVICS リンク対応データ読み込み処理
 *
 * @param [in]	path	ファイル名（フルパス）
 * @param [in]	mesh_no	2次メッシュ番号
 *
 * @retval true	  正常
 * @retval false  エラー
 */
bool ParseData::readdata_81(std::string path,int mesh_no)
{
#if 1

using namespace std;
	//管理データ読み込
	// ファイルを開く
	char file_name[256];
	memset(file_name,NULL,sizeof(file_name));
//	sprintf(file_name,"%s%d\\%d.81",V_DIR,mesh_code,mesh_code);
	sprintf_s(file_name,sizeof(file_name),"%s",path.c_str());

//	char* basefile= PathRemoveExtension(path.c_str());
//	int mesh_no = atoi(basefile);

	vicsdata.clear();
	if(fdata!=NULL)
	{
		delete fdata;	
		fdata=NULL;
		fdata = new char[READ_BUFFER_SIZE];
	}


	std::ifstream fs(file_name, std::ios::binary | std::ios::in);
	if( fs.fail() )	return false;

	// ファイルデータがなくなるまで取得する
	std::streamsize data_size = 0;
	std::streamsize now_pos = 0;
	int record_size = 1;	// 初回だけ読み取らせるため設定
	std::fill(fdata, fdata+READ_BUFFER_SIZE, 0);
	int con_code;
	loop_flg = 0;
	con_link_num = 0;
	node_line nd; //重複レコード処理用
	while( true )
	{
		if( static_cast<std::streamsize>(now_pos + record_size) > data_size )
		{

			// 使用していないデータを前に移動させる
			if( (data_size - now_pos) < static_cast<int>(record_size) && data_size > 0 )
			{
				if( (data_size - now_pos) > 0 )
					copy((fdata + now_pos), (fdata + READ_BUFFER_SIZE), fdata);

				now_pos = (data_size - now_pos);
			}

			fs.read(&fdata[now_pos], READ_BUFFER_SIZE-now_pos);
	

			if( fs.bad() )
			{
				fs.close();	
				return false;
			}

			// 読み取ったデータ数
			data_size = fs.gcount() + now_pos;
			now_pos = 0;
		}
		
		// データ数の確認
		if( data_size == 0 )
		{
			fs.close();	
			return false;
		}
	
		record_size = collect(&fdata[now_pos]);

		char recordno[2];		//継続レコード番号
		char linktype[2];		//リンク区分
		char vicslinkno[5];		//VICSリンク番号
		char updatecode[2];		//更新コード
		char addlinkcode[2];	//新規追加リンク識別コード

		char meshid[2];			//存在メッシュ識別
		char nodeid[6];			//基本道路ノード番号
		char nodetype[2];		//基本道路ノード種別
		char crosstype[2];		//統合交差点識別
		char linknum[5];		//構成基本道路ノードデータ総数

		char linkmeshid[2];		//存在メッシュ識別
		char linknodeno[6];		//ノード番号

		char contflg[2];		//継続フラグ


		vicslinedata ld;

		//初期化
		memset(&ld,NULL,sizeof(ld));
		memset(recordno,NULL,sizeof(recordno));
		memset(linktype,NULL,sizeof(linktype));
		memset(vicslinkno,NULL,sizeof(vicslinkno));
		memset(updatecode,NULL,sizeof(updatecode));
		memset(addlinkcode,NULL,sizeof(addlinkcode));
		memset(meshid,NULL,sizeof(meshid));
		memset(nodeid,NULL,sizeof(nodeid));
		memset(nodetype,NULL,sizeof(nodetype));
		memset(crosstype,NULL,sizeof(crosstype));
		memset(linknum,NULL,sizeof(linknum));
		memset(linkmeshid,NULL,sizeof(linkmeshid));
		memset(linknodeno,NULL,sizeof(linknodeno));
		memset(contflg,NULL,sizeof(contflg));

		//データ取得
		copy(fdata+2+ now_pos,fdata+3+now_pos,recordno);
		copy(fdata+3+ now_pos,fdata+4+now_pos,linktype);
		copy(fdata+4+ now_pos,fdata+8+now_pos,vicslinkno);
		copy(fdata+8+ now_pos,fdata+9+now_pos,updatecode);
		copy(fdata+9+ now_pos,fdata+10+now_pos,addlinkcode);

		copy(fdata+10+ now_pos,fdata+11+now_pos,meshid);
		copy(fdata+11+ now_pos,fdata+16+now_pos,nodeid);
		copy(fdata+16+ now_pos,fdata+17+now_pos,nodetype);
		copy(fdata+17+ now_pos,fdata+18+now_pos,crosstype);

		copy(fdata+26+ now_pos,fdata+30+now_pos,linknum);
		copy(fdata+255+ now_pos,fdata+256+now_pos,contflg);

		ld.mesh_code = mesh_no;
		ld.record_no = strtol(recordno, NULL, 10);
		if (ld.record_no > 1)
		{
//TRACE("データ溢れ\r\n");
		}
		ld.link_type = strtol(linktype, NULL, 10);
		ld.vics_link = strtol(vicslinkno, NULL, 10);
		ld.update_code = strtol(updatecode, NULL, 10);
		if (ld.update_code > 0)
		{
//TRACE("更新コード [%d]\r\n",ld.update_code);
		}
		ld.addlink_code = strtol(addlinkcode, NULL, 10);
		if (ld.addlink_code > 0)
		{
//TRACE("追加リンクコード [%d]\r\n",ld.addlink_code);
		}
		//流入側ノード情報
		ld.indata.mesh_id = strtol(meshid, NULL, 10);
		ld.indata.node_mesh_code = mesh_check(mesh_no,ld.indata.mesh_id);
		strncpy_s(ld.indata.node_id,sizeof(ld.indata.node_id),nodeid,_TRUNCATE);

		ld.in_node_type = strtol(nodetype, NULL, 10);
		ld.in_cross_type = strtol(crosstype, NULL, 10);

		memset(meshid,NULL,sizeof(meshid));
		memset(nodeid,NULL,sizeof(nodeid));
		memset(nodetype,NULL,sizeof(nodetype));
		memset(crosstype,NULL,sizeof(crosstype));
		copy(fdata+18+ now_pos,fdata+19+now_pos,meshid);
		copy(fdata+19+ now_pos,fdata+24+now_pos,nodeid);
		copy(fdata+24+ now_pos,fdata+25+now_pos,nodetype);
		copy(fdata+25+ now_pos,fdata+26+now_pos,crosstype);
		//流出側ノード情報
		ld.outdata.mesh_id = strtol(meshid, NULL, 10);
		ld.outdata.node_mesh_code = mesh_check(mesh_no,ld.outdata.mesh_id);
		strncpy_s(ld.outdata.node_id,sizeof(ld.outdata.node_id),nodeid,_TRUNCATE);
		ld.out_node_type = strtol(nodetype, NULL, 10);
		ld.out_cross_type = strtol(crosstype, NULL, 10);

		//リンク数
		ld.node_num = strtol(linknum, NULL, 10);
		ld.cont_flg = strtol(contflg, NULL, 10);

		if( ld.cont_flg == 1)
		{
			loop_flg = 1;
			
			if ( con_link_num == 0)
				con_link_num = ld.node_num;
		}

		int loopnum=0;
		//継続テーブルの場合
		if(loop_flg == 1)
		{
			loopnum = con_link_num;
		}
		else
		{
			loopnum = ld.node_num;
		}


		int cnt=0;

		//最後の継続テーブル
		if ( ld.cont_flg == 0 && loop_flg == 1)
		{

			ld.linkdata[0].mesh_id = nd.mesh_id;
			ld.linkdata[0].node_mesh_code = nd.node_mesh_code;
			strncpy_s(ld.linkdata[0].node_id,sizeof(ld.linkdata[0].node_id),nd.node_id,_TRUNCATE);



			for (int i=0;i < loopnum;i++)
			{
	//			if ( i > 37 && ld.cont_flg == 1)
				if ( i > 36 )
				{
	//TRACE("データ溢れ  [%d]\r\n",ld.node_num);

					//継続ノードの為、最大値を変更しておく。
					//ld.node_num=37;
					break;
				}

				memset(meshid,NULL,sizeof(meshid));
				memset(nodeid,NULL,sizeof(nodeid));

				copy(fdata+30+now_pos+cnt,fdata+31+now_pos+cnt,meshid);
				copy(fdata+31+now_pos+cnt,fdata+36+now_pos+cnt,nodeid);

				ld.linkdata[i+1].mesh_id = strtol(meshid, NULL, 10);
				ld.linkdata[i+1].node_mesh_code = mesh_check(mesh_no,ld.linkdata[i+1].mesh_id);
				strncpy_s(ld.linkdata[i+1].node_id,sizeof(ld.linkdata[i+1].node_id),nodeid,_TRUNCATE);

				cnt+=6;
			}

		}
		else
		{


			for (int i=0;i < loopnum;i++)
			{
	//			if ( i > 37 && ld.cont_flg == 1)
				if ( i > 36 )
				{
	//TRACE("データ溢れ  [%d]\r\n",ld.node_num);

					//継続ノードの為、最大値を変更しておく。
					//ld.node_num=37;
					break;
				}

				memset(meshid,NULL,sizeof(meshid));
				memset(nodeid,NULL,sizeof(nodeid));

				copy(fdata+30+now_pos+cnt,fdata+31+now_pos+cnt,meshid);
				copy(fdata+31+now_pos+cnt,fdata+36+now_pos+cnt,nodeid);

				ld.linkdata[i].mesh_id = strtol(meshid, NULL, 10);
				ld.linkdata[i].node_mesh_code = mesh_check(mesh_no,ld.linkdata[i].mesh_id);
				strncpy_s(ld.linkdata[i].node_id,sizeof(ld.linkdata[i].node_id),nodeid, _TRUNCATE);

				//継続レコードの場合
				if(loop_flg == 1)
				{
					nd.mesh_id = strtol(meshid, NULL, 10);
					nd.node_mesh_code = mesh_check(mesh_no,ld.linkdata[i].mesh_id);
					strncpy_s(nd.node_id,sizeof(nd.node_id),nodeid, _TRUNCATE);

				}

				cnt+=6;
			}
		}
		//継続テーブルの場合
		if ( loop_flg == 1 ) 
		{
			//テーブルサイズより大きい場合
			if(con_link_num > 37)
			{
				//ld.node_num = 37;
			}
			else
			{
				ld.node_num = con_link_num+1;
			}
			con_link_num -=37;
		}

		//最後の継続テーブル
		if ( ld.cont_flg == 0 && loop_flg == 1)
		{
			loop_flg=0;
			con_link_num = 0;
			//ld.line_num = 16;
		}

		vicsdata.push_back( ld );

		now_pos += record_size;

	}
	fs.close();	

#endif



	return true;
}


/**
 * ADVICS キャラクターコード変換
 *
 * @param [in]	buf	ファイルバッファ
 *
 * @retval 257  バッファサイズ
 */
int	ParseData::collect(char *buf)
{
	for( int i = 0; i < 256;i++)
	{
		buf[i] = ebcdic2char(buf[i]);
	}

	return 257;

}
/**
 * ADVICS キャラクターコード変換（ID:21 基本ノード用）
 *
 * @param [in]	buf	ファイルバッファ
 *
 * @retval 257  バッファサイズ
 */

int	ParseData::collect_21(char *buf)
{
	for( int i = 0; i < 155;i++)
	{
		buf[i] = ebcdic2char(buf[i]);
	}

	for( int i = 175; i < 177;i++)
	{
		buf[i] = ebcdic2char(buf[i]);
	}


	for( int i = 177; i < 256;i++)
	{
		buf[i] = ebcdic2char(buf[i]);
	}

	return 257;

}

/**
 * ADVICS キャラクターコード変換（ID:23 基本リンク内属性用）
 *
 * @param [in]	buf	ファイルバッファ
 *
 * @retval 257  バッファサイズ
 */

int	ParseData::collect_23(char *buf)
{
	for( int i = 0; i < 44;i++)
	{
		buf[i] = ebcdic2char(buf[i]);
	}

	for( int i = 64; i < 114;i++)
	{
		buf[i] = ebcdic2char(buf[i]);
	}


	for( int i = 134; i < 184;i++)
	{
		buf[i] = ebcdic2char(buf[i]);
	}

	for( int i = 204; i < 256;i++)
	{
		buf[i] = ebcdic2char(buf[i]);
	}

	return 257;

}

/**
 * CSVファイル出力
 *
 * @retval   バッファサイズ

 * @retval true  正常
 * @retval false エラー
 */
bool ParseData::saveadvicsfiledata()
{
	using namespace std;

	// ファイルを開く
	FILE* fp = fopen(ADVICS_FILE, "a");
		if( fp == NULL )
			return false;

if(write_flg==0)
{
		fprintf(fp, "レコードID,メッシュコード,継続レコード番号,リンク区分,ＶＩＣＳリンク番号,更新コード,新規追加リンク識別コード,\
流入側 存在メッシュ識別,流入側メッシュコード,流入側基本道路ノード番号,基本道路ノード種別,統合交差点識別,\
流出側 存在メッシュ識別,流出側メッシュコード,流出側基本道路ノード番号,基本道路ノード種別,統合交差点識別,構成基本道路ノードデータ総数,\
リンク構成ノード列 構成基本ノード(1) 存在メッシュ識別,ノード番号,\
構成基本ノード(2) 存在メッシュ識別,ノード番号,\
構成基本ノード(3) 存在メッシュ識別,ノード番号,\
構成基本ノード(4) 存在メッシュ識別,ノード番号,\
構成基本ノード(5) 存在メッシュ識別,ノード番号,\
構成基本ノード(6) 存在メッシュ識別,ノード番号,\
構成基本ノード(7) 存在メッシュ識別,ノード番号,\
構成基本ノード(8) 存在メッシュ識別,ノード番号,\
構成基本ノード(9) 存在メッシュ識別,ノード番号,\
構成基本ノード(10) 存在メッシュ識別,ノード番号,\
構成基本ノード(11) 存在メッシュ識別,ノード番号,\
構成基本ノード(12) 存在メッシュ識別,ノード番号,\
構成基本ノード(13) 存在メッシュ識別,ノード番号,\
構成基本ノード(14) 存在メッシュ識別,ノード番号,\
構成基本ノード(15) 存在メッシュ識別,ノード番号,\
構成基本ノード(16) 存在メッシュ識別,ノード番号,\
構成基本ノード(17) 存在メッシュ識別,ノード番号,\
構成基本ノード(18) 存在メッシュ識別,ノード番号,\
構成基本ノード(19) 存在メッシュ識別,ノード番号,\
構成基本ノード(20) 存在メッシュ識別,ノード番号,\
構成基本ノード(21) 存在メッシュ識別,ノード番号,\
構成基本ノード(22) 存在メッシュ識別,ノード番号,\
構成基本ノード(23) 存在メッシュ識別,ノード番号,\
構成基本ノード(24) 存在メッシュ識別,ノード番号,\
構成基本ノード(25) 存在メッシュ識別,ノード番号,\
構成基本ノード(26) 存在メッシュ識別,ノード番号,\
構成基本ノード(27) 存在メッシュ識別,ノード番号,\
構成基本ノード(28) 存在メッシュ識別,ノード番号,\
構成基本ノード(29) 存在メッシュ識別,ノード番号,\
構成基本ノード(30) 存在メッシュ識別,ノード番号,\
構成基本ノード(31) 存在メッシュ識別,ノード番号,\
構成基本ノード(32) 存在メッシュ識別,ノード番号,\
構成基本ノード(33) 存在メッシュ識別,ノード番号,\
構成基本ノード(34) 存在メッシュ識別,ノード番号,\
構成基本ノード(35) 存在メッシュ識別,ノード番号,\
構成基本ノード(36) 存在メッシュ識別,ノード番号,\
構成基本ノード(37) 存在メッシュ識別,ノード番号,\
継続フラグ\n");
write_flg=1;
}
		// 対象ファイルを開きデータを書き込む
		for(vector<vicslinedata>::iterator it = vicsdata.begin(); it != vicsdata.end(); ++it)
		{
			//if (it->write_flg == 1)
			{

			// ヘッダの順にデータを出力する
			fprintf(fp, "81,%d,%d,%d,%d,%d,%d,%d,%d,%s,%d,%d,%d,%d,%s,%d,%d,%d,",
				it->mesh_code,it->record_no,it->link_type,it->vics_link,it->update_code,it->addlink_code,
				it->indata.mesh_id,it->indata.node_mesh_code,it->indata.node_id,it->in_node_type,it->in_cross_type,
				it->outdata.mesh_id,it->outdata.node_mesh_code,it->outdata.node_id,it->out_node_type,it->out_cross_type,
				it->node_num);

				for (int i=0;i < 37;i++)
				{
					if ( i > 37)
					{
//TRACE("データ溢れ  [%d]\r\n",ld.node_num);

						break;
					}
					if(strlen(it->linkdata[i].node_id) > 0)
					{					
						fprintf(fp,"%d,%s,",it->linkdata[i].mesh_id,it->linkdata[i].node_id);
					}
					else
					{
						fprintf(fp,",,");
					}
				}
				fprintf(fp,"%d\n",it->cont_flg);
//		ld.traffic_data=strtol(traf, NULL, 10);
//		ld.ryoko_speed=strtol(r_speed, NULL, 10);



			}
		}

		// ファイルを閉じる
		if( fp != NULL )
			fclose(fp);


	return true;
}

/**
 * ADVICSデータDB登録
 *
 * @retval   

 * @retval true  正常
 * @retval false エラー
 */
bool ParseData::insertadvicsdata()
{
	using namespace std;
	// 地図データベースの作成
//	DBSetting mdb;
	if( 0 !=mdb.Connection() )
	{
		return false;
	}

	//ADVICSテーブル インサート準備
	mdb.prepare_advics_insert();
	//ADVICS ノード情報テーブル インサート準備
	mdb.prepare_advicsnode_insert();

	// トランザクション開始
	mdb.begin();

	// 対象ファイルを開きデータを書き込む
	for(vector<vicslinedata>::iterator it = vicsdata.begin(); it != vicsdata.end(); ++it)
	{

		//高速道路、都市高速道路のみを対象とする。
		//if(it->link_type != 1 && it->link_type != 2)
		//{
		//	continue;
		//}

		vicslinedata vr;
		memset(&vr,NULL,sizeof(vr));

		vr.mesh_code = it->mesh_code;

		vr.record_no = it->record_no;
		vr.link_type = it->link_type;
		vr.vics_link = it->vics_link;
		vr.update_code = it->update_code;
		vr.addlink_code = it->addlink_code;
		vr.indata.mesh_id = it->indata.mesh_id;
		vr.indata.node_mesh_code = it->indata.node_mesh_code;
		memcpy(vr.indata.node_id,it->indata.node_id,sizeof(vr.indata.node_id));
		vr.in_node_type = it->in_node_type;
		vr.in_cross_type = it->in_cross_type;
		vr.outdata.mesh_id = it->outdata.mesh_id;
		vr.outdata.node_mesh_code = it->outdata.node_mesh_code;
		memcpy(vr.outdata.node_id,it->outdata.node_id,sizeof(vr.outdata.node_id));
		vr.out_node_type = it->out_node_type;
		vr.out_cross_type = it->out_cross_type;
		vr.node_num = it->node_num;
		vr.cont_flg = it->cont_flg;
		for (int i=0; i< 37;i++)
		{
			vr.linkdata[i].mesh_id = it->linkdata[i].mesh_id;
			vr.linkdata[i].node_mesh_code = it->linkdata[i].node_mesh_code;
			memcpy(vr.linkdata[i].node_id,it->linkdata[i].node_id,sizeof(vr.linkdata[i].node_id));
		}

		//継続レコードは登録しない
		if(vr.record_no == 1)
		{
			// データベースに登録する
			if( !mdb.insertdata(vr) )
			{
				mdb.rollback();
				return false;
			}
			int l_cnt=0;
			if(vr.cont_flg==1)
			{
				l_cnt=36;
			}
			else
			{
				l_cnt=vr.node_num-1;

			}

			for(int i=0;i < l_cnt;i++)
			{
				// データベースに登録する
				if( !mdb.insertadvicsnodedata(vr,i,0) )
				{
					mdb.rollback();
					return false;

				}
			}
		}
		else
		{
			for(int i=0;i < vr.node_num-1;i++)
			{
				vr.record_no=1;
				// データベースに登録する
				if( !mdb.insertadvicsnodedata(vr,i,1) )
				{
					mdb.rollback();
					return false;

				}
			}
		}
	}
	// トランザクション終了
	mdb.commit();

	//DB切断
	mdb.disconnect();

	return true;

}


/**
 * 基本ノードデータDB登録
 *
 * @retval   

 * @retval true  正常
 * @retval false エラー
 */
bool ParseData::insertbasicnodedata()
{
	using namespace std;
	// 地図データベースの作成
	DBSetting mdb;
	if( 0 !=mdb.Connection() )
	{
		return false;
	}

	//基本ノードテーブル インサート準備
	mdb.prepare_node_insert();

	// トランザクション開始
	mdb.begin();

	// 対象ファイルを開きデータを書き込む
	for(vector<posdata>::iterator it = nodedata.begin(); it != nodedata.end(); ++it)
	{

		//高速道路、都市高速道路のみを対象とする。
//		if(it->link_type != 1 && it->link_type != 2)
//		{
//			continue;
//		}

		posdata vr;
		memset(&vr,NULL,sizeof(vr));

		vr.mesh_code = it->mesh_code;
		memcpy(vr.node_id,it->node_id,sizeof(vr.node_id));
		vr.node_type = it->node_type;

		vr.mesh_code_2nd = it->mesh_code_2nd;
		memcpy(vr.node_id_2nd,it->node_id_2nd,sizeof(vr.node_id_2nd));


		vr.seiki_pos_x = it->seiki_pos_x;
		vr.seiki_pos_y = it->seiki_pos_y;
		//正規座標をDMS形式座標に変換する。
		unsigned int l_lat = it->seiki_pos_y;
		unsigned int l_lon = it->seiki_pos_x;
		getLonLat(it->mesh_code,l_lat,l_lon);

		//ミリ秒単位をDMS形式に変更
		double a = ((double)l_lon) /3600000 * 1000000;
		double b = ((double)l_lat) /3600000 * 1000000;
		//小数7桁目以降を切り捨て
		vr.pos_x = floor(a)/ 1000000;
		vr.pos_y = floor(b)/ 1000000;

		vr.cross_name_len = it->cross_name_len;
		vr.cross_kana_len = it->cross_kana_len;


		memcpy(vr.cross_name,it->cross_name,sizeof(vr.cross_name));
		memcpy(vr.cross_kana_name,it->cross_kana_name,sizeof(vr.cross_kana_name));

		if ( it->link_num > 0)
		{
			for (int i = 0;i < it->link_num ; i++)
			{

				memcpy(vr.jt_point[i],it->jt_point[i],sizeof(vr.jt_point));
				memcpy(vr.jt_code[i],it->jt_code[i],sizeof(vr.jt_code));
				vr.jt_ang[i]  = it->jt_ang[i];

			}

		}

		// データベースに登録する
		if( !mdb.insertnodedata(vr) )
		{
			mdb.rollback();
			return false;
		}
	}
	// トランザクション終了
	mdb.commit();

	//DB切断
	mdb.disconnect();

	return true;

}

/**
 * 基本リンクデータDB登録
 *
 * @retval   

 * @retval true  正常
 * @retval false エラー
 */
bool ParseData::insertbasiclinkdata()
{
	using namespace std;
	// 地図データベースの作成
//	DBSetting mdb;
	if( 0 !=mdb.Connection() )
	{
		return false;
	}

	//基本リンクテーブル インサート準備
	mdb.prepare_link_insert();

	// トランザクション開始
	mdb.begin();

	// 対象ファイルを開きデータを書き込む
	for(vector<linkdata>::iterator it = ldata.begin(); it != ldata.end(); ++it)
	{

		//高速道路、都市高速道路のみを対象とする。
//		if(it->link_type != 1 && it->link_type != 2)
//		{
//			continue;
//		}

		linkdata vr;
		memset(&vr,NULL,sizeof(vr));

		vr.mesh_code = it->mesh_code;
		memcpy(vr.node_1,it->node_1,sizeof(vr.node_1));
		memcpy(vr.node_2,it->node_2,sizeof(vr.node_2));
		vr.road_code = it->road_code;
		vr.road_no = it->road_no;
		vr.master_code = it->master_code;
		vr.link_length = it->link_length;
		vr.link_type = it->link_type;

		vr.road_only_flg = it->road_only_flg;
		vr.toll_flg = it->toll_flg;


		// データベースに登録する
		if( !mdb.insertlinkdata(vr) )
		{
			mdb.rollback();
			return false;
		}
	}
	// トランザクション終了
	mdb.commit();

	//DB切断
	mdb.disconnect();

	return true;

}

/**
 * 基本リンク内属性データDB登録
 *
 * @retval   

 * @retval true  正常
 * @retval false エラー
 */
bool ParseData::insertlinkattrdata()
{
	using namespace std;
	int i=0;	

	// 地図データベースの作成
//	DBSetting mdb;
	if( 0 !=mdb.Connection() )
	{
		return false;
	}

	//基本リンクテーブル インサート準備
	mdb.prepare_link_attr_insert();

	// トランザクション開始
	mdb.begin();

	// 対象ファイルを開きデータを書き込む
	for(vector<link_attr>::iterator it = lattr.begin(); it != lattr.end(); ++it)
	{

		//高速道路、都市高速道路のみを対象とする。
//		if(it->link_type != 1 && it->link_type != 2)
//		{
//			continue;
//		}

		link_attr vr;
		memset(&vr,NULL,sizeof(vr));

		vr.mesh_code = it->mesh_code;
		memcpy(vr.node_1,it->node_1,sizeof(vr.node_1));
		memcpy(vr.node_2,it->node_2,sizeof(vr.node_2));

		vr.record_no = it->record_no;
		vr.attr_type_num = it->attr_type_num;

		for (i=0;i< 3;i++)
		{
			vr.atdata[i].attr_type_code = it->atdata[i].attr_type_code;
			vr.atdata[i].attr_level_code= it->atdata[i].attr_level_code;
			vr.atdata[i].attr_start_node_no= it->atdata[i].attr_start_node_no;
			vr.atdata[i].attr_start_con_code= it->atdata[i].attr_start_con_code;
			vr.atdata[i].attr_end_node_no= it->atdata[i].attr_end_node_no;
			vr.atdata[i].attr_end_con_code= it->atdata[i].attr_end_con_code;
			vr.atdata[i].attr_name_len= it->atdata[i].attr_name_len;
			vr.atdata[i].attr_kana_len= it->atdata[i].attr_kana_len;
			memcpy(vr.atdata[i].attr_name,it->atdata[i].attr_name,sizeof(vr.atdata[i].attr_name));
			memcpy(vr.atdata[i].attr_kana,it->atdata[i].attr_kana,sizeof(vr.atdata[i].attr_kana));
		}

		vr.cont_flg= it->cont_flg;

		// データベースに登録する
		if( !mdb.insertlinkattrdata(vr) )
		{
			mdb.rollback();
			return false;
		}
	}
	// トランザクション終了
	mdb.commit();

	//DB切断
	mdb.disconnect();

	return true;

}


/**
 * 水系データDB登録
 *
 * @retval   

 * @retval true  正常
 * @retval false エラー
 */
bool ParseData::insertwaterdata()
{
	using namespace std;
	// 地図データベースの作成
//	DBSetting mdb;
	if( 0 !=mdb.Connection() )
	{
		return false;
	}

	//基本リンクテーブル インサート準備
//	mdb.prepare_water_insert();
//	mdb.prepare_water_insert2();
	mdb.prepare_water_poly_insert();

	// トランザクション開始
	mdb.begin();

	// 対象ファイルを開きデータを書き込む
	for(vector<suidata>::iterator it = sdata.begin(); it != sdata.end(); ++it)
	{


		suidata vr;
		memset(&vr,NULL,sizeof(vr));

		vr.mesh_code = it->mesh_code;

		vr.item_no = it->item_no;
		vr.item_record = it->item_record;
		vr.sui_type = it->sui_type;
		vr.sui_num = it->sui_num;
		for(int i = 0;i < vr.sui_num;i++)
		{
			vr.sui_code[i] = it->sui_code[i];

			unsigned int l_lat = it->sui_pos[i].x;
			unsigned int l_lon = it->sui_pos[i].y;
			getLonLat(it->mesh_code,l_lat,l_lon);


			vr.sui_pos[i].x = l_lat;
			vr.sui_pos[i].y = l_lon;
		}

		vr.lv_flg = it->lv_flg;
		vr.cont_flg = it->cont_flg;

		// データベースに登録する
//		if( !mdb.insertwaterdata(vr) )
//		if( !mdb.insertwaterdata2(vr) )
//		{
//			mdb.rollback();
//			return false;
//		}
		if( !mdb.insertwaterpoly(vr) )
		{
			mdb.rollback();
			return false;
		}

	}
	// トランザクション終了
	mdb.commit();

	//DB切断
	mdb.disconnect();

	return true;

}


//m_vicslinkデータ生成
bool ParseData::insertmakedata_adf()
{
	using namespace std;

	//DB接続
	if( 0 !=mdb.Connection() )
	{
		return false;
	}
	// トランザクション開始
	mdb.begin();

//add by cuijun on 2011/12/10
#if 1
	//m_advicsnode_mixテーブルにデータインサート
	if(0 != mdb.insertadvicsnode_mix())
	{
		//DB切断
		mdb.disconnect();
		return false;
	}
	// トランザクション終了
	mdb.commit();
#endif
//add by cuijun on 2011/12/10

#if 1
	//m_vicslink_adfテーブルにデータインサート
	if(0 != mdb.insertvicslinkdata_adf())
	{
		//DB切断
		mdb.disconnect();
		return false;
	}
	// トランザクション終了
	mdb.commit();
#endif
#if 1
	//渋滞長調整
	if(0 != mdb.setlinklength_adf())
	{
		//DB切断
		mdb.disconnect();
		return false;
	}

	// トランザクション終了
	mdb.commit();
#endif	

	// トランザクション終了
		mdb.commit();
	//DB切断
	mdb.disconnect();
	return true;
}

//m_vicslink_adf 施設情報の調整
bool ParseData::execmakedata_adf()
{
	using namespace std;

	//DB接続
	if( 0 !=mdb.Connection() )
	{
		return false;
	}
	// トランザクション開始
	mdb.begin();

//リンク並び順の初期値設定を入れる事

	//施設始端に0設定
	if(0 != mdb.set_adf_zero1())
	{
		//DB切断
		mdb.disconnect();
		return false;
	}
	if(0 != mdb.set_adf_zero2())
	{
		//DB切断
		mdb.disconnect();
		return false;
	}

	int res1 =0;
	int res2 =0;
	int res3 =0;

#if 1
	while(1)
	{
#if 1
		res1= mdb.update_linkdata_node_adf();
		if(-1== res1)
		{
			//DB切断
			mdb.disconnect();
			return false;
		}
#endif
#if 1
		res2 =  mdb.updateafterfacildata_adf();
		if(-1 ==res2)
		{
			//DB切断
			mdb.disconnect();
			return false;
		}
#endif
#if 1
		res3 = mdb.updatebeforefacildata_adf();
		if(-1 == res3)
		{
			//DB切断
			mdb.disconnect();
			return false;
		}
#endif
		if(res1 ==1 && res2 == 1 && res3 ==1)
//		if(res3 ==1 )
		{
			break;
		}
	}
#endif

	// トランザクション終了
		mdb.commit();
	//DB切断
	mdb.disconnect();
	return true;
}