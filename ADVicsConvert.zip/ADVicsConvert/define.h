#include <vector>

#include <stdio.h>
#include <stdlib.h>
//#include <windef.h>
//#include <string>
//#include <sstream>
//#include <string>

//#include <atltypes.h>

//�f�[�^�x�[�X�ڑ����


//�G���[�R�[�h
#define CONV_NO_NETWORK_DATA		1000	//����:�l�b�g���[�N��񂪂Ȃ��ꍇ
#define CONV_SUCCESS				0		//����
#define CONV_OTHER_ERROR			-1001	//���̑��̃G���[
#define CONV_CANNOT_OPEN_FILE		-1002	//�t�@�C�����I�[�v���ł��Ȃ��ꍇ�̃G���[
#define CONV_MEMORY_ALLOC_ERROR		-1003	//���������m�ۂł��Ȃ��ꍇ�̃G���[
#define CONV_OVER_FLOW_ERROR		-1004	//�m�ۂ����o�b�t�@���I�[�o�[�t���[�����ꍇ�̃G���[
#define CONV_ILLEGAL_DATA			-1005	//�\���ł��Ȃ��f�[�^�̃G���[
#define CONV_CONNECTION_ERROR		-2001	//�R�l�N�V�����G���[
#define CONV_DB_ERROR				-2002	//DB�̃G���[

#define DB_HOST "localhost"
//�͐�f�[�^�o�^�p
//#define DB_HOST "10.69.130.81"
#define DB_PORT "5432"
#define DB_OPTIONS ""
#define DB_TTY ""
//#define DB_NAME "vics_info"
//#define DB_NAME "vics_phase7"
//#define DB_NAME "vics_sumi"
//#define DB_NAME "vics_info_test_0909"
#define DB_NAME "vics_info_saitest"

//�͐�f�[�^�o�^�p
//#define DB_NAME "vics_gis"



//#define DB_NAME "vics_test"
//#define DB_NAME "vics"
#define DB_USERNAME "postgres"
#define DB_PASSWORD "postgres"

//��{�m�[�h���e�[�u�����쐬����B
#define CREATE_BASICNODE "CREATE TABLE m_basicnode (meshcode integer NOT NULL,nodeid character(5) NOT NULL,nodetype integer,meshcode2nd integer,nodeid2nd character(5),seiki_pos_x integer,seiki_pos_y integer,pos_x double precision,pos_y double precision, cross_name text,cross_kana_name text,CONSTRAINT basicnode_pkey PRIMARY KEY (meshcode, nodeid));"
//��{�����N���e�[�u�����쐬����B
//#define CREATE_BASICLINK "CREATE TABLE m_basiclink (meshcode integer NOT NULL,in_nodeid character(5) NOT NULL,out_nodeid character(5) NOT NULL,roadtype integer,link_length integer,link_type integer,  road_only_flg integer,toll_flg integer,CONSTRAINT basiclink_pkey PRIMARY KEY (meshcode, in_nodeid, out_nodeid));"
#define CREATE_BASICLINK \
				"CREATE TABLE m_basiclink \
				( \
				  meshcode integer NOT NULL, \
				  in_nodeid character(5) NOT NULL, \
				  out_nodeid character(5) NOT NULL, \
				  roadtype integer, \
				  roadno integer, \
				  mastercode integer, \
				  link_length integer, \
				  link_type integer, \
				  road_only_flg integer, \
				  toll_flg integer, \
				  CONSTRAINT basiclink_pkey PRIMARY KEY (meshcode, in_nodeid, out_nodeid) \
				);"


//ADVICS�e�[�u�����쐬����B
#define CREATE_ADVICS "CREATE TABLE m_advics (meshcode integer NOT NULL,recordno integer NOT NULL,linktype integer NOT NULL,vicslinkno integer NOT NULL,updatecode integer,addlinkcode integer,in_meshid integer,in_meshcode integer,in_nodeid character(5),in_nodetype integer,in_crosstype integer,out_meshid integer,out_meshcode integer,out_nodeid character(5),out_nodetype integer,out_crosstype integer,nodenum integer,contflag integer,  CONSTRAINT advics_pkey PRIMARY KEY (meshcode, recordno, linktype, vicslinkno));"
//ADVICS�m�[�h���e�[�u�����쐬����B
#define CREATE_ADVICSNODE "CREATE TABLE m_advicsnode (meshcode integer NOT NULL,recordno integer NOT NULL,linktype integer NOT NULL,vicslinkno integer NOT NULL,seqno integer NOT NULL,in_meshid integer,in_nodemeshcode integer,in_nodeid character(6),out_meshid integer,out_nodemeshcode integer,out_nodeid character(6),CONSTRAINT advicsnode_pkey PRIMARY KEY (meshcode, recordno, linktype, vicslinkno, seqno));"
//ADVICS�m�[�h���e�[�u�����쐬����B
#define CREATE_ADVICSNODE_MIX "CREATE TABLE m_advicsnode_mix ( meshcode integer NOT NULL,linktype integer NOT NULL,vicslinkno integer NOT NULL,seqno integer NOT NULL,nodenum integer,in_meshid integer,in_nodemeshcode integer,in_nodeid text,out_meshid integer,out_nodemeshcode integer,out_nodeid text,linklen integer,link_type integer,road_only_flg integer,toll_flg integer,CONSTRAINT advicsnode_mix_pkey PRIMARY KEY (meshcode, linktype, vicslinkno, seqno));"

//�{�ݕ��у`�F�b�N�pview
#define CREATE_VICSFACIL_VIEW "CREATE OR REPLACE VIEW v_vicsfacil_adf4 AS SELECT DISTINCT ad.meshcode, ad.linktype, ad.vicslinkno, at.nodenum, at.link_type, at.road_only_flg, at.toll_flg, ad.in_meshid, ad.in_nodemeshcode, ad.in_nodeid, ad.out_meshid, ad.out_nodemeshcode, ad.out_nodeid, ad.seqno, startd.\"RoadID\" AS startroadid, startd.\"FacilName\" AS startfacilname, startd.\"RoadSeqNo\" AS startfacilno, startd.\"Direction\" AS startdirection, edd.\"RoadID\" AS endroadid, edd.\"FacilName\" AS endfacilname, edd.\"RoadSeqNo\" AS endfacilno, edd.\"Direction\" AS enddirection FROM m_advicsnode ad LEFT JOIN m_advicsnode_mix at ON ad.meshcode = at.meshcode AND ad.linktype = at.linktype AND ad.vicslinkno = at.vicslinkno AND ad.seqno = at.seqno LEFT JOIN ( SELECT DISTINCT nd.\"MeshCode\", nd.\"RoadCode\", nd.\"RoadSeqNo\", nd.\"AllRoadNodeNo\", rp.\"FacilName\", mc1.\"RoadID\", hw1.\"Direction\" FROM m_hwynode nd, m_roadpoint rp, m_highway hw1, m_roadpaircode mc1 WHERE nd.\"MeshCode\" = rp.\"RepMeshCode\" AND nd.\"RoadCode\" = rp.\"RoadCode\" AND nd.\"RoadCode\" = hw1.\"RoadCode\" AND nd.\"RoadSeqNo\" = rp.\"RoadSeqNo\" AND nd.\"RoadSeqNo\" = hw1.\"RoadSeqNo\" AND nd.\"RoadCode\" = mc1.\"RoadCode\" AND nd.\"DirFlag\" = hw1.\"Direction\" ORDER BY nd.\"MeshCode\", nd.\"RoadCode\", nd.\"RoadSeqNo\", nd.\"AllRoadNodeNo\", rp.\"FacilName\", mc1.\"RoadID\", hw1.\"Direction\") startd ON ad.in_nodemeshcode = startd.\"MeshCode\" AND ad.in_nodeid = startd.\"AllRoadNodeNo\" LEFT JOIN ( SELECT DISTINCT nd.\"MeshCode\", nd.\"RoadCode\", nd.\"RoadSeqNo\", nd.\"AllRoadNodeNo\", rp.\"FacilName\", mc2.\"RoadID\", hw2.\"Direction\" FROM m_hwynode nd, m_roadpoint rp, m_highway hw2, m_roadpaircode mc2 WHERE nd.\"MeshCode\" = rp.\"RepMeshCode\" AND nd.\"RoadCode\" = rp.\"RoadCode\" AND nd.\"RoadCode\" = hw2.\"RoadCode\" AND nd.\"RoadSeqNo\" = rp.\"RoadSeqNo\" AND nd.\"RoadSeqNo\" = hw2.\"RoadSeqNo\" AND nd.\"RoadCode\" = mc2.\"RoadCode\" AND nd.\"DirFlag\" = hw2.\"Direction\" ORDER BY nd.\"MeshCode\", nd.\"RoadCode\", nd.\"RoadSeqNo\", nd.\"AllRoadNodeNo\", rp.\"FacilName\", mc2.\"RoadID\", hw2.\"Direction\") edd ON ad.out_nodemeshcode = edd.\"MeshCode\" AND ad.out_nodeid = edd.\"AllRoadNodeNo\" ORDER BY ad.meshcode, ad.linktype, ad.vicslinkno, ad.seqno, ad.in_meshid, ad.in_nodeid, ad.out_meshid, ad.out_nodeid, startd.\"RoadID\", startd.\"FacilName\", startd.\"RoadSeqNo\", edd.\"RoadID\", edd.\"FacilName\", edd.\"RoadSeqNo\", ad.in_nodemeshcode, ad.out_nodemeshcode, at.nodenum, at.link_type, at.road_only_flg, at.toll_flg, edd.\"Direction\", startd.\"Direction\";"

//�{�ݕ��ѐݒ�pview
#define CREATE_VICSFACILDATA_VIEW "CREATE OR REPLACE VIEW v_vicsfacildata_adf4_1 AS SELECT v_vf.meshcode, v_vf.linktype, v_vf.vicslinkno, v_vf.nodenum, v_vf.link_type, v_vf.road_only_flg, v_vf.toll_flg, v_vf.in_meshid, v_vf.in_nodemeshcode, v_vf.in_nodeid, v_vf.out_meshid, v_vf.out_nodemeshcode, v_vf.out_nodeid, v_vf.seqno,CASE WHEN v_vf.startroadid <> 0 THEN v_vf.startroadid ELSE vl.\"StartRoadID\" END AS startroadid, v_vf.startfacilname, CASE WHEN v_vf.startfacilno <> 0 THEN v_vf.startfacilno ELSE vl.\"StartFacilityID\" END AS startfacilno, v_vf.startdirection,CASE WHEN v_vf.endroadid <> 0 THEN v_vf.endroadid ELSE vl.\"EndRoadID\" END AS endroadid, v_vf.endfacilname,CASE WHEN v_vf.endfacilno <> 0 THEN v_vf.endfacilno ELSE vl.\"EndFacilityID\" END AS endfacilno, v_vf.enddirection, vl.\"Seq\", vl.\"Direction\", vl.\"RoadSeqNo\" FROM v_vicsfacil_adf4 v_vf, m_vicslink_adf1 vl WHERE v_vf.meshcode = vl.\"MeshNo\" AND v_vf.linktype = vl.\"VicsLinkType\" AND v_vf.vicslinkno = vl.\"VicsLinkNo\" AND v_vf.seqno = vl.\"Seq\";"



#define DROP_VICSFACIL_VIEW "DROP VIEW v_vicsfacil_adf4;"
#define DROP_VICSFACILDATA_VIEW "DROP VIEW v_vicsfacildata_adf4_1;"

//ADVICS�e�[�u���̃f�[�^�𗎂Ƃ�
#define DROP_ADVICSDATA "DROP TABLE m_advics;"
//ADVICS�m�[�h���e�[�u���̃f�[�^�𗎂Ƃ�
#define DROP_ADVICSNODE "DROP TABLE m_advicsnode;"
//��{�m�[�h���e�[�u���̃f�[�^�𗎂Ƃ�
#define DROP_BASICNODE "DROP TABLE m_basicnode;"
//��{�����N���e�[�u���̃f�[�^�𗎂Ƃ�
#define DROP_BASICLINK "DROP TABLE m_basiclink;"

//ADVICS�m�[�h���e�[�u�����쐬����B
#define DROP_ADVICSNODE_MIX "DROP TABLE m_advicsnode_mix;"

//m_VICSLINK�f�[�^�쐬 �i��Œ�������鎖)
#define INSERT_VICSLINK "insert into m_vicslink select distinct(ad.meshcode),ad.linktype,ad.vicslinkno,1,coalesce(startd.\"RoadID\",edd.\"RoadID\",0) as roadid,coalesce(startd.\"RoadSeqNo\",0) as startFacilNo,coalesce(edd.\"RoadSeqNo\",0) as endFacilNo,1000,ad.linktypefrom ((m_advics ad left join (select distinct(nd.\"MeshCode\"),nd.\"RoadCode\",	nd.\"RoadSeqNo\",nd.\"AllRoadNodeNo\",rp.\"FacilName\",mc1.\"RoadID\" from m_hwynode nd ,m_roadpoint rp,m_highway hw1,m_roadpaircode mc1 where nd.\"MeshCode\"=rp.\"RepMeshCode\" and nd.\"RoadCode\" = rp.\"RoadCode\" and nd.\"RoadCode\" =hw1.\"RoadCode\" and nd.\"RoadSeqNo\" = rp.\"RoadSeqNo\" and nd.\"RoadSeqNo\" = hw1.\"RoadSeqNo\" and nd.\"RoadCode\" = mc1.\"RoadCode\" and nd.\"DirFlag\" =hw1.\"Direction\" ) startd on ad.in_meshcode= startd.\"MeshCode\" and ad.in_nodeid = startd.\"AllRoadNodeNo\" ) left join ( select distinct(nd.\"MeshCode\"),nd.\"RoadCode\",nd.\"RoadSeqNo\",nd.\"AllRoadNodeNo\",rp.\"FacilName\",mc2.\"RoadID\" from m_hwynode nd ,m_roadpoint rp,m_highway hw2,m_roadpaircode mc2 where nd.\"MeshCode\"=rp.\"RepMeshCode\" and nd.\"RoadCode\" = rp.\"RoadCode\" and nd.\"RoadCode\" =hw2.\"RoadCode\" and nd.\"RoadSeqNo\" = rp.\"RoadSeqNo\" and nd.\"RoadSeqNo\" = hw2.\"RoadSeqNo\" and	nd.\"RoadCode\" = mc2.\"RoadCode\" and nd.\"DirFlag\" =hw2.\"Direction\" ) edd on ad.out_meshcode= edd.\"MeshCode\" and ad.out_nodeid = edd.\"AllRoadNodeNo\") where (ad.linktype=1 or ad.linktype=2) ;"
//m_vicslink_adf�f�[�^�쐬
//#define INSERT_VICSLINK_ADF "insert into m_vicslink_adf select distinct(ad.meshcode),ad.linktype,ad.vicslinkno,ad.seqno,coalesce(startd.\"RoadID\",0) as startroadid,coalesce(startd.\"RoadSeqNo\",0) as startFacilNo,coalesce(edd.\"RoadID\",0) as endroadid,coalesce(edd.\"RoadSeqNo\",0) as endFacilNo,0,ad.linktype from ((m_advicsnode ad left join (	select distinct(nd.\"MeshCode\"),nd.\"RoadCode\",nd.\"RoadSeqNo\",nd.\"AllRoadNodeNo\",rp.\"FacilName\",mc1.\"RoadID\" from m_hwynode nd ,m_roadpoint rp,m_highway hw1,m_roadpaircode mc1 where nd.\"RoadCode\" = rp.\"RoadCode\" and nd.\"RoadCode\" =hw1.\"RoadCode\" and nd.\"RoadSeqNo\" = rp.\"RoadSeqNo\" and	nd.\"RoadSeqNo\" = hw1.\"RoadSeqNo\" and nd.\"RoadCode\" = mc1.\"RoadCode\" and nd.\"DirFlag\" =hw1.\"Direction\") startd on ad.in_nodemeshcode= startd.\"MeshCode\" and ad.in_nodeid = startd.\"AllRoadNodeNo\") left join (	select distinct(nd.\"MeshCode\"),nd.\"RoadCode\",nd.\"RoadSeqNo\",nd.\"AllRoadNodeNo\",rp.\"FacilName\",mc2.\"RoadID\" from m_hwynode nd ,m_roadpoint rp,m_highway hw2,m_roadpaircode mc2 where nd.\"RoadCode\" = rp.\"RoadCode\" and nd.\"RoadCode\" =hw2.\"RoadCode\" and nd.\"RoadSeqNo\" = rp.\"RoadSeqNo\" and	nd.\"RoadSeqNo\" = hw2.\"RoadSeqNo\" and nd.\"RoadCode\" = mc2.\"RoadCode\" and nd.\"DirFlag\" =hw2.\"Direction\")edd on ad.out_nodemeshcode= edd.\"MeshCode\" and ad.out_nodeid = edd.\"AllRoadNodeNo\");"
#define INSERT_VICSLINK_ADF "insert into m_vicslink_adf select distinct(ad.meshcode),ad.linktype,ad.vicslinkno,ad.seqno,coalesce(startd.\"RoadID\",0) as startroadid,coalesce(startd.\"RoadSeqNo\",0) as startFacilNo,coalesce(edd.\"RoadID\",0) as endroadid,coalesce(edd.\"RoadSeqNo\",0) as endFacilNo,0,ad.linktype,coalesce(startd.\"Direction\",edd.\"Direction\",0) as direction from ((m_advicsnode ad left join ( select distinct(nd.\"MeshCode\"),nd.\"RoadCode\",nd.\"RoadSeqNo\",nd.\"AllRoadNodeNo\",rp.\"FacilName\",mc1.\"RoadID\",hw1.\"Direction\" from m_hwynode nd ,m_roadpoint rp,m_highway hw1,m_roadpaircode mc1 where nd.\"RoadCode\" = rp.\"RoadCode\" and nd.\"RoadCode\" =hw1.\"RoadCode\" and nd.\"RoadSeqNo\" = rp.\"RoadSeqNo\" and	nd.\"RoadSeqNo\" = hw1.\"RoadSeqNo\" and nd.\"RoadCode\" = mc1.\"RoadCode\" and nd.\"DirFlag\" =hw1.\"Direction\") startd on ad.in_nodemeshcode= startd.\"MeshCode\" and ad.in_nodeid = startd.\"AllRoadNodeNo\") left join ( select distinct(nd.\"MeshCode\"),nd.\"RoadCode\",nd.\"RoadSeqNo\",nd.\"AllRoadNodeNo\",rp.\"FacilName\",mc2.\"RoadID\",hw2.\"Direction\" from m_hwynode nd ,m_roadpoint rp,m_highway hw2,m_roadpaircode mc2 where nd.\"RoadCode\" = rp.\"RoadCode\" and nd.\"RoadCode\" =hw2.\"RoadCode\" and nd.\"RoadSeqNo\" = rp.\"RoadSeqNo\" and nd.\"RoadSeqNo\" = hw2.\"RoadSeqNo\" and nd.\"RoadCode\" = mc2.\"RoadCode\" and nd.\"DirFlag\" =hw2.\"Direction\")edd on ad.out_nodemeshcode= edd.\"MeshCode\" and ad.out_nodeid = edd.\"AllRoadNodeNo\");"


//Add by cuijun on 2011/12/10
//m_advicsnode_mix�f�[�^�쐬
#define INSERT_ADVICSNODE_MIX_ADF "insert into m_advicsnode_mix SELECT distinct(tem.meshcode), tem.linktype, tem.vicslinkno, tem.seqno, tem.nodenum, tem.in_meshid, tem.in_nodemeshcode, tem.in_nodeid, tem.out_meshid, tem.out_nodemeshcode, tem.out_nodeid, tem.link_length + tem.link_length2 AS linklen, tem.link_type, tem.road_only_flg, tem.toll_flg FROM ( SELECT sd.meshcode, sd.linktype, sd.vicslinkno, sd.nodenum, sd.seqno, sd.in_meshid, sd.in_nodemeshcode, sd.in_nodeid, sd.out_meshid, sd.out_nodemeshcode, sd.out_nodeid, sum(ln.link_length) AS link_length, 0 AS link_length2, ln.link_type, ln.road_only_flg, ln.toll_flg FROM ( SELECT ad.meshcode, ad.linktype, ad.vicslinkno, ad.nodenum, nd.seqno, nd.in_meshid, nd.in_nodemeshcode, nd.in_nodeid, nd.out_meshid, nd.out_nodemeshcode, nd.out_nodeid FROM m_advics ad, m_advicsnode nd WHERE ad.meshcode = nd.meshcode AND ad.linktype = nd.linktype AND ad.vicslinkno = nd.vicslinkno) sd JOIN m_basiclink ln ON sd.in_nodemeshcode = ln.meshcode AND sd.in_nodeid::text = lpad(ln.in_nodeid::text, 5, '0'::text) AND sd.out_nodemeshcode = ln.meshcode AND sd.out_nodeid::text = lpad(ln.out_nodeid::text, 5, '0'::text) GROUP BY sd.meshcode, sd.linktype, sd.vicslinkno, sd.nodenum, sd.seqno, sd.in_meshid, sd.in_nodemeshcode, sd.in_nodeid, sd.out_meshid, sd.out_nodemeshcode, sd.out_nodeid, ln.link_type, ln.road_only_flg, ln.toll_flg UNION SELECT sd.meshcode, sd.linktype, sd.vicslinkno, sd.nodenum, sd.seqno, sd.in_meshid, sd.in_nodemeshcode, sd.in_nodeid, sd.out_meshid, sd.out_nodemeshcode, sd.out_nodeid, 0, sum(ln2.link_length) AS link_length2, ln2.link_type, ln2.road_only_flg, ln2.toll_flg FROM ( SELECT ad.meshcode, ad.linktype, ad.vicslinkno, ad.nodenum, nd.seqno, nd.in_meshid, nd.in_nodemeshcode, nd.in_nodeid, nd.out_meshid, nd.out_nodemeshcode, nd.out_nodeid FROM m_advics ad, m_advicsnode nd WHERE ad.meshcode = nd.meshcode AND ad.linktype = nd.linktype AND ad.vicslinkno = nd.vicslinkno) sd JOIN m_basiclink ln2 ON sd.out_nodemeshcode = ln2.meshcode AND sd.out_nodeid::text = lpad(ln2.in_nodeid::text, 5, '0'::text) AND sd.in_nodemeshcode = ln2.meshcode AND sd.in_nodeid::text = lpad(ln2.out_nodeid::text, 5, '0'::text) GROUP BY sd.meshcode, sd.linktype, sd.vicslinkno, sd.nodenum, sd.seqno, sd.in_meshid, sd.in_nodemeshcode, sd.in_nodeid, sd.out_meshid, sd.out_nodemeshcode, sd.out_nodeid, ln2.link_type, ln2.road_only_flg, ln2.toll_flg) tem;"
//Add by cuijun on 2011/12/10


//�����N�����X�V�i��Œ�������鎖)
#define UPDATE_LENGTH "update m_vicslink set \"LinkLength\"=tem.link_length from ( select sd.meshcode,sd.linktype,sd.vicslinkno,sum(coalesce(ln.link_length,ln2.link_length)) as link_length from ((select ad.meshcode,ad.linktype,ad.vicslinkno,nd.seqno,nd.in_meshid,nd.in_nodemeshcode,nd.in_nodeid,nd.out_meshid,nd.out_nodemeshcode,nd.out_nodeid from m_advics ad,m_advicsnode nd where ad.meshcode=nd.meshcode and ad.linktype=nd.linktype and ad.vicslinkno=nd.vicslinkno and (ad.linktype=1 or ad.linktype=2 ) order by ad.meshcode,ad.linktype ,ad.vicslinkno,nd.seqno ) sd left join m_basiclink ln on sd.in_nodemeshcode=ln.meshcode and sd.in_nodeid =lpad(ln.in_nodeid,5,'0') and sd.out_nodemeshcode=ln.meshcode and sd.out_nodeid =lpad(ln.out_nodeid,5,'0')) left join m_basiclink ln2 on sd.out_nodemeshcode=ln2.meshcode and sd.out_nodeid =lpad(ln2.in_nodeid,5,'0') and sd.in_nodemeshcode=ln2.meshcode and sd.in_nodeid =lpad(ln2.out_nodeid,5,'0') group by sd.meshcode,sd.linktype ,sd.vicslinkno) tem where m_vicslink.\"MeshNo\" = tem.meshcode and m_vicslink.\"VicsLinkType\" = tem.linktype and m_vicslink.\"VicsLinkNo\" = tem.vicslinkno;"

#define UPDATE_LENGTH�QADF "update m_vicslink_adf set \"LinkLength\"=tem2.linklen from ( select tem.meshcode,tem.linktype,tem.vicslinkno,tem.seqno ,(tem.link_length +tem.link_length2 ) as linklen from ( select sd.meshcode,sd.linktype,sd.vicslinkno,sd.seqno,sum(ln.link_length) as link_length,0 as link_length2 from (select ad.meshcode,ad.linktype,ad.vicslinkno,nd.seqno,nd.in_meshid,nd.in_nodemeshcode,nd.in_nodeid ,nd.out_meshid ,nd.out_nodemeshcode ,nd.out_nodeid from m_advics ad,m_advicsnode nd where ad.meshcode=nd.meshcode and ad.linktype=nd.linktype and ad.vicslinkno=nd.vicslinkno ) sd join m_basiclink ln on sd.in_nodemeshcode=ln.meshcode and sd.in_nodeid =lpad(ln.in_nodeid,5,'0') and sd.out_nodemeshcode=ln.meshcode and sd.out_nodeid =lpad(ln.out_nodeid,5,'0') group by   sd.meshcode,sd.linktype ,sd.vicslinkno,sd.seqno union select sd.meshcode,sd.linktype ,sd.vicslinkno,sd.seqno,0,sum(ln2.link_length) as link_length2 from (select ad.meshcode,ad.linktype,ad.vicslinkno,nd.seqno,nd.in_meshid,nd.in_nodemeshcode,nd.in_nodeid,nd.out_meshid,nd.out_nodemeshcode,nd.out_nodeid from m_advics ad,m_advicsnode nd where ad.meshcode=nd.meshcode and ad.linktype=nd.linktype and ad.vicslinkno=nd.vicslinkno ) sd join m_basiclink ln2 on sd.out_nodemeshcode=ln2.meshcode and sd.out_nodeid =lpad(ln2.in_nodeid,5,'0') and sd.in_nodemeshcode=ln2.meshcode and sd.in_nodeid =lpad(ln2.out_nodeid,5,'0')group by sd.meshcode,sd.linktype ,sd.vicslinkno ,sd.seqno) tem ) tem2 where m_vicslink_adf.\"MeshNo\" = tem2.meshcode and m_vicslink_adf.\"VicsLinkType\" = tem2.linktype and m_vicslink_adf.\"VicsLinkNo\" = tem2.vicslinkno and m_vicslink_adf.\"Seq\" = tem2.seqno;"



//�O���{�ݏ�񌟍��A�o�^
#define UPDATE_BEFORE_FACIL "update m_vicslink set \"RoadID\"=se1.roadid,\"StartFacilityID\" =se1.startfacilno from (select distinct(vn.meshcode),vn.linktype,vn.vicslinkno,tep.roadid,tep.startfacilno from (select vf.meshcode,vf.linktype,vf.vicslinkno,vf.in_meshcode,vf.in_nodeid,vf.out_meshcode,vf.out_nodeid,vf.roadid,vf.startfacilname,vf.startfacilno,vf.endfacilname,vf.endfacilno,case when node.meshcode2nd <>0 then node.meshcode2nd else vf.in_meshcode end as m_code,case when node.nodeid2nd <>'0000' then node.nodeid2nd else vf.in_nodeid end as n_id from v_vicsfacildata vf,m_basicnode node where vf.in_meshcode=node.meshcode and vf.in_nodeid=lpad(node.nodeid,5,'0') and vf.startfacilno =0) vn,v_vicsfacildata tep where vn.m_code=tep.out_meshcode and lpad(vn.n_id,5,'0') =tep.out_nodeid and tep.startfacilno <>0 ) se1 where m_vicslink.\"MeshNo\"=se1.meshcode and m_vicslink.\"VicsLinkType\"=se1.linktype and m_vicslink.\"VicsLinkNo\"=se1.vicslinkno;"
#define UPDATE_AFTER_FACIL "update m_vicslink set \"RoadID\"=se1.roadid,\"EndFacilityID\" =se1.endfacilno from (select distinct(vn.meshcode),vn.linktype,vn.vicslinkno,tep.roadid,tep.endfacilno from (select vf.meshcode,vf.linktype,vf.vicslinkno,vf.in_meshcode,vf.in_nodeid,vf.out_meshcode,vf.out_nodeid,vf.roadid,vf.startfacilname,vf.startfacilno,vf.endfacilname,vf.endfacilno,case when node.meshcode2nd <>0 then node.meshcode2nd else vf.out_meshcode end as m_code,case when node.nodeid2nd <>'0000' then node.nodeid2nd else vf.out_nodeid end as n_id from v_vicsfacildata vf,m_basicnode node where vf.out_meshcode=node.meshcode and	vf.out_nodeid=lpad(node.nodeid,5,'0') and vf.endfacilno =0) vn,v_vicsfacildata tep where vn.m_code=tep.in_meshcode and lpad(vn.n_id,5,'0') =tep.in_nodeid and tep.endfacilno <>0 ) se1 where m_vicslink.\"MeshNo\"=se1.meshcode and m_vicslink.\"VicsLinkType\"=se1.linktype and m_vicslink.\"VicsLinkNo\"=se1.vicslinkno;"

#define UPDATE_AFTER_FACIL_ADF5 "update m_vicslink_adf set \"EndRoadID\"=se1.endroadid,\"EndFacilityID\" =se1.endfacilno,\"Direction\" =coalesce(se1.startdirection,se1.enddirection,se1.\"Direction\",0) from ( select distinct(vn.meshcode),vn.linktype,vn.vicslinkno,vn.\"Seq\",vn.startdirection,tep.startroadid,tep.startfacilno,tep.endroadid,tep.endfacilno,tep.enddirection,tep.\"Direction\" from ( select vf.meshcode,vf.linktype,vf.vicslinkno,vf.\"Seq\",vf.nodenum, vf.link_type, vf.road_only_flg,vf.toll_flg,vf.in_nodemeshcode,vf.in_nodeid,node.nodetype,vf.out_nodemeshcode,vf.out_nodeid,vf.startdirection,vf.startroadid,vf.startfacilname,vf.startfacilno,vf.endroadid,vf.endfacilname,vf.endfacilno,case when node.meshcode2nd <>0 then node.meshcode2nd else vf.out_nodemeshcode end as m_code,case when node.nodeid2nd <>'0000' then node.nodeid2nd else vf.out_nodeid  end as n_id from v_vicsfacildata_adf4_1 vf,m_basicnode node where vf.out_nodemeshcode=node.meshcode and vf.out_nodeid=lpad(node.nodeid,5,'0') and vf.endfacilno =0 and vf.\"Seq\"=vf.nodenum-2 and (vf.road_only_flg =1 or vf.toll_flg=1) and (vf.link_type=1 or vf.link_type=2)) vn,v_vicsfacildata_adf4_1 tep where vn.m_code=tep.in_nodemeshcode and lpad(vn.n_id,5,'0') =tep.in_nodeid and tep.endfacilno <>0 and tep.\"Seq\"=0 and (tep.road_only_flg =1 or tep.toll_flg=1)) se1 where m_vicslink_adf.\"MeshNo\"=se1.meshcode and m_vicslink_adf.\"VicsLinkType\"=se1.linktype and m_vicslink_adf.\"VicsLinkNo\"=se1.vicslinkno and m_vicslink_adf.\"Seq\"=se1.\"Seq\";"

#define UPDATE_BEFORE_FACIL_ADF5 "update m_vicslink_adf set \"StartRoadID\"=se1.startroadid,\"StartFacilityID\" =se1.startfacilno,\"Direction\" =coalesce(se1.enddirection,se1.startdirection,se1.\"Direction\",0), \"RoadSeqNo\"= coalesce(se1.\"RoadSeqNo\"+1,NULL)  from ( select distinct(vn.meshcode),vn.linktype,vn.vicslinkno,vn.\"Seq\",vn.enddirection,tep.startdirection,tep.startroadid,tep.startfacilno,tep.endroadid,tep.endfacilno,tep.\"Direction\",tep.\"RoadSeqNo\" from (select vf.meshcode,vf.linktype,vf.vicslinkno,vf.\"Seq\",vf.nodenum, vf.link_type, vf.road_only_flg,vf.toll_flg,vf.in_nodemeshcode,vf.in_nodeid,vf.out_nodemeshcode,vf.out_nodeid,vf.startroadid,vf.startfacilname,vf.startfacilno,vf.enddirection,vf.endroadid,vf.endfacilname,vf.endfacilno,case when node.meshcode2nd <>0 then node.meshcode2nd else vf.in_nodemeshcode end as m_code, case when node.nodeid2nd <>'0000' then node.nodeid2nd else vf.in_nodeid end as n_id,vf.\"RoadSeqNo\" from v_vicsfacildata_adf4_1 vf,m_basicnode node where vf.in_nodemeshcode=node.meshcode and vf.in_nodeid=lpad(node.nodeid,5,'0') and vf.startfacilno =0 and vf.\"Seq\"=0 and	(vf.road_only_flg =1 or vf.toll_flg=1) and (vf.link_type=1 or vf.link_type=2)) vn,v_vicsfacildata_adf4_1 tep where vn.m_code=tep.out_nodemeshcode and lpad(vn.n_id,5,'0') =tep.out_nodeid and	tep.startfacilno <>0  and tep.\"Seq\"=tep.nodenum-2 and (tep.road_only_flg =1 or tep.toll_flg=1)) se1 where m_vicslink_adf.\"MeshNo\"=se1.meshcode and m_vicslink_adf.\"VicsLinkType\"=se1.linktype and m_vicslink_adf.\"VicsLinkNo\"=se1.vicslinkno and m_vicslink_adf.\"Seq\"=se1.\"Seq\";"

/*
#define UPDATE_NODE_CROSS "update m_vicslink_adf set \"EndRoadID\"=se1.\"EndRoadID\",\"EndFacilityID\" =se1.\"EndFacilityID\" from (select v1.\"MeshNo\",v1.\"VicsLinkType\",v1.\"VicsLinkNo\",v1.\"Seq\",v2.\"EndRoadID\",v2.\"EndFacilityID\" from m_vicslink_adf v1 join m_vicslink_adf v2 on v1.\"MeshNo\"= v2.\"MeshNo\" and v1.\"VicsLinkType\"=v2.\"VicsLinkType\" and v1.\"VicsLinkNo\"=v2.\"VicsLinkNo\" and v2.\"Seq\"=v1.\"Seq\"+1 and v1.\"StartFacilityID\" <> 0 and v1.\"EndFacilityID\" =0 and v2.\"StartFacilityID\" = 0 and v2.\"EndFacilityID\" <> 0 ) se1 where m_vicslink_adf.\"MeshNo\"=se1.\"MeshNo\" and m_vicslink_adf.\"VicsLinkType\"=se1.\"VicsLinkType\" and m_vicslink_adf.\"VicsLinkNo\"=se1.\"VicsLinkNo\" and m_vicslink_adf.\"Seq\"=se1.\"Seq\";"

#define UPDATE_NODE_CROSS_2 "update m_vicslink_adf set \"StartRoadID\"=se1.\"StartRoadID\",\"StartFacilityID\" =se1.\"StartFacilityID\",\"Direction\" = se1.\"Direction\" from (select v1.\"MeshNo\",v1.\"VicsLinkType\",v1.\"VicsLinkNo\",v2.\"Seq\",v1.\"StartRoadID\",v1.\"StartFacilityID\",v1.\"Direction\" from m_vicslink_adf v1 join m_vicslink_adf v2 on v1.\"MeshNo\"= v2.\"MeshNo\" and v1.\"VicsLinkType\"=v2.\"VicsLinkType\" and v1.\"VicsLinkNo\"=v2.\"VicsLinkNo\" and v2.\"Seq\"=v1.\"Seq\"+1 and v1.\"StartFacilityID\" <> 0 and v1.\"EndFacilityID\" <>0 and v2.\"StartFacilityID\" = 0 and v2.\"EndFacilityID\" <> 0 and v1.\"EndFacilityID\"= v2.\"EndFacilityID\" ) se1 where m_vicslink_adf.\"MeshNo\"=se1.\"MeshNo\" and m_vicslink_adf.\"VicsLinkType\"=se1.\"VicsLinkType\" and m_vicslink_adf.\"VicsLinkNo\"=se1.\"VicsLinkNo\" and m_vicslink_adf.\"Seq\"=se1.\"Seq\";"

#define UPDATE_NODE_TAIL "update m_vicslink_adf set \"StartRoadID\"=se1.\"StartRoadID\",\"StartFacilityID\" =se1.\"StartFacilityID\",\"Direction\" = se1.\"Direction\" from (select v1.\"MeshNo\",v1.\"VicsLinkType\",v1.\"VicsLinkNo\",v2.\"Seq\",v1.\"StartRoadID\",v1.\"StartFacilityID\",v1.\"Direction\" from m_vicslink_adf v1 join m_vicslink_adf v2 on v1.\"MeshNo\"= v2.\"MeshNo\" and v1.\"VicsLinkType\"=v2.\"VicsLinkType\" and v1.\"VicsLinkNo\"=v2.\"VicsLinkNo\" and v2.\"Seq\"=v1.\"Seq\"+1 and v1.\"StartFacilityID\" <> 0 and v1.\"EndFacilityID\" =0 and v2.\"StartFacilityID\" = 0 and v2.\"EndFacilityID\" = 0 ) se1 where m_vicslink_adf.\"MeshNo\"=se1.\"MeshNo\" and m_vicslink_adf.\"VicsLinkType\"=se1.\"VicsLinkType\" and m_vicslink_adf.\"VicsLinkNo\"=se1.\"VicsLinkNo\" and m_vicslink_adf.\"Seq\"=se1.\"Seq\";"

#define UPDATE_NODE_HEAD "update m_vicslink_adf set \"EndRoadID\"=se1.\"EndRoadID\",\"EndFacilityID\" =se1.\"EndFacilityID\" from ( select v1.\"MeshNo\",v1.\"VicsLinkType\",v1.\"VicsLinkNo\",v1.\"Seq\",v2.\"EndRoadID\", v2.\"EndFacilityID\"  from m_vicslink_adf v1 join m_vicslink_adf v2 on v1.\"MeshNo\"= v2.\"MeshNo\" and v1.\"VicsLinkType\"=v2.\"VicsLinkType\" and v1.\"VicsLinkNo\"=v2.\"VicsLinkNo\" and v2.\"Seq\"=v1.\"Seq\"+1 and v1.\"StartFacilityID\" <> 0 and v1.\"EndFacilityID\" =0 and v2.\"StartFacilityID\" <> 0 and v2.\"EndFacilityID\" <> 0 and v1.\"StartFacilityID\"= v2.\"StartFacilityID\" ) se1 where m_vicslink_adf.\"MeshNo\"=se1.\"MeshNo\" and m_vicslink_adf.\"VicsLinkType\"=se1.\"VicsLinkType\" and m_vicslink_adf.\"VicsLinkNo\"=se1.\"VicsLinkNo\" and m_vicslink_adf.\"Seq\"=se1.\"Seq\";"
*/
#define UPDATE_NODE_CROSS "update m_vicslink_adf set \"EndRoadID\"=se1.\"EndRoadID\",\"EndFacilityID\" =se1.\"EndFacilityID\" from (select v1.\"MeshNo\",v1.\"VicsLinkType\",v1.\"VicsLinkNo\",v1.\"Seq\",v2.\"EndRoadID\",v2.\"EndFacilityID\" from m_vicslink_adf v1 join m_vicslink_adf v2 on v1.\"MeshNo\"= v2.\"MeshNo\" and v1.\"VicsLinkType\"=v2.\"VicsLinkType\" and v1.\"VicsLinkNo\"=v2.\"VicsLinkNo\" and v2.\"Seq\"=v1.\"Seq\"+1 and v1.\"StartFacilityID\" <> 0 and v1.\"EndFacilityID\" =0 and v2.\"StartFacilityID\" = 0 and v2.\"EndFacilityID\" <> 0 ) se1 where m_vicslink_adf.\"MeshNo\"=se1.\"MeshNo\" and m_vicslink_adf.\"VicsLinkType\"=se1.\"VicsLinkType\" and m_vicslink_adf.\"VicsLinkNo\"=se1.\"VicsLinkNo\" and m_vicslink_adf.\"Seq\"=se1.\"Seq\";"

#define UPDATE_NODE_CROSS_2 "update m_vicslink_adf set \"StartRoadID\"=se1.\"StartRoadID\",\"StartFacilityID\" =se1.\"StartFacilityID\",\"Direction\" = se1.\"Direction\",\"RoadSeqNo\" =se1.\"RoadSeqNo\" from (select v1.\"MeshNo\",v1.\"VicsLinkType\",v1.\"VicsLinkNo\",v2.\"Seq\",v1.\"StartRoadID\",v1.\"StartFacilityID\",v1.\"Direction\",v1.\"RoadSeqNo\" from m_vicslink_adf v1 join m_vicslink_adf v2 on v1.\"MeshNo\"= v2.\"MeshNo\" and v1.\"VicsLinkType\"=v2.\"VicsLinkType\" and v1.\"VicsLinkNo\"=v2.\"VicsLinkNo\" and v2.\"Seq\"=v1.\"Seq\"+1 and v1.\"StartFacilityID\" <> 0 and v1.\"EndFacilityID\" <>0 and v2.\"StartFacilityID\" = 0 and v2.\"EndFacilityID\" <> 0 and v1.\"EndFacilityID\"= v2.\"EndFacilityID\" ) se1 where m_vicslink_adf.\"MeshNo\"=se1.\"MeshNo\" and m_vicslink_adf.\"VicsLinkType\"=se1.\"VicsLinkType\" and m_vicslink_adf.\"VicsLinkNo\"=se1.\"VicsLinkNo\" and m_vicslink_adf.\"Seq\"=se1.\"Seq\";"

#define UPDATE_NODE_TAIL "update m_vicslink_adf set \"StartRoadID\"=se1.\"StartRoadID\",\"StartFacilityID\" =se1.\"StartFacilityID\",\"Direction\" = se1.\"Direction\" ,\"RoadSeqNo\" =se1.\"RoadSeqNo\" from (select v1.\"MeshNo\",v1.\"VicsLinkType\",v1.\"VicsLinkNo\",v2.\"Seq\",v1.\"StartRoadID\",v1.\"StartFacilityID\",v1.\"Direction\",v1.\"RoadSeqNo\" from m_vicslink_adf v1 join m_vicslink_adf v2 on v1.\"MeshNo\"= v2.\"MeshNo\" and v1.\"VicsLinkType\"=v2.\"VicsLinkType\" and v1.\"VicsLinkNo\"=v2.\"VicsLinkNo\" and v2.\"Seq\"=v1.\"Seq\"+1 and v1.\"StartFacilityID\" <> 0 and v1.\"EndFacilityID\" =0 and v2.\"StartFacilityID\" = 0 and v2.\"EndFacilityID\" = 0 ) se1 where m_vicslink_adf.\"MeshNo\"=se1.\"MeshNo\" and m_vicslink_adf.\"VicsLinkType\"=se1.\"VicsLinkType\" and m_vicslink_adf.\"VicsLinkNo\"=se1.\"VicsLinkNo\" and m_vicslink_adf.\"Seq\"=se1.\"Seq\";"

#define UPDATE_NODE_HEAD "update m_vicslink_adf set \"EndRoadID\"=se1.\"EndRoadID\",\"EndFacilityID\" =se1.\"EndFacilityID\",\"RoadSeqNo\" =se1.\"RoadSeqNo\" from ( select v1.\"MeshNo\",v1.\"VicsLinkType\",v1.\"VicsLinkNo\",v1.\"Seq\",v2.\"EndRoadID\", v2.\"EndFacilityID\",v2.\"RoadSeqNo\"  from m_vicslink_adf v1 join m_vicslink_adf v2 on v1.\"MeshNo\"= v2.\"MeshNo\" and v1.\"VicsLinkType\"=v2.\"VicsLinkType\" and v1.\"VicsLinkNo\"=v2.\"VicsLinkNo\" and v2.\"Seq\"=v1.\"Seq\"+1 and v1.\"StartFacilityID\" <> 0 and v1.\"EndFacilityID\" =0 and v2.\"StartFacilityID\" <> 0 and v2.\"EndFacilityID\" <> 0 and v1.\"StartFacilityID\"= v2.\"StartFacilityID\" ) se1 where m_vicslink_adf.\"MeshNo\"=se1.\"MeshNo\" and m_vicslink_adf.\"VicsLinkType\"=se1.\"VicsLinkType\" and m_vicslink_adf.\"VicsLinkNo\"=se1.\"VicsLinkNo\" and m_vicslink_adf.\"Seq\"=se1.\"Seq\";"

#define UPDATE_ZERO_SET1 "UPDATE m_vicslink_adf SET \"RoadSeqNo\" = 0 where m_vicslink_adf.\"StartRoadID\" <> 0 and m_vicslink_adf.\"EndRoadID\" <> 0 and m_vicslink_adf.\"StartRoadID\" = m_vicslink_adf.\"EndRoadID\" and m_vicslink_adf.\"StartFacilityID\" <> m_vicslink_adf.\"EndFacilityID\";"

#define UPDATE_ZERO_SET2 "UPDATE m_vicslink_adf SET \"RoadSeqNo\" = 0 WHERE m_vicslink_adf.\"StartRoadID\" <> 0 and m_vicslink_adf.\"EndRoadID\" = 0 and m_vicslink_adf.\"StartFacilityID\" <> 0  and m_vicslink_adf.\"EndFacilityID\" =0;"

	//�m�[�h���
	struct posdata
	{
		int mesh_code;
		char node_id[5];
		//POINT seiki_pos;
		int seiki_pos_x;
		int seiki_pos_y;

		double pos_x;
		double pos_y;


		int  node_type;

		int  mesh_code_2nd;
		char node_id_2nd[5];

		int link_num;
		
		char jt_point[8][5];
//		int  jt_code[8];
		char  jt_code[8][9];//�ݒ��int�����A�����̓s����char���g�p
		int	 jt_ang[8];

		int cross_name_len;
		char cross_name[21];
		int cross_kana_len;
		char cross_kana_name[21];


		int   cont_flg;
//		POINT startpos;
		int startpos_x;
		int startpos_y;

		int   write_flg;

		
		//posdata(int a=0,char b=""):mesh_code(a),node_id(b){}

		//operator==(const posdata &a) const{
		//	return mesh_code == a.mesh_code ;
		//}

	};


struct TPosEquals {
  explicit TPosEquals(const int& s,const char& b): mesh_code(s){  memset(node_id,0,sizeof(node_id));memcpy(node_id,&b,sizeof(node_id));}
  bool operator ()(const posdata& pos){
    return (pos.mesh_code == mesh_code && 0==memcmp(pos.node_id,node_id,sizeof(node_id)));
  }
  int mesh_code;
  char node_id[5];
};

	//�����N���
	struct linkdata
	{
		int mesh_code;

		char node_1[5];
		char node_2[5];

		int link_length;
		int link_type;
		int	line_num;
//		POINT startpos;
		int startpos_x;
		int startpos_y;

		//POINT hosepas[19];
		//POINT endpos;
		int endpos_x;
		int endpos_y;

		int   road_code;
		int   road_no;
		int   master_code;

		int	road_hukuin_code;
		int	road_syasen;
		int	road_hukuin;

		int	traffic_data;
		int ryoko_speed;

		int   cont_flg;
		int   road_only_flg;
		int   toll_flg;
	};


	struct node_line
	{
		int mesh_id;
		int node_mesh_code;
		char node_id[6];
	};

	//ADVICS���
	struct vicslinedata
	{
		//POINT node1_pos;
		//int node1_mesh_no;

		//POINT node2_pos;
		//int node2_mesh_no;


		int mesh_code;
		int record_no;
		int link_type;
		int vics_link;
		int update_code;
		int addlink_code;
		node_line indata;
		int in_node_type;
		int in_cross_type;

		node_line outdata;
		int out_node_type;
		int out_cross_type;

		int node_num;
		node_line linkdata[37];
		int   cont_flg;

		int check_flg;

	};

	//�m�[�h�������
	struct attrdata
	{
		int attr_type_no;
		int attr_type_code;
		int attr_level_code;
		int attr_start_node_no;
		int attr_start_con_code;
		int attr_end_node_no;
		int attr_end_con_code;
		int attr_name_len;
		char attr_name[21];
		int attr_kana_len;
		char attr_kana[21];
	};
	//�����N����
	struct link_attr
	{
		int mesh_code;

		char node_1[5];
		char node_2[5];

		int record_no;
		int attr_type_num;

		//int attr_type_no;
		attrdata atdata[3];

		int   cont_flg;
	};

	struct pos{
		int x ;
		int y ;
	} ;

	//�o�H�T���p
	//���n���
	struct suidata
	{
		int mesh_code;
		int item_no;
		int item_record;
		int	sui_type;
		int	sui_num;
		int sui_code[21];
		pos sui_pos[21];
		int	lv_flg;
		int	cont_flg;
	};
