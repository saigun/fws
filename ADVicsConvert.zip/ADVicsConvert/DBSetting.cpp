#include "StdAfx.h"

#include "DBSetting.h"
#include <stdio.h>
#include <iostream>

#include <algorithm>

#pragma warning (disable : 4267)
#pragma warning (disable : 4800)
#pragma warning (disable : 4996)



DBSetting::DBSetting(void)
: STMT_INSERT_ADVICS("ins_advics"),
  STMT_INSERT_ADVICSNODE("ins_advicsnode"),
  STMT_INSERT_BASICNODE("ins_basicnode"),
  STMT_INSERT_BASICLINK("ins_basiclink"),
  STMT_INSERT_BASICLINKATTR("ins_basiclinkattr"),
  STMT_INSERT_WATER("ins_water"),
  STMT_INSERT_WATER1("ins_water"),
  STMT_INSERT_WATER_POLY("ins_waterpoly")
{
	con_flg=0;
	line_flg=0;
}

DBSetting::~DBSetting(void)
{
}

int DBSetting::Connection()
{
	int ret = CONV_CONNECTION_ERROR;
    // DB�ڑ�
    con = PQsetdbLogin(DB_HOST,DB_PORT,DB_OPTIONS,DB_TTY,DB_NAME,DB_USERNAME,DB_PASSWORD);

    // �ڑ��Ɏ��s
    if ( PQstatus(con) == CONNECTION_BAD ){
        fprintf(stderr,"%s",PQerrorMessage(con));
		printf("�R�l�N�V�����Ɏ��s���܂����B");
        goto fin;
    }

	// �N���C�A���g�̕����R�[�h��ݒ�
//	if( PQsetClientEncoding( con, "UTF8" ) != 0 )
//	{
		//Logger::write<Logger::ERROR>("MapDB::%s : %s", __FUNCTION__, PQerrorMessage(con));
//		return ret;
//	}
	//Logger::write<Logger::TRACE>("MapDB::%s [%s][%s][%s][%s][%s] END", __FUNCTION__, dbname,user,pass,host,port);


	ret = CONV_SUCCESS;
fin:
	return ret;
}

/**
 * �f�[�^�x�[�X�ؒf�֐�
 *
 * @retval true		����I��
 * @retval false	�ُ�I��
 */
bool DBSetting::disconnect()
{
	// �ڑ���Ԃ��m�F
	if( con == NULL )
	{
		//Logger::write<Logger::WARN>("MapDB::%s : already disconnection", __FUNCTION__);
		return true;
	}

	// �ڑ���Ԃ�����
	PQfinish(con);
	con = NULL;

	return true;
}

/**
 * �g�����U�N�V�����J�n
 *
 * @retval true		����I��
 * @retval false	�ُ�I��
 */
bool DBSetting::begin()
{
	// �g�����U�N�V�����J�n
	PGresult* res = PQexec(con, "BEGIN");
	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("MapDBWriter::%s : %s", __FUNCTION__, PQresultErrorMessage(res));

		// �������̉��
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);

	return true;
}

/**
 * �g�����U�N�V�����m��
 *
 * @retval true		����I��
 * @retval false	�ُ�I��
 */
bool DBSetting::commit()
{
	// �g�����U�N�V�����I��
	PGresult* res = PQexec(con, "COMMIT");
	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("MapDBWriter::%s : %s", __FUNCTION__, PQresultErrorMessage(res));

		// �������̉��
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);
	
	return true;
}

/**
 * ���[���o�b�N
 *
 * @retval true		����I��
 * @retval false	�ُ�I��
 */
bool DBSetting::rollback()
{
	// �g�����U�N�V�����I��
	PGresult* res = PQexec(con, "ROLLBACK");
	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));

		// �������̉��
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);

	return true;
}

void DBSetting::pqclear(PGresult **res)
{
	if(*res == NULL)
	{
		return;
	}

	PQclear(*res);
	*res = NULL;
}

bool DBSetting::executSql(string sql)//add by cuijun
{

	bool ret = true;
	PGresult* res = PQexec(con, sql.c_str());
	int sts = PQresultStatus(res); 
	if( res == NULL || 
		sts == PGRES_BAD_RESPONSE ||
		sts == PGRES_NONFATAL_ERROR ||
		sts == PGRES_FATAL_ERROR
	  )
	{
		printf("!!Error: sql=%s", sql);
		ret = false;
	}

	pqclear(&res);

	return ret;
}

bool DBSetting::isTableExist(string tableName)//add by cuijun
{
	string checkTableSql = "SELECT relname FROM pg_class WHERE relkind = 'r' AND relname = '" + tableName + "'";
	
	//�e�[�u���̑��݂��m�F
	return executSql(checkTableSql);
}

//add by cuijun
bool DBSetting::cleartable(string tableName)
{
	string clearTableSql = "truncate table " + tableName;

	//�e�[�u���Ł[�����폜
	return executSql(clearTableSql);
}

//add by cuijun
bool DBSetting::createtable(string tableName, string createtableSql)
{
	
	//�e�[�u���̑��݂��m�F
	bool ret = isTableExist(tableName);
	if(ret == false)
	{
		//�e�[�u����V�K�쐬
		ret = executSql(createtableSql);
	}
	else
	{
		//�e�[�u���Ł[�����폜
		ret = cleartable(tableName);
	}

	return ret;
}

bool DBSetting::createTmpView(string viewName, string createViewSql)
{
	//�e�[�u���̑��݂��m�F
	bool ret = isTableExist(viewName);
	if(ret == false)
	{
		//�e�[�u����V�K�쐬
		ret = executSql(createViewSql);
	}

	return ret;
	
}


//�Z�d�f�[�^�o�^�p�e�[�u���쐬
bool DBSetting::createtable()
{
	//���o�ׁ̈A�ꎞ�e�[�u�����쐬

	PGresult* res = PQexec(con, CREATE_BASICNODE);
	int sts = PQresultStatus(res); 
	if( res == NULL || sts != PGRES_COMMAND_OK )
	{

		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		// �������̉��
		if( res != NULL )
		{
			pqclear(&res);
		}
		return false;
	}
	res = PQexec(con, CREATE_BASICLINK);
	sts = PQresultStatus(res);
	if( res == NULL || sts != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		// �������̉��
		if( res != NULL )
		{
			pqclear(&res);
		}
		return false;
	}

	res = PQexec(con, CREATE_ADVICS);
	sts = PQresultStatus(res);
	if( res == NULL || sts != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		// �������̉��
		if( res != NULL )
		{
			pqclear(&res);
		}
		return false;
	}

	res = PQexec(con, CREATE_ADVICSNODE);
	sts = PQresultStatus(res);
	if( res == NULL || sts != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		// �������̉��
		if( res != NULL )
		{
			pqclear(&res);
		}
		return false;
	}
	res = PQexec(con, CREATE_ADVICSNODE_MIX);
	sts = PQresultStatus(res);
	if( res == NULL || sts != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		// �������̉��
		if( res != NULL )
		{
			pqclear(&res);
		}
		return false;
	}
	res = PQexec(con, CREATE_VICSFACIL_VIEW);
	sts = PQresultStatus(res);
	if( res == NULL || sts != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		// �������̉��
		if( res != NULL )
		{
			pqclear(&res);
		}
		return false;
	}

	//CREATE_VICSFACILDATA_VIEW�ŗp�����Ă���vicslink_adf�̃X�L�[�}��񂪌Â����߁A��Ŋm�F�K�v�B
	res = PQexec(con, CREATE_VICSFACILDATA_VIEW);
	sts = PQresultStatus(res);
	if( res == NULL || sts != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		// �������̉��
		if( res != NULL )
		{
			pqclear(&res);
		}

		return false;
	}

	pqclear(&res);

	return true;
}

//�Z�d�f�[�^�o�^�p�e�[�u���폜
bool DBSetting::droptable()
{
	bool ret = true;

	//���o�ׂ̈̈ꎞ�e�[�u�����폜

	PGresult* res = PQexec(con, DROP_VICSFACILDATA_VIEW);
	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		// �������̉��
		if( res != NULL )	PQclear(res);
		
		ret = false;
		printf("Failing delete:[%s]!",DROP_VICSFACILDATA_VIEW);

		//return false;
	}

	res = PQexec(con, DROP_VICSFACIL_VIEW);
	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		// �������̉��
		if( res != NULL )	PQclear(res);
		
		ret = false;
		printf("Failing delete:[%s]!",DROP_VICSFACIL_VIEW);
		//return false;
	}


	res = PQexec(con, DROP_BASICNODE);
	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		// �������̉��
		if( res != NULL )	PQclear(res);

		ret = false;
		printf("Failing delete:[%s]!",DROP_BASICNODE);
		//return false;
	}
	res = PQexec(con, DROP_BASICLINK);
	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		// �������̉��

		ret = false;
		printf("Failing delete:[%s]!",DROP_BASICLINK);
		//return false;
	}

	res = PQexec(con, DROP_ADVICSDATA);
	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		// �������̉��
		if( res != NULL )	PQclear(res);

		ret = false;
		printf("Failing delete:[%s]!", DROP_ADVICSDATA);
		//return false;
	}

	res = PQexec(con, DROP_ADVICSNODE);
	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		// �������̉��
		if( res != NULL )	PQclear(res);

		ret = false;
		printf("Failing delete:[%s]!", DROP_ADVICSNODE);
		//return false;
	}
	res = PQexec(con, DROP_ADVICSNODE_MIX);
	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("DBSetting::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		// �������̉��
		if( res != NULL )	PQclear(res);

		ret = false;
		printf("Failing delete:[%s]!", DROP_ADVICSNODE_MIX);
		//return false;
	}


	PQclear(res);
	//return true;
	return ret;

}

//DB�o�^�Ɏg�p����SQL����Ԋ҂���B
bool DBSetting::prepare_advics_insert()
{
	// ���sSQL��
//	const char* sqls =
//		" INSERT INTO m_advics "
//		" VALUES($1::int, $2::int, $3::int, $4::int, $5::int, $6::int, $7::int,$8::char,$9::int,$10::int,"
//		" VALUES($11::int, $12::char, $13::int, $14::int, $15::int, $16::int, $17::char,$18::int,$19::char,$20::int,"
//		" VALUES($21::char, $22::int, $23::char, $24::int, $25::char, $26::int, $27::char,$28::int,$29::char,$30::int,"
//		" VALUES($31::char, $32::int, $33::char, $34::int, $35::char, $36::int, $37::char,$38::int,$39::char,$40::int,"
//		" VALUES($41::char, $42::int, $43::char, $44::int, $45::char, $46::int, $47::char,$48::int,$49::char,$50::int,"
//		" VALUES($51::char, $52::int, $53::char, $54::int, $55::char, $56::int, $57::char,$58::int,$59::char,$60::int,"
//		" VALUES($61::char, $62::int, $63::char, $64::int, $65::char, $66::int, $67::char,$68::int,$69::char,$70::int"
//		")";

//	const char* sqls =
//		" INSERT INTO m_advics "
//		" ( meshcode ,recordno ,linktype ,vicslinkno , updatecode , addlinkcode , in_meshid ,"
//        " in_nodeid , in_nodetype , in_crosstype , out_meshid , out_nodeid , out_nodetype , out_crosstype ,"
//        " nodenum ,contflag) "
//		" VALUES($1::int, $2::int, $3::int, $4::int, $5::int, $6::int, $7::int,$8::character,$9::int,$10::int,"
//		" $11::int, $12::character, $13::int, $14::int, $15::int, $16::int )";

	const char* sqls =
		" INSERT INTO m_advics "
		" ( meshcode ,recordno ,linktype ,vicslinkno,updatecode , addlinkcode , in_meshid,in_meshcode,in_nodeid,in_nodetype,in_crosstype,"
		" out_meshid,out_meshcode,out_nodeid,out_nodetype,out_crosstype,nodenum,contflag ) "
		" VALUES($1::int, $2::int, $3::int, $4::int, $5::int, $6::int, $7::int,$8::int,$9::character(6) ,$10::int,$11::int,"
    	" $12::int,$13::int, $14::character(6), $15::int, $16::int, $17::int, $18::int )";

//	PGresult* res = PQprepare(con, STMT_INSERT_ADVICS, sqls, 70, NULL);
//	PGresult* res = PQprepare(con, STMT_INSERT_ADVICS, sqls, 16, NULL);
	PGresult* res = PQprepare(con, STMT_INSERT_ADVICS, sqls, 18, NULL);
	if( !res || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		std::cout << PQerrorMessage(con) << std::endl;
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);

	return true;

}



//DB�o�^�Ɏg�p����SQL����Ԋ҂���B
bool DBSetting::prepare_advicsnode_insert()
{
	// ���sSQL��
	const char* sqls =
		" INSERT INTO m_advicsnode "
		" ( meshcode ,recordno,linktype ,vicslinkno,seqno,in_meshid,in_nodemeshcode,in_nodeid,out_meshid,out_nodemeshcode,out_nodeid ) "
		" VALUES($1::int, $2::int, $3::int, $4::int, $5::int,$6::int,$7::int, $8::character(6),$9::int,$10::int, $11::character(6))";

//	PGresult* res = PQprepare(con, STMT_INSERT_ADVICS, sqls, 70, NULL);
//	PGresult* res = PQprepare(con, STMT_INSERT_ADVICS, sqls, 16, NULL);
	PGresult* res = PQprepare(con, STMT_INSERT_ADVICSNODE, sqls, 11, NULL);
	if( !res || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		std::cout << PQerrorMessage(con) << std::endl;
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);

	return true;

}


//DB�o�^�Ɏg�p����SQL����Ԋ҂���B
bool DBSetting::prepare_node_insert()
{
	// ���sSQL��
	const char* sqls =
		" INSERT INTO m_basicnode "
		" ( meshcode ,nodeid,nodetype,meshcode2nd,nodeid2nd,seiki_pos_x ,seiki_pos_y,pos_x,pos_y,cross_name,cross_kana_name ) "
		" VALUES($1::int, $2::character(5), $3::int, $4::int, $5::character(5),$6::int, $7::int, $8::float8,$9::float8,$10::text,$11::text)";



	PGresult* res = PQprepare(con, STMT_INSERT_BASICNODE, sqls, 11, NULL);
	if( !res || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		std::cout << PQerrorMessage(con) << std::endl;
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);

	return true;

}

//DB�o�^�Ɏg�p����SQL����Ԋ҂���B
bool DBSetting::prepare_link_insert()
{
	// ���sSQL��
	const char* sqls =
		" INSERT INTO m_basiclink "
		" ( meshcode ,in_nodeid,out_nodeid ,roadtype,roadno,mastercode,link_length,link_type,road_only_flg,toll_flg ) "
		" VALUES($1::int, $2::character(5), $3::character(5), $4::int, $5::int,$6::int, $7::int,$8::int, $9::int,$10::int)";

	PGresult* res = PQprepare(con, STMT_INSERT_BASICLINK, sqls, 10, NULL);
	if( !res || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		std::cout << PQerrorMessage(con) << std::endl;
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);

	return true;

}

//DB�o�^�Ɏg�p����SQL����Ԋ҂���B
bool DBSetting::prepare_link_attr_insert()
{
	// ���sSQL��
#if 0
	const char* sqls =
		" INSERT INTO m_basiclinkattr "
		" ( meshcode ,in_nodeid,out_nodeid ,recordno,attrtypenum, "
		" attr1typecode,attr1levelcode,attr1startnodeno,attr1startconcode,attr1endnodeno ,attr1endconcode,attr1namelen,attr1name,attr1kanalen,attr1kana, "
		" attr2typecode,attr2levelcode,attr2startnodeno,attr2startconcode,attr2endnodeno ,attr2endconcode,attr2namelen,attr2name,attr2kanalen,attr2kana, "
		" attr3typecode,attr3levelcode,attr3startnodeno,attr3startconcode,attr3endnodeno ,attr3endconcode,attr3namelen,attr3name,attr3kanalen,attr3kana) "
		" VALUES($1::int, $2::character(5), $3::character(5), $4::int, $5::int,"
		" $6::int, $7::int,$8::int, $9::int,$10::int,$11::int,$12::int,$13::text,$14::int,$15::text,"
		" $16::int, $17::int,$18::int, $19::int,$20::int,$21::int,$22::int,$23::text,$24::int,$25::text,"
		" $26::int, $27::int,$28::int, $29::int,$30::int,$31::int,$32::int,$33::text,$34::int,$35::text)";
	PGresult* res = PQprepare(con, STMT_INSERT_BASICLINKATTR, sqls, 35, NULL);
#endif
	const char* sqls =
		" INSERT INTO m_basiclinkattr_1 "
		" ( meshcode ,in_nodeid,out_nodeid ,recordno,attrtypenum,attrtypeno, "
		" attr1typecode,attr1levelcode,attr1startnodeno,attr1startconcode,attr1endnodeno ,attr1endconcode,attr1namelen,attr1name,attr1kanalen,attr1kana) "
		" VALUES($1::int, $2::character(5), $3::character(5), $4::int, $5::int, $6::int,"
		" $7::int, $8::int,$9::int, $10::int,$11::int,$12::int,$13::int,$14::text,$15::int,$16::text)";

	PGresult* res = PQprepare(con, STMT_INSERT_BASICLINKATTR, sqls, 16, NULL);
	if( !res || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		std::cout << PQerrorMessage(con) << std::endl;
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);

	return true;

}

//DB�o�^�Ɏg�p����SQL����Ԋ҂���B
bool DBSetting::prepare_water_insert()
{
	// ���sSQL��

	const char* sqls =
		" INSERT INTO m_waterdata "
		" ( meshno ,itemno,itemrecord ,suitype,suinum,suino,suicode,suipos,lvflg,conflg) "
		" VALUES($1::int, $2::int, $3::int, $4::int, $5::int, $6::int,"
		" $7::int, $8::point,$9::int, $10::int)";

	PGresult* res = PQprepare(con, STMT_INSERT_WATER, sqls, 10, NULL);
	if( !res || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		std::cout << PQerrorMessage(con) << std::endl;
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);

	return true;

}
//DB�o�^�Ɏg�p����SQL����Ԋ҂���B
bool DBSetting::prepare_water_insert2()
{
	// ���sSQL��

	const char* sqls =
		" INSERT INTO m_waterdata_a "
		" ( meshno ,itemno,itemrecord ,suitype,suinum,suicode1,suipos1,"
		"suicode2,suipos2,suicode3,suipos3,suicode4,suipos4,suicode5,suipos5,suicode6,suipos6,"
"suicode7,suipos7,suicode8,suipos8,suicode9,suipos9,suicode10,suipos10,suicode11,suipos11,	"	
"suicode12,suipos12,suicode13,suipos13,suicode14,suipos14,suicode15,suipos15,suicode16,suipos16,"
"suicode17,suipos17,suicode18,suipos18,suicode19,suipos19,suicode20,suipos20,suicode21,suipos21,"
"lvflg,conflg) "
		" VALUES($1::int, $2::int, $3::int, $4::int, $5::int, $6::int, $7::point,"
		"$8::int,$9::point,$10::int,$11::point,$12::int,$13::point,$14::int,$15::point,$16::int,$17::point,"
		"$18::int,$19::point,$20::int,$21::point,$22::int,$23::point,$24::int,$25::point,$26::int,$27::point,"
		"$28::int,$29::point,$30::int,$31::point,$32::int,$33::point,$34::int,$35::point,$36::int,$37::point,"
		"$38::int,$39::point,$40::int,$41::point,$42::int,$43::point,$44::int,$45::point,$46::int,$47::point,"
		"$48::int,$49::int)";

	PGresult* res = PQprepare(con, STMT_INSERT_WATER1, sqls, 49, NULL);
	if( !res || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		std::cout << PQerrorMessage(con) << std::endl;
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);

	return true;

}

//DB�o�^�Ɏg�p����SQL����Ԋ҂���B
bool DBSetting::prepare_water_poly_insert()
{
	// ���sSQL��

	const char* sqls =
		" INSERT INTO m_sui_data "
		" ( meshno ,itemno,geopos,geoline ) "
		" VALUES($1::int, $2::int, ST_GeomFromText($3::geometry,-1), ST_GeomFromText($4::geometry))";
//		" VALUES($1::int, $2::int, ST_GeomFromText($3::geometry,-1))";
//		" VALUES($1::int, $2::int, setsrid($3::char::geometry,-1))";

//		" VALUES($1::int, $2::int, ST_GeomFromText($3::char,-1))";
	PGresult* res = PQprepare(con, STMT_INSERT_WATER_POLY, sqls, 4, NULL);
	if( !res || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		std::cout << PQerrorMessage(con) << std::endl;
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);

	return true;

}


bool DBSetting::insertdata(vicslinedata val)
{
#if 0
	// �p�����[�^�̐ݒ�
//	const char* param[70] =
	const char* param[16] =
	{
		reinterpret_cast<char*>(&val.mesh_code),
		reinterpret_cast<char*>(&val.record_no),
		reinterpret_cast<char*>(&val.link_type),
		reinterpret_cast<char*>(&val.vics_link),
		reinterpret_cast<char*>(&val.update_code),
		reinterpret_cast<char*>(&val.addlink_code),
		reinterpret_cast<char*>(&val.indata.mesh_id),
		reinterpret_cast<char*>(&val.indata.node_id),
		reinterpret_cast<char*>(&val.in_node_type),
		reinterpret_cast<char*>(&val.in_cross_type),
		reinterpret_cast<char*>(&val.outdata.mesh_id),
		reinterpret_cast<char*>(&val.outdata.node_id),
		reinterpret_cast<char*>(&val.out_node_type),
		reinterpret_cast<char*>(&val.out_cross_type),
		reinterpret_cast<char*>(&val.node_num),
//		reinterpret_cast<char*>(&val.linkdata[0].mesh_id),reinterpret_cast<char*>(&val.linkdata[0].node_id),
//		reinterpret_cast<char*>(&val.linkdata[1].mesh_id),reinterpret_cast<char*>(&val.linkdata[1].node_id),
//		reinterpret_cast<char*>(&val.linkdata[2].mesh_id),reinterpret_cast<char*>(&val.linkdata[2].node_id),
//		reinterpret_cast<char*>(&val.linkdata[3].mesh_id),reinterpret_cast<char*>(&val.linkdata[3].node_id),
//		reinterpret_cast<char*>(&val.linkdata[4].mesh_id),reinterpret_cast<char*>(&val.linkdata[4].node_id),
//		reinterpret_cast<char*>(&val.linkdata[5].mesh_id),reinterpret_cast<char*>(&val.linkdata[5].node_id),
//		reinterpret_cast<char*>(&val.linkdata[6].mesh_id),reinterpret_cast<char*>(&val.linkdata[6].node_id),
//		reinterpret_cast<char*>(&val.linkdata[7].mesh_id),reinterpret_cast<char*>(&val.linkdata[7].node_id),
//		reinterpret_cast<char*>(&val.linkdata[8].mesh_id),reinterpret_cast<char*>(&val.linkdata[8].node_id),
//		reinterpret_cast<char*>(&val.linkdata[9].mesh_id),reinterpret_cast<char*>(&val.linkdata[9].node_id),
//		reinterpret_cast<char*>(&val.linkdata[10].mesh_id),reinterpret_cast<char*>(&val.linkdata[10].node_id),
//		reinterpret_cast<char*>(&val.linkdata[11].mesh_id),reinterpret_cast<char*>(&val.linkdata[11].node_id),
//		reinterpret_cast<char*>(&val.linkdata[12].mesh_id),reinterpret_cast<char*>(&val.linkdata[12].node_id),
//		reinterpret_cast<char*>(&val.linkdata[13].mesh_id),reinterpret_cast<char*>(&val.linkdata[13].node_id),
//		reinterpret_cast<char*>(&val.linkdata[14].mesh_id),reinterpret_cast<char*>(&val.linkdata[14].node_id),
//		reinterpret_cast<char*>(&val.linkdata[15].mesh_id),reinterpret_cast<char*>(&val.linkdata[15].node_id),
//		reinterpret_cast<char*>(&val.linkdata[16].mesh_id),reinterpret_cast<char*>(&val.linkdata[16].node_id),
//		reinterpret_cast<char*>(&val.linkdata[17].mesh_id),reinterpret_cast<char*>(&val.linkdata[17].node_id),
//		reinterpret_cast<char*>(&val.linkdata[18].mesh_id),reinterpret_cast<char*>(&val.linkdata[18].node_id),
//		reinterpret_cast<char*>(&val.linkdata[19].mesh_id),reinterpret_cast<char*>(&val.linkdata[19].node_id),
//		reinterpret_cast<char*>(&val.linkdata[20].mesh_id),reinterpret_cast<char*>(&val.linkdata[20].node_id),
//		reinterpret_cast<char*>(&val.linkdata[21].mesh_id),reinterpret_cast<char*>(&val.linkdata[21].node_id),
//		reinterpret_cast<char*>(&val.linkdata[22].mesh_id),reinterpret_cast<char*>(&val.linkdata[22].node_id),
//		reinterpret_cast<char*>(&val.linkdata[23].mesh_id),reinterpret_cast<char*>(&val.linkdata[23].node_id),
//		reinterpret_cast<char*>(&val.linkdata[24].mesh_id),reinterpret_cast<char*>(&val.linkdata[24].node_id),
//		reinterpret_cast<char*>(&val.linkdata[25].mesh_id),reinterpret_cast<char*>(&val.linkdata[25].node_id),
//		reinterpret_cast<char*>(&val.linkdata[26].mesh_id),reinterpret_cast<char*>(&val.linkdata[26].node_id),
//		reinterpret_cast<char*>(&val.linkdata[27].mesh_id),reinterpret_cast<char*>(&val.linkdata[27].node_id),
//		reinterpret_cast<char*>(&val.linkdata[28].mesh_id),reinterpret_cast<char*>(&val.linkdata[28].node_id),
//		reinterpret_cast<char*>(&val.linkdata[29].mesh_id),reinterpret_cast<char*>(&val.linkdata[29].node_id),
//		reinterpret_cast<char*>(&val.linkdata[30].mesh_id),reinterpret_cast<char*>(&val.linkdata[30].node_id),
//		reinterpret_cast<char*>(&val.linkdata[31].mesh_id),reinterpret_cast<char*>(&val.linkdata[31].node_id),
//		reinterpret_cast<char*>(&val.linkdata[32].mesh_id),reinterpret_cast<char*>(&val.linkdata[32].node_id),
//		reinterpret_cast<char*>(&val.linkdata[33].mesh_id),reinterpret_cast<char*>(&val.linkdata[33].node_id),
//		reinterpret_cast<char*>(&val.linkdata[34].mesh_id),reinterpret_cast<char*>(&val.linkdata[34].node_id),
//		reinterpret_cast<char*>(&val.linkdata[35].mesh_id),reinterpret_cast<char*>(&val.linkdata[35].node_id),
//		reinterpret_cast<char*>(&val.linkdata[36].mesh_id),reinterpret_cast<char*>(&val.linkdata[36].node_id),
		reinterpret_cast<char*>(&val.cont_flg)
	};
#endif


	// �l�b�g���[�N�o�C�g�I�[�_�[�ɕ��ёւ�
	std::reverse(reinterpret_cast<char*>(&val.mesh_code), reinterpret_cast<char*>(&val.mesh_code) + sizeof(val.mesh_code));
	std::reverse(reinterpret_cast<char*>(&val.record_no), reinterpret_cast<char*>(&val.record_no) + sizeof(val.record_no));
	std::reverse(reinterpret_cast<char*>(&val.link_type), reinterpret_cast<char*>(&val.link_type) + sizeof(val.link_type));
	std::reverse(reinterpret_cast<char*>(&val.vics_link), reinterpret_cast<char*>(&val.vics_link) + sizeof(val.vics_link));
	std::reverse(reinterpret_cast<char*>(&val.update_code), reinterpret_cast<char*>(&val.update_code) + sizeof(val.update_code));
	std::reverse(reinterpret_cast<char*>(&val.addlink_code), reinterpret_cast<char*>(&val.addlink_code) + sizeof(val.addlink_code));
	std::reverse(reinterpret_cast<char*>(&val.indata.mesh_id), reinterpret_cast<char*>(&val.indata.mesh_id) + sizeof(val.indata.mesh_id));
	std::reverse(reinterpret_cast<char*>(&val.indata.node_mesh_code), reinterpret_cast<char*>(&val.indata.node_mesh_code) + sizeof(val.indata.node_mesh_code));
	std::reverse(reinterpret_cast<char*>(&val.in_node_type), reinterpret_cast<char*>(&val.in_node_type) + sizeof(val.in_node_type));
	std::reverse(reinterpret_cast<char*>(&val.in_cross_type), reinterpret_cast<char*>(&val.in_cross_type) + sizeof(val.in_cross_type));
	std::reverse(reinterpret_cast<char*>(&val.outdata.mesh_id), reinterpret_cast<char*>(&val.outdata.mesh_id) + sizeof(val.outdata.mesh_id));
	std::reverse(reinterpret_cast<char*>(&val.outdata.node_mesh_code), reinterpret_cast<char*>(&val.outdata.node_mesh_code) + sizeof(val.outdata.node_mesh_code));
	std::reverse(reinterpret_cast<char*>(&val.out_node_type), reinterpret_cast<char*>(&val.out_node_type) + sizeof(val.out_node_type));
	std::reverse(reinterpret_cast<char*>(&val.out_cross_type), reinterpret_cast<char*>(&val.out_cross_type) + sizeof(val.out_cross_type));
	std::reverse(reinterpret_cast<char*>(&val.node_num), reinterpret_cast<char*>(&val.node_num) + sizeof(val.node_num));
	std::reverse(reinterpret_cast<char*>(&val.cont_flg), reinterpret_cast<char*>(&val.cont_flg) + sizeof(val.cont_flg));


//	std::reverse(reinterpret_cast<char*>(&val.indata.node_id), reinterpret_cast<char*>(&val.indata.node_id) + sizeof(val.indata.node_id));

	const char* param[18] =
	{
		reinterpret_cast<char*>(&val.mesh_code),
		reinterpret_cast<char*>(&val.record_no),
		reinterpret_cast<char*>(&val.link_type),
		reinterpret_cast<char*>(&val.vics_link),
		reinterpret_cast<char*>(&val.update_code),
		reinterpret_cast<char*>(&val.addlink_code),
		reinterpret_cast<char*>(&val.indata.mesh_id),
		reinterpret_cast<char*>(&val.indata.node_mesh_code),
		( strlen(val.indata.node_id) == 0 ? NULL : val.indata.node_id ),
		reinterpret_cast<char*>(&val.in_node_type),
		reinterpret_cast<char*>(&val.in_cross_type),
		reinterpret_cast<char*>(&val.outdata.mesh_id),
		reinterpret_cast<char*>(&val.outdata.node_mesh_code),
		( strlen(val.outdata.node_id) == 0 ? NULL : val.outdata.node_id ),
		reinterpret_cast<char*>(&val.out_node_type),
		reinterpret_cast<char*>(&val.out_cross_type),
		reinterpret_cast<char*>(&val.node_num),
		reinterpret_cast<char*>(&val.cont_flg)
	};

#if 0
//	int paramLen[70] =
	int paramLen[16] =
	{
		sizeof(val.mesh_code), sizeof(val.record_no), sizeof(val.link_type),
		sizeof(val.vics_link), sizeof(val.update_code),sizeof(val.addlink_code),
		sizeof(val.indata.mesh_id), sizeof(val.indata.node_id),sizeof(val.in_node_type),sizeof(val.in_cross_type),
		sizeof(val.outdata.mesh_id), sizeof(val.outdata.node_id),sizeof(val.out_node_type),sizeof(val.out_cross_type),
		sizeof(val.node_num), 
//		sizeof(val.linkdata[0].mesh_id),sizeof(val.linkdata[0].node_id), 
//		sizeof(val.linkdata[1].mesh_id),sizeof(val.linkdata[1].node_id), 
//		sizeof(val.linkdata[2].mesh_id),sizeof(val.linkdata[2].node_id), 
//		sizeof(val.linkdata[3].mesh_id),sizeof(val.linkdata[3].node_id), 
//		sizeof(val.linkdata[4].mesh_id),sizeof(val.linkdata[4].node_id), 
//		sizeof(val.linkdata[5].mesh_id),sizeof(val.linkdata[5].node_id), 
//		sizeof(val.linkdata[6].mesh_id),sizeof(val.linkdata[6].node_id), 
//		sizeof(val.linkdata[7].mesh_id),sizeof(val.linkdata[7].node_id), 
//		sizeof(val.linkdata[8].mesh_id),sizeof(val.linkdata[8].node_id), 
//		sizeof(val.linkdata[9].mesh_id),sizeof(val.linkdata[9].node_id), 
//		sizeof(val.linkdata[10].mesh_id),sizeof(val.linkdata[10].node_id), 
//		sizeof(val.linkdata[11].mesh_id),sizeof(val.linkdata[11].node_id), 
//		sizeof(val.linkdata[12].mesh_id),sizeof(val.linkdata[12].node_id), 
//		sizeof(val.linkdata[13].mesh_id),sizeof(val.linkdata[13].node_id), 
//		sizeof(val.linkdata[14].mesh_id),sizeof(val.linkdata[14].node_id), 
//		sizeof(val.linkdata[15].mesh_id),sizeof(val.linkdata[15].node_id), 
//		sizeof(val.linkdata[16].mesh_id),sizeof(val.linkdata[16].node_id), 
//		sizeof(val.linkdata[17].mesh_id),sizeof(val.linkdata[17].node_id), 
//		sizeof(val.linkdata[18].mesh_id),sizeof(val.linkdata[18].node_id), 
//		sizeof(val.linkdata[19].mesh_id),sizeof(val.linkdata[19].node_id), 
//		sizeof(val.linkdata[20].mesh_id),sizeof(val.linkdata[20].node_id), 
//		sizeof(val.linkdata[21].mesh_id),sizeof(val.linkdata[21].node_id), 
//		sizeof(val.linkdata[22].mesh_id),sizeof(val.linkdata[22].node_id), 
//		sizeof(val.linkdata[23].mesh_id),sizeof(val.linkdata[23].node_id), 
//		sizeof(val.linkdata[24].mesh_id),sizeof(val.linkdata[24].node_id), 
//		sizeof(val.linkdata[25].mesh_id),sizeof(val.linkdata[25].node_id), 
//		sizeof(val.linkdata[26].mesh_id),sizeof(val.linkdata[26].node_id), 
//		sizeof(val.linkdata[27].mesh_id),sizeof(val.linkdata[27].node_id), 
//		sizeof(val.linkdata[28].mesh_id),sizeof(val.linkdata[28].node_id), 
//		sizeof(val.linkdata[29].mesh_id),sizeof(val.linkdata[29].node_id), 
//		sizeof(val.linkdata[30].mesh_id),sizeof(val.linkdata[30].node_id), 
//		sizeof(val.linkdata[31].mesh_id),sizeof(val.linkdata[31].node_id), 
//		sizeof(val.linkdata[32].mesh_id),sizeof(val.linkdata[32].node_id), 
//		sizeof(val.linkdata[33].mesh_id),sizeof(val.linkdata[33].node_id), 
//		sizeof(val.linkdata[34].mesh_id),sizeof(val.linkdata[34].node_id), 
//		sizeof(val.linkdata[35].mesh_id),sizeof(val.linkdata[35].node_id), 
//		sizeof(val.linkdata[36].mesh_id),sizeof(val.linkdata[36].node_id), 
		sizeof(val.cont_flg)
	};
#endif
	int paramLen[18] =
	{
		sizeof(val.mesh_code), sizeof(val.record_no), sizeof(val.link_type),
		sizeof(val.vics_link), sizeof(val.update_code),sizeof(val.addlink_code),
		sizeof(val.indata.mesh_id),sizeof(val.indata.node_mesh_code), sizeof(val.indata.node_id),sizeof(val.in_node_type),sizeof(val.in_cross_type),
		sizeof(val.outdata.mesh_id),sizeof(val.outdata.node_mesh_code), sizeof(val.outdata.node_id),sizeof(val.out_node_type),sizeof(val.out_cross_type),
		sizeof(val.node_num),sizeof(val.cont_flg) 

	};


//	int paramFmt[70] = {1, 1, 1, 1, 1, 1,1,1,1,1,
//	1, 1, 1, 1, 1, 1,1,1,1,1,
//	1, 1, 1, 1, 1, 1,1,1,1,1,
//	1, 1, 1, 1, 1, 1,1,1,1,1,
//	1, 1, 1, 1, 1, 1,1,1,1,1,
//	1, 1, 1, 1, 1, 1,1,1,1,1,
//	1, 1, 1, 1, 1, 1,1,1,1,1};

	int paramFmt[18] = {1, 1, 1, 1, 1, 1,1,1,0,1,1,
	1, 1,0, 1, 1, 1, 1};

	//int paramFmt[8] = {1, 1, 1, 1, 1, 1,1,0};


//	PGresult* res = PQexecPrepared(con, STMT_INSERT_ADVICS, 16, param, paramLen, paramFmt, 0);
	PGresult* res = PQexecPrepared(con, STMT_INSERT_ADVICS, 18, param, paramLen, paramFmt, 0);

	int re = PQresultStatus(res);
	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("MapDBWriter::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);



	return true;
}




bool DBSetting::insertadvicsnodedata(vicslinedata val,int cnt,int con_flg)
{

	int icount = cnt;
	int cn=0;
	//���p�e�[�u���ł͂Ȃ�
	if(con_flg==0)
	{
		cn=icount;
	}
	else
	{
		cn=icount+36;
	}


	// �l�b�g���[�N�o�C�g�I�[�_�[�ɕ��ёւ�
	std::reverse(reinterpret_cast<char*>(&val.mesh_code), reinterpret_cast<char*>(&val.mesh_code) + sizeof(val.mesh_code));
	std::reverse(reinterpret_cast<char*>(&val.record_no), reinterpret_cast<char*>(&val.record_no) + sizeof(val.record_no));
	std::reverse(reinterpret_cast<char*>(&val.link_type), reinterpret_cast<char*>(&val.link_type) + sizeof(val.link_type));
	std::reverse(reinterpret_cast<char*>(&val.vics_link), reinterpret_cast<char*>(&val.vics_link) + sizeof(val.vics_link));
	std::reverse(reinterpret_cast<char*>(&cn), reinterpret_cast<char*>(&cn) + sizeof(cn));
	std::reverse(reinterpret_cast<char*>(&val.linkdata[icount].mesh_id), reinterpret_cast<char*>(&val.linkdata[icount].mesh_id) + sizeof(&val.linkdata[icount].mesh_id));
	std::reverse(reinterpret_cast<char*>(&val.linkdata[icount].node_mesh_code), reinterpret_cast<char*>(&val.linkdata[icount].node_mesh_code) + sizeof(&val.linkdata[icount].node_mesh_code));
	std::reverse(reinterpret_cast<char*>(&val.linkdata[icount+1].mesh_id), reinterpret_cast<char*>(&val.linkdata[icount+1].mesh_id) + sizeof(&val.linkdata[icount+1].mesh_id));
	std::reverse(reinterpret_cast<char*>(&val.linkdata[icount+1].node_mesh_code), reinterpret_cast<char*>(&val.linkdata[icount+1].node_mesh_code) + sizeof(&val.linkdata[icount+1].node_mesh_code));


	// �p�����[�^�̐ݒ�
	const char* param[11] =
	{
		reinterpret_cast<char*>(&val.mesh_code),
		reinterpret_cast<char*>(&val.record_no),
		reinterpret_cast<char*>(&val.link_type),
		reinterpret_cast<char*>(&val.vics_link),
		reinterpret_cast<char*>(&cn),
		reinterpret_cast<char*>(&val.linkdata[icount].mesh_id),
		reinterpret_cast<char*>(&val.linkdata[icount].node_mesh_code),
		( strlen(val.linkdata[icount].node_id) == 0 ? NULL : val.linkdata[icount].node_id ),
		reinterpret_cast<char*>(&val.linkdata[icount+1].mesh_id),
		reinterpret_cast<char*>(&val.linkdata[icount+1].node_mesh_code),
		( strlen(val.linkdata[icount+1].node_id) == 0 ? NULL : val.linkdata[icount+1].node_id )
	};

	int paramLen[11] =
	{
		sizeof(val.mesh_code), sizeof(val.record_no), sizeof(val.link_type),sizeof(val.vics_link), sizeof(cn),
		sizeof(val.linkdata[icount].mesh_id),sizeof(val.linkdata[icount].node_mesh_code),sizeof(val.linkdata[icount].node_id),
		sizeof(val.linkdata[icount+1].mesh_id),sizeof(val.linkdata[icount+1].node_mesh_code),sizeof(val.linkdata[icount+1].node_id)
	};

	int paramFmt[11] = {1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0};

	PGresult* res = PQexecPrepared(con, STMT_INSERT_ADVICSNODE, 11, param, paramLen, paramFmt, 0);

	int re = PQresultStatus(res);
	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("MapDBWriter::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);

	return true;
}



/**
 * ��{�m�[�h�f�[�^DB�o�^
 *
 * @param [in]	val	��{�m�[�h�f�[�^�\����
 *
 * @retval true		����I��
 * @retval false	�ُ�I��
 */
bool DBSetting::insertnodedata(posdata val)
{


	// �l�b�g���[�N�o�C�g�I�[�_�[�ɕ��ёւ�
	std::reverse(reinterpret_cast<char*>(&val.mesh_code), reinterpret_cast<char*>(&val.mesh_code) + sizeof(val.mesh_code));
//	std::reverse(reinterpret_cast<char*>(&val.nodeid), reinterpret_cast<char*>(&val.nodeid) + sizeof(val.nodeid));
	std::reverse(reinterpret_cast<char*>(&val.node_type), reinterpret_cast<char*>(&val.node_type) + sizeof(val.node_type));
	std::reverse(reinterpret_cast<char*>(&val.mesh_code_2nd), reinterpret_cast<char*>(&val.mesh_code_2nd) + sizeof(val.mesh_code_2nd));
	std::reverse(reinterpret_cast<char*>(&val.seiki_pos_x), reinterpret_cast<char*>(&val.seiki_pos_x) + sizeof(val.seiki_pos_x));
	std::reverse(reinterpret_cast<char*>(&val.seiki_pos_y), reinterpret_cast<char*>(&val.seiki_pos_y) + sizeof(val.seiki_pos_y));
	std::reverse(reinterpret_cast<char*>(&val.pos_x), reinterpret_cast<char*>(&val.pos_x) + sizeof(val.pos_x));
	std::reverse(reinterpret_cast<char*>(&val.pos_y), reinterpret_cast<char*>(&val.pos_y) + sizeof(val.pos_y));

	char tpname[100];
	char tpkana[100];
	memset(tpname,NULL,sizeof(tpname));
	memset(tpkana,NULL,sizeof(tpkana));

	if(strlen(val.cross_name) > 0)
	{
		if(ConvertSJIStoUTF8(val.cross_name,tpname) == -1)
		{
			return false;
		}
		
	}
	if(strlen(val.cross_name) > 0)
	{
		if(ConvertSJIStoUTF8(val.cross_kana_name,tpkana) == -1)
		{
			return false;
		}
		
	}

	// �p�����[�^�̐ݒ�
	const char* param[11] =
	{
		reinterpret_cast<char*>(&val.mesh_code),
		( strlen(val.node_id) == 0 ? NULL : val.node_id ),
		reinterpret_cast<char*>(&val.node_type),
		reinterpret_cast<char*>(&val.mesh_code_2nd),
		( strlen(val.node_id_2nd) == 0 ? NULL : val.node_id_2nd ),
		reinterpret_cast<char*>(&val.seiki_pos_x),
		reinterpret_cast<char*>(&val.seiki_pos_y),
		reinterpret_cast<char*>(&val.pos_x),
		reinterpret_cast<char*>(&val.pos_y),
		( strlen(val.cross_name) == 0 ? NULL : tpname ),
		( strlen(val.cross_kana_name) == 0 ? NULL : tpkana )

	};

	int paramLen[11] =
	{
		sizeof(val.mesh_code), sizeof(val.node_id), sizeof(val.node_type),
		sizeof(val.mesh_code_2nd), sizeof(val.node_id_2nd),
		sizeof(val.seiki_pos_x),sizeof(val.seiki_pos_y), sizeof(val.pos_x),sizeof(val.pos_y),
		strlen(tpname),strlen(tpkana)};

	int paramFmt[11] = {1, 0, 1, 1, 0, 1, 1, 1, 1,0,0};

	PGresult* res = PQexecPrepared(con, STMT_INSERT_BASICNODE, 11, param, paramLen, paramFmt, 0);

	int re = PQresultStatus(res);
	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("MapDBWriter::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);

	return true;
}


/**
 * ��{�����N�f�[�^DB�o�^
 *
 * @param [in]	val	��{�����N�f�[�^�\����
 *
 * @retval true		����I��
 * @retval false	�ُ�I��
 */
bool DBSetting::insertlinkdata(linkdata val)
{

	// �l�b�g���[�N�o�C�g�I�[�_�[�ɕ��ёւ�
	std::reverse(reinterpret_cast<char*>(&val.mesh_code), reinterpret_cast<char*>(&val.mesh_code) + sizeof(val.mesh_code));
	std::reverse(reinterpret_cast<char*>(&val.road_code), reinterpret_cast<char*>(&val.road_code) + sizeof(val.road_code));
	std::reverse(reinterpret_cast<char*>(&val.road_no), reinterpret_cast<char*>(&val.road_no) + sizeof(val.road_no));
	std::reverse(reinterpret_cast<char*>(&val.master_code), reinterpret_cast<char*>(&val.master_code) + sizeof(val.master_code));
	std::reverse(reinterpret_cast<char*>(&val.link_length), reinterpret_cast<char*>(&val.link_length) + sizeof(val.link_length));
	std::reverse(reinterpret_cast<char*>(&val.link_type), reinterpret_cast<char*>(&val.link_type) + sizeof(val.link_type));
	std::reverse(reinterpret_cast<char*>(&val.road_only_flg), reinterpret_cast<char*>(&val.road_only_flg) + sizeof(val.road_only_flg));
	std::reverse(reinterpret_cast<char*>(&val.toll_flg), reinterpret_cast<char*>(&val.toll_flg) + sizeof(val.toll_flg));

	// �p�����[�^�̐ݒ�
	const char* param[10] =
	{
		reinterpret_cast<char*>(&val.mesh_code),
		( strlen(val.node_1) == 0 ? NULL : val.node_1 ),
		( strlen(val.node_2) == 0 ? NULL : val.node_2 ),
		reinterpret_cast<char*>(&val.road_code),
		reinterpret_cast<char*>(&val.road_no),
		reinterpret_cast<char*>(&val.master_code),
		reinterpret_cast<char*>(&val.link_length),
		reinterpret_cast<char*>(&val.link_type),
		reinterpret_cast<char*>(&val.road_only_flg),
		reinterpret_cast<char*>(&val.toll_flg)
	};
	//�p�����[�^��
	int paramLen[10] =
	{
		sizeof(val.mesh_code), sizeof(val.node_1), sizeof(val.node_2),
		sizeof(val.road_code), sizeof(val.road_no),sizeof(val.master_code),sizeof(val.link_length),sizeof(val.link_type), sizeof(val.road_only_flg),sizeof(val.toll_flg) };
	//�p�����[�^�t�H�[�}�b�g
	int paramFmt[10] = {1, 0, 0, 1, 1, 1, 1, 1, 1, 1};

	//SQL���s
	PGresult* res = PQexecPrepared(con, STMT_INSERT_BASICLINK, 10, param, paramLen, paramFmt, 0);

	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("MapDBWriter::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		if( res != NULL )	PQclear(res);
		return false;
	}
	PQclear(res);

	return true;
}

/**
 * ��{�����N�������f�[�^DB�o�^
 *
 * @param [in]	val	��{�����N�f�[�^�\����
 *
 * @retval true		����I��
 * @retval false	�ُ�I��
 */
bool DBSetting::insertlinkattrdata(link_attr val)
{

	int i=0;
	int count = val.attr_type_num;

	// �l�b�g���[�N�o�C�g�I�[�_�[�ɕ��ёւ�
	std::reverse(reinterpret_cast<char*>(&val.mesh_code), reinterpret_cast<char*>(&val.mesh_code) + sizeof(val.mesh_code));
	std::reverse(reinterpret_cast<char*>(&val.record_no), reinterpret_cast<char*>(&val.record_no) + sizeof(val.record_no));
	std::reverse(reinterpret_cast<char*>(&val.attr_type_num), reinterpret_cast<char*>(&val.attr_type_num) + sizeof(val.attr_type_num));

	char tpname[50];
	char tpkana[50];
//	memset(tpname,NULL,sizeof(tpname));
//	memset(tpkana,NULL,sizeof(tpkana));

	for (i=0;i < count;i++)
	{
		std::reverse(reinterpret_cast<char*>(&val.atdata[i].attr_type_no), reinterpret_cast<char*>(&val.atdata[i].attr_type_no) + sizeof(val.atdata[i].attr_type_no));
		std::reverse(reinterpret_cast<char*>(&val.atdata[i].attr_type_code), reinterpret_cast<char*>(&val.atdata[i].attr_type_code) + sizeof(val.atdata[i].attr_type_code));
		std::reverse(reinterpret_cast<char*>(&val.atdata[i].attr_level_code), reinterpret_cast<char*>(&val.atdata[i].attr_level_code) + sizeof(val.atdata[i].attr_level_code));
		std::reverse(reinterpret_cast<char*>(&val.atdata[i].attr_start_node_no), reinterpret_cast<char*>(&val.atdata[i].attr_start_node_no) + sizeof(val.atdata[i].attr_start_node_no));
		std::reverse(reinterpret_cast<char*>(&val.atdata[i].attr_start_con_code), reinterpret_cast<char*>(&val.atdata[i].attr_start_con_code) + sizeof(val.atdata[i].attr_start_con_code));
		std::reverse(reinterpret_cast<char*>(&val.atdata[i].attr_end_node_no), reinterpret_cast<char*>(&val.atdata[i].attr_end_node_no) + sizeof(val.atdata[i].attr_end_node_no));
		std::reverse(reinterpret_cast<char*>(&val.atdata[i].attr_end_con_code), reinterpret_cast<char*>(&val.atdata[i].attr_end_con_code) + sizeof(val.atdata[i].attr_end_con_code));
		std::reverse(reinterpret_cast<char*>(&val.atdata[i].attr_name_len), reinterpret_cast<char*>(&val.atdata[i].attr_name_len) + sizeof(val.atdata[i].attr_name_len));
		std::reverse(reinterpret_cast<char*>(&val.atdata[i].attr_kana_len), reinterpret_cast<char*>(&val.atdata[i].attr_kana_len) + sizeof(val.atdata[i].attr_kana_len));

		memset(tpname,NULL,sizeof(tpname));
		memset(tpkana,NULL,sizeof(tpkana));

		//������ UTF8�֕ϊ�
		if(strlen(val.atdata[i].attr_name) > 0)
		{
			if(ConvertSJIStoUTF8(val.atdata[i].attr_name,tpname) == -1)
			{
				return false;
			}
		}
		if(strlen(val.atdata[i].attr_kana) > 0)
		{
			if(ConvertSJIStoUTF8(val.atdata[i].attr_kana,tpkana) == -1)
			{
				return false;
			}
		}

		// �p�����[�^�̐ݒ�
		const char* param[16] =
		{
			reinterpret_cast<char*>(&val.mesh_code),
			( strlen(val.node_1) == 0 ? NULL : val.node_1 ),
			( strlen(val.node_2) == 0 ? NULL : val.node_2 ),
			reinterpret_cast<char*>(&val.record_no),
			reinterpret_cast<char*>(&val.attr_type_num),
			reinterpret_cast<char*>(&val.atdata[i].attr_type_no),
			reinterpret_cast<char*>(&val.atdata[i].attr_type_code),
			reinterpret_cast<char*>(&val.atdata[i].attr_level_code),
			reinterpret_cast<char*>(&val.atdata[i].attr_start_node_no),
			reinterpret_cast<char*>(&val.atdata[i].attr_start_con_code),
			reinterpret_cast<char*>(&val.atdata[i].attr_end_node_no),
			reinterpret_cast<char*>(&val.atdata[i].attr_end_con_code),
			reinterpret_cast<char*>(&val.atdata[i].attr_name_len),
			( strlen(val.atdata[i].attr_name) == 0 ? NULL : tpname ),
			reinterpret_cast<char*>(&val.atdata[i].attr_kana_len),
			( strlen(val.atdata[i].attr_kana) == 0 ? NULL : tpkana)
		};

		//�p�����[�^��
		int paramLen[16] =
		{
			sizeof(val.mesh_code), sizeof(val.node_1), sizeof(val.node_2),sizeof(val.record_no), sizeof(val.attr_type_num),sizeof(val.atdata[i].attr_type_no),
			sizeof(val.atdata[i].attr_type_code),sizeof(val.atdata[i].attr_level_code),sizeof(val.atdata[i].attr_start_node_no), sizeof(val.atdata[i].attr_start_con_code),sizeof(val.atdata[i].attr_end_node_no),
			sizeof(val.atdata[i].attr_end_con_code),sizeof(val.atdata[i].attr_name_len),strlen(tpname), sizeof(val.atdata[i].attr_kana_len),strlen(tpkana)
		};
		//�p�����[�^�t�H�[�}�b�g
		int paramFmt[16] = {1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0};

		//SQL���s
		PGresult* res = PQexecPrepared(con, STMT_INSERT_BASICLINKATTR, 16, param, paramLen, paramFmt, 0);

		if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
		{
			//Logger::write<Logger::ERROR>("MapDBWriter::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
			if( res != NULL )	PQclear(res);
			return false;
		}

		commit();
		PQclear(res);
	}


//	PQclear(res);

	return true;
}

//m_vicslink_adf�e�[�u���ɏ����f�[�^�o�^
bool DBSetting::insertvicslinkdata_adf()
{
	int ret = CONV_OTHER_ERROR;
    // SQL��
	char sql[5000];
	memset(sql,NULL,sizeof(sql));
    PGresult *res;

    // SQL���s
	sprintf(sql, INSERT_VICSLINK_ADF);
	res = PQexec(con,sql);
	int tes = PQresultStatus(res);
	if (PQresultStatus(res) != PGRES_COMMAND_OK) {
		// SQL�̎��s�Ɏ��s
		//fprintf(stderr,"%s",PQerrorMessage(con));
		printf("�f�[�^�̓o�^�Ɏ��s���܂����B�e�[�u�����Fm_vicslink_adf�e�[�u��");
		goto fin;
	}

	PQclear(res);

	ret = CONV_SUCCESS;
fin:
    return ret;

}

//add by cuijun on 2011/12/10
bool DBSetting::insertadvicsnode_mix()
{
	int ret = CONV_OTHER_ERROR;
    // SQL��
	char sql[5000];
	memset(sql,NULL,sizeof(sql));
    PGresult *res;

    // SQL���s
	sprintf(sql, INSERT_ADVICSNODE_MIX_ADF);
	res = PQexec(con,sql);
	int tes = PQresultStatus(res);
	if (PQresultStatus(res) != PGRES_COMMAND_OK) {
		// SQL�̎��s�Ɏ��s
		//fprintf(stderr,"%s",PQerrorMessage(con));
		printf("�f�[�^�̓o�^�Ɏ��s���܂����B�e�[�u�����Fm_advicsnode_mix�e�[�u��");
		goto fin;
	}

	PQclear(res);

	ret = CONV_SUCCESS;
fin:
    return ret;

}
//add by cuijun on 2011/12/10



/**
 * ���n�f�[�^DB�o�^
 *
 * @param [in]	val	��{�����N�f�[�^�\����
 *
 * @retval true		����I��
 * @retval false	�ُ�I��
 */
bool DBSetting::insertwaterdata(suidata val)
{

	int i=0;
	int count = val.sui_num;

	// �l�b�g���[�N�o�C�g�I�[�_�[�ɕ��ёւ�
	std::reverse(reinterpret_cast<char*>(&val.mesh_code), reinterpret_cast<char*>(&val.mesh_code) + sizeof(val.mesh_code));
	std::reverse(reinterpret_cast<char*>(&val.item_no), reinterpret_cast<char*>(&val.item_no) + sizeof(val.item_no));
	std::reverse(reinterpret_cast<char*>(&val.item_record), reinterpret_cast<char*>(&val.item_record) + sizeof(val.item_record));

	std::reverse(reinterpret_cast<char*>(&val.sui_type), reinterpret_cast<char*>(&val.sui_type) + sizeof(val.sui_type));
	std::reverse(reinterpret_cast<char*>(&val.sui_num), reinterpret_cast<char*>(&val.sui_num) + sizeof(val.sui_num));
	std::reverse(reinterpret_cast<char*>(&val.lv_flg), reinterpret_cast<char*>(&val.lv_flg) + sizeof(val.lv_flg));
	std::reverse(reinterpret_cast<char*>(&val.cont_flg), reinterpret_cast<char*>(&val.cont_flg) + sizeof(val.cont_flg));


	for (i=0;i < count;i++)
	{
		int cnt =i;

		std::reverse(reinterpret_cast<char*>(&val.sui_code[i]), reinterpret_cast<char*>(&val.sui_code[i]) + sizeof(val.sui_code[i]));
		std::reverse(reinterpret_cast<char*>(&cnt), reinterpret_cast<char*>(&cnt) + sizeof(cnt));
		//std::reverse(reinterpret_cast<char*>(&val.sui_pos[i]), reinterpret_cast<char*>(&val.sui_pos[i]) + sizeof(val.sui_pos[i]));

		char wpos[50];
		memset(wpos,0,sizeof(wpos));
//		printf(wpos,"POINT(%d,%d)",val.sui_pos[i].x,val.sui_pos[i].y);
		sprintf(wpos,"(%d,%d)",val.sui_pos[i].x,val.sui_pos[i].y);

		// �p�����[�^�̐ݒ�
		const char* param[10] =
		{
			reinterpret_cast<char*>(&val.mesh_code),
			reinterpret_cast<char*>(&val.item_no),
			reinterpret_cast<char*>(&val.item_record),
			reinterpret_cast<char*>(&val.sui_type),
			reinterpret_cast<char*>(&val.sui_num),
			reinterpret_cast<char*>(&cnt),
			reinterpret_cast<char*>(&val.sui_code[i]),
			wpos,
			reinterpret_cast<char*>(&val.lv_flg),
			reinterpret_cast<char*>(&val.cont_flg)
		};

		//�p�����[�^��
		int paramLen[10] =
		{
			sizeof(val.mesh_code), sizeof(val.item_no), sizeof(val.item_record),sizeof(val.sui_type), sizeof(val.sui_num),sizeof(cnt),
			sizeof(val.sui_code[i]),sizeof(wpos),sizeof(val.lv_flg), sizeof(val.cont_flg)
		};
		//�p�����[�^�t�H�[�}�b�g
		int paramFmt[10] = {1, 1, 1, 1, 1, 1, 1, 0, 1, 1};

		//SQL���s
		PGresult* res = PQexecPrepared(con, STMT_INSERT_WATER, 10, param, paramLen, paramFmt, 0);

		if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
		{
			//Logger::write<Logger::ERROR>("MapDBWriter::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
			if( res != NULL )	PQclear(res);
			return false;
		}

		commit();
		PQclear(res);
	}


//	PQclear(res);

	return true;
}

/**
 * ���n�f�[�^DB�o�^
 *
 * @param [in]	val	��{�����N�f�[�^�\����
 *
 * @retval true		����I��
 * @retval false	�ُ�I��
 */
bool DBSetting::insertwaterdata2(suidata val)
{

	int i=0;
	int count = val.sui_num;

	// �l�b�g���[�N�o�C�g�I�[�_�[�ɕ��ёւ�
	std::reverse(reinterpret_cast<char*>(&val.mesh_code), reinterpret_cast<char*>(&val.mesh_code) + sizeof(val.mesh_code));
	std::reverse(reinterpret_cast<char*>(&val.item_no), reinterpret_cast<char*>(&val.item_no) + sizeof(val.item_no));
	std::reverse(reinterpret_cast<char*>(&val.item_record), reinterpret_cast<char*>(&val.item_record) + sizeof(val.item_record));

	std::reverse(reinterpret_cast<char*>(&val.sui_type), reinterpret_cast<char*>(&val.sui_type) + sizeof(val.sui_type));
	std::reverse(reinterpret_cast<char*>(&val.sui_num), reinterpret_cast<char*>(&val.sui_num) + sizeof(val.sui_num));
	std::reverse(reinterpret_cast<char*>(&val.lv_flg), reinterpret_cast<char*>(&val.lv_flg) + sizeof(val.lv_flg));
	std::reverse(reinterpret_cast<char*>(&val.cont_flg), reinterpret_cast<char*>(&val.cont_flg) + sizeof(val.cont_flg));


//	for (i=0;i < count;i++)
	{
		//int cnt =i;

//		std::reverse(reinterpret_cast<char*>(&val.sui_code[i]), reinterpret_cast<char*>(&val.sui_code[i]) + sizeof(val.sui_code[i]));
//		std::reverse(reinterpret_cast<char*>(&cnt), reinterpret_cast<char*>(&cnt) + sizeof(cnt));
		//std::reverse(reinterpret_cast<char*>(&val.sui_pos[i]), reinterpret_cast<char*>(&val.sui_pos[i]) + sizeof(val.sui_pos[i]));

		char wpos[21][50];
		memset(wpos,0,sizeof(wpos));
//		printf(wpos,"POINT(%d,%d)",val.sui_pos[i].x,val.sui_pos[i].y);

		for (i=0;i < count;i++)
		{
			std::reverse(reinterpret_cast<char*>(&val.sui_code[i]), reinterpret_cast<char*>(&val.sui_code[i]) + sizeof(val.sui_code[i]));
			sprintf(wpos[i],"(%d,%d)",val.sui_pos[i].x,val.sui_pos[i].y);
		}


		// �p�����[�^�̐ݒ�
		const char* param[49] =
		{
			reinterpret_cast<char*>(&val.mesh_code),
			reinterpret_cast<char*>(&val.item_no),
			reinterpret_cast<char*>(&val.item_record),
			reinterpret_cast<char*>(&val.sui_type),
			reinterpret_cast<char*>(&val.sui_num),
			( strlen(wpos[0]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[0]) ),
			( strlen(wpos[0]) == 0 ? NULL : wpos[0] ),
			( strlen(wpos[1]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[1]) ),
			( strlen(wpos[1]) == 0 ? NULL : wpos[1] ),
			( strlen(wpos[2]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[2]) ),
			( strlen(wpos[2]) == 0 ? NULL : wpos[2] ),
			( strlen(wpos[3]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[3]) ),
			( strlen(wpos[3]) == 0 ? NULL : wpos[3] ),
			( strlen(wpos[4]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[4]) ),
			( strlen(wpos[4]) == 0 ? NULL : wpos[4] ),
			( strlen(wpos[5]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[5]) ),
			( strlen(wpos[5]) == 0 ? NULL : wpos[5] ),
			( strlen(wpos[6]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[6]) ),
			( strlen(wpos[6]) == 0 ? NULL : wpos[6] ),
			( strlen(wpos[7]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[7]) ),
			( strlen(wpos[7]) == 0 ? NULL : wpos[7] ),
			( strlen(wpos[8]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[8]) ),
			( strlen(wpos[8]) == 0 ? NULL : wpos[8] ),
			( strlen(wpos[9]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[9]) ),
			( strlen(wpos[9]) == 0 ? NULL : wpos[9] ),
			( strlen(wpos[10]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[10]) ),
			( strlen(wpos[10]) == 0 ? NULL : wpos[10] ),
			( strlen(wpos[11]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[11]) ),
			( strlen(wpos[11]) == 0 ? NULL : wpos[11] ),
			( strlen(wpos[12]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[12]) ),
			( strlen(wpos[12]) == 0 ? NULL : wpos[12] ),
			( strlen(wpos[13]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[13]) ),
			( strlen(wpos[13]) == 0 ? NULL : wpos[13] ),
			( strlen(wpos[14]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[14]) ),
			( strlen(wpos[14]) == 0 ? NULL : wpos[14] ),
			( strlen(wpos[15]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[15]) ),
			( strlen(wpos[15]) == 0 ? NULL : wpos[15] ),
			( strlen(wpos[16]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[16]) ),
			( strlen(wpos[16]) == 0 ? NULL : wpos[16] ),
			( strlen(wpos[17]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[17]) ),
			( strlen(wpos[17]) == 0 ? NULL : wpos[17] ),
			( strlen(wpos[18]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[18]) ),
			( strlen(wpos[18]) == 0 ? NULL : wpos[18] ),
			( strlen(wpos[19]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[19]) ),
			( strlen(wpos[19]) == 0 ? NULL : wpos[19] ),
			( strlen(wpos[20]) == 0 ? NULL : reinterpret_cast<char*>(&val.sui_code[20]) ),
			( strlen(wpos[20]) == 0 ? NULL : wpos[20] ),
			reinterpret_cast<char*>(&val.lv_flg),
			reinterpret_cast<char*>(&val.cont_flg)
		};

		//�p�����[�^��
		int paramLen[49] =
		{
			sizeof(val.mesh_code), sizeof(val.item_no), sizeof(val.item_record),sizeof(val.sui_type), sizeof(val.sui_num),
			sizeof(val.sui_code[0]),sizeof(wpos[0]),sizeof(val.sui_code[1]),sizeof(wpos[1]),sizeof(val.sui_code[2]),sizeof(wpos[2]),sizeof(val.sui_code[3]),sizeof(wpos[3]),
			sizeof(val.sui_code[4]),sizeof(wpos[4]),sizeof(val.sui_code[5]),sizeof(wpos[5]),sizeof(val.sui_code[6]),sizeof(wpos[6]),sizeof(val.sui_code[7]),sizeof(wpos[7]),
			sizeof(val.sui_code[8]),sizeof(wpos[8]),sizeof(val.sui_code[9]),sizeof(wpos[9]),sizeof(val.sui_code[10]),sizeof(wpos[10]),sizeof(val.sui_code[11]),sizeof(wpos[11]),
			sizeof(val.sui_code[12]),sizeof(wpos[12]),sizeof(val.sui_code[13]),sizeof(wpos[13]),sizeof(val.sui_code[14]),sizeof(wpos[14]),sizeof(val.sui_code[15]),sizeof(wpos[15]),
			sizeof(val.sui_code[16]),sizeof(wpos[16]),sizeof(val.sui_code[17]),sizeof(wpos[17]),sizeof(val.sui_code[18]),sizeof(wpos[18]),sizeof(val.sui_code[19]),sizeof(wpos[19]),
			sizeof(val.sui_code[20]),sizeof(wpos[20]),sizeof(val.lv_flg), sizeof(val.cont_flg)
		};
		//�p�����[�^�t�H�[�}�b�g
		int paramFmt[49] = {1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1};

		//SQL���s
		PGresult* res = PQexecPrepared(con, STMT_INSERT_WATER1, 49, param, paramLen, paramFmt, 0);

		if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
		{
			//Logger::write<Logger::ERROR>("MapDBWriter::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
			if( res != NULL )	PQclear(res);
			return false;
		}

		commit();
		PQclear(res);
	}


//	PQclear(res);

	return true;
}

/**
 * ���n�f�[�^DB�o�^
 *
 * @param [in]	val	��{�����N�f�[�^�\����
 *
 * @retval true		����I��
 * @retval false	�ُ�I��
 */
bool DBSetting::insertwaterpoly(suidata val)
{

	int i=0;
	int count = val.sui_num;

	// �l�b�g���[�N�o�C�g�I�[�_�[�ɕ��ёւ�
	std::reverse(reinterpret_cast<char*>(&val.mesh_code), reinterpret_cast<char*>(&val.mesh_code) + sizeof(val.mesh_code));
	std::reverse(reinterpret_cast<char*>(&val.item_no), reinterpret_cast<char*>(&val.item_no) + sizeof(val.item_no));

	if(con_flg==0)
	{
		memset(psql,NULL,sizeof(psql));
	}

	for (i=0;i < count;i++)
	{
		//�Ő擪��
		if(con_flg==0 && i==0)
		{
			if(val.sui_type ==1)
			{
				line_flg=1;
				sprintf(psql,"POLYGON((%d %d",val.sui_pos[i].x,val.sui_pos[i].y);
			}
			else
//			if(val.sui_type ==2 || sui_type ==3 || count < 3)
			{
				//return true;
				line_flg=2;
				sprintf(psql,"LINESTRING(%d %d",val.sui_pos[i].x,val.sui_pos[i].y);
			}

		}
		else
		{
			sprintf(psql,"%s,%d %d",psql,val.sui_pos[i].x,val.sui_pos[i].y);
			//strcat(psql,",%d %d",val.sui_pos[i].x,val.sui_pos[i].y);
		}
	}

	if ( val.cont_flg == 1)
	{
		con_flg =1;
		//��x������
		return true;
	}

	if ( val.cont_flg == 0)
	{
		if (line_flg==2 || line_flg==3)
		{
			strcat(psql,")");
		}
		else
		{
			strcat(psql,"))");
		}
//		con_flg =0;
//		line_flg=0;

	}
printf("%s\n",psql);
	// �p�����[�^�̐ݒ�
	const char* param[4] =
	{
		reinterpret_cast<char*>(&val.mesh_code),
		reinterpret_cast<char*>(&val.item_no),
		( strlen(psql) == 0 || (line_flg==2 || line_flg==3)  ? NULL : psql ),
		( strlen(psql) == 0 || (line_flg!=2 && line_flg!=3)  ? NULL : psql ),
	};

	//�p�����[�^��
	int paramLen[4] =
	{
		sizeof(val.mesh_code), sizeof(val.item_no), sizeof(psql), sizeof(psql)
	};
	//�p�����[�^�t�H�[�}�b�g
	int paramFmt[4] = {1, 1, 0,0};

	//SQL���s
	PGresult* res = PQexecPrepared(con, STMT_INSERT_WATER_POLY, 4, param, paramLen, paramFmt, 0);

	if( res == NULL || PQresultStatus(res) != PGRES_COMMAND_OK )
	{
		//Logger::write<Logger::ERROR>("MapDBWriter::%s : %s", __FUNCTION__, PQresultErrorMessage(res));
		if( res != NULL )	PQclear(res);
		return false;
	}

	commit();
	PQclear(res);

	if ( val.cont_flg == 0)
	{
		con_flg =0;
		line_flg=0;

	}


//	PQclear(res);

	return true;
}



bool DBSetting::setlinklength_adf()
{
	int ret = CONV_OTHER_ERROR;
    // SQL��
	char sql[5000];
	memset(sql,NULL,sizeof(sql));

	PGresult *res;

    // SQL���s
	sprintf(sql, UPDATE_LENGTH�QADF);
	res = PQexec(con,sql);
	int tes = PQresultStatus(res);

	if (PQresultStatus(res) != PGRES_COMMAND_OK) {
		// SQL�̎��s�Ɏ��s
		//fprintf(stderr,"%s",PQerrorMessage(con));
		printf("�f�[�^�̃����N���X�V�Ɏ��s���܂����B�e�[�u�����Fm_vicslink_adf�e�[�u��");
		goto fin;
	}

	PQclear(res);

	ret = CONV_SUCCESS;
fin:
    return ret;

}

int DBSetting::updatebeforefacildata_adf()
{
	int ret = -1;
    // SQL��
	char sql[5000];
	char *value;
    PGresult *res;
	int cnt_s=0;
    // SQL���s
	sprintf(sql, UPDATE_BEFORE_FACIL_ADF5);

	while(1)
	{
		res = PQexec(con,sql);
		int tes = PQresultStatus(res);
		if (PQresultStatus(res) != PGRES_COMMAND_OK) {
			// SQL�̎��s�Ɏ��s
			//fprintf(stderr,"%s",PQerrorMessage(con));
			printf("�f�[�^�̃����N���X�V�Ɏ��s���܂����B�e�[�u�����Fm_vicslink_adf�e�[�u��");
			goto fin;
		}


		value=PQcmdTuples(res);
		int rows=atoi(value);
		commit();

		PQclear(res);

printf("�O�{�ݐݒ� %d\r\n",rows);
		if(rows==0)
			break;


		cnt_s++;

	}

	ret = CONV_SUCCESS;

	if(cnt_s ==0)
	{
		ret=1;
	}
fin:
    return ret;

}

int DBSetting::updateafterfacildata_adf()
{
	int ret = -1;
    // SQL��
	char sql[5000];
	char *value;
    PGresult *res;
	int cnt_s=0;

    // SQL���s
	sprintf(sql, UPDATE_AFTER_FACIL_ADF5);

	while(1)
	{
		res = PQexec(con,sql);
		if (PQresultStatus(res) != PGRES_COMMAND_OK) {
			// SQL�̎��s�Ɏ��s
			//fprintf(stderr,"%s",PQerrorMessage(con));
			printf("�f�[�^�̃����N���X�V�Ɏ��s���܂����B�e�[�u�����Fm_vicslink_adf�e�[�u��");
			goto fin;
		}


		value=PQcmdTuples(res);
		int rows=atoi(value);
		commit();
		PQclear(res);
printf("��{�ݐݒ� %d\r\n",rows);

		if(rows==0)
			break;

		cnt_s++;
	}

	ret = CONV_SUCCESS;

	if(cnt_s ==0)
	{
		ret=1;
	}
fin:
    return ret;

}

int DBSetting::update_linkdata_node_adf()
{
	int ret = -1;

	char sql1[5000];
	char sql2[5000];
	char sql3[5000];
	char sql4[5000];
	char *value;
    PGresult *res;

	bool flg_s1=false;
	bool flg_s2=false;
	bool flg_s3=false;
	bool flg_s4=false;

	int cnt_s1=0;
	int cnt_s2=0;
	int cnt_s3=0;
	int cnt_s4=0;

	sprintf(sql1, UPDATE_NODE_CROSS);
	sprintf(sql2, UPDATE_NODE_CROSS_2);
	sprintf(sql3, UPDATE_NODE_TAIL);
	sprintf(sql4, UPDATE_NODE_HEAD);
	
	while(1)
	{

		flg_s1=false;
		flg_s2=false;
		flg_s3=false;
		flg_s4=false;

		cnt_s1=0;
		cnt_s2=0;
		cnt_s3=0;
		cnt_s4=0;

		while(1)
		{
			res = PQexec(con,sql1);
			if (PQresultStatus(res) != PGRES_COMMAND_OK) {
				// SQL�̎��s�Ɏ��s
				//fprintf(stderr,"%s",PQerrorMessage(con));
				printf("���ꃊ���N�Ԓ���1�Ɏ��s���܂����B�e�[�u�����Fm_vicslink_adf�e�[�u��");
				goto fin;
			}
			value=PQcmdTuples(res);
			int rows=atoi(value);
			commit();
			PQclear(res);
			printf("���ꃊ���N������1 %d\r\n",rows);

			if(rows==0)
			{
				if(cnt_s1==0)
				{
					flg_s1=true;
				}
				break;
			}
			cnt_s1++;
		}

		while(1)
		{
			res = PQexec(con,sql2);
			if (PQresultStatus(res) != PGRES_COMMAND_OK) {
				// SQL�̎��s�Ɏ��s
				//fprintf(stderr,"%s",PQerrorMessage(con));
				printf("���ꃊ���N�Ԓ���2�Ɏ��s���܂����B�e�[�u�����Fm_vicslink_adf�e�[�u��");
				goto fin;
			}
			value=PQcmdTuples(res);
			int rows=atoi(value);
			commit();
			PQclear(res);
			printf("���ꃊ���N������2 %d\r\n",rows);

			if(rows==0)
			{
				if(cnt_s2==0)
				{
					flg_s2=true;
				}
				break;
			}
			cnt_s2++;
		}
		while(1)
		{
			res = PQexec(con,sql3);
			if (PQresultStatus(res) != PGRES_COMMAND_OK) {
				// SQL�̎��s�Ɏ��s
				//fprintf(stderr,"%s",PQerrorMessage(con));
				printf("���ꃊ���N�Ԓ���3�Ɏ��s���܂����B�e�[�u�����Fm_vicslink_adf�e�[�u��");
				goto fin;
			}
			value=PQcmdTuples(res);
			int rows=atoi(value);
			commit();
			PQclear(res);
			printf("���ꃊ���N������3 %d\r\n",rows);

			if(rows==0)
			{
				if(cnt_s3==0)
				{
					flg_s3=true;
				}
				break;
			}
			cnt_s3++;
		}
		while(1)
		{
			res = PQexec(con,sql4);
			if (PQresultStatus(res) != PGRES_COMMAND_OK) {
				// SQL�̎��s�Ɏ��s
				//fprintf(stderr,"%s",PQerrorMessage(con));
				printf("���ꃊ���N�Ԓ���4�Ɏ��s���܂����B�e�[�u�����Fm_vicslink_adf�e�[�u��");
				goto fin;
			}
			value=PQcmdTuples(res);
			int rows=atoi(value);
			commit();
			PQclear(res);
			printf("���ꃊ���N������4 %d\r\n",rows);

			if(rows==0)
			{
				if(cnt_s4==0)
				{
					flg_s4=true;
				}
				break;
			}
			cnt_s4++;
		}

		if(	flg_s1==true && flg_s2==true && flg_s3==true && flg_s4==true)
		{
			break;
		}
	}

	ret = CONV_SUCCESS;

	//�����X�V���Ȃ������ꍇ
	if( cnt_s1==0 && cnt_s2==0 && cnt_s3==0 && cnt_s4==0)
	{
		ret  = 1;
	}


fin:
	return ret;
}



#define NUM_OF_LINE_CHARS 100
//SJIS�������UTF-8�ɕϊ�
int DBSetting::ConvertSJIStoUTF8(char* s,char* d)
{
	wchar_t wszBuf[NUM_OF_LINE_CHARS];

	// SJIS �� Unicode
	if(MultiByteToWideChar(
          CP_ACP,
          0,
          (const char *)s,
          -1,
          wszBuf,
          NUM_OF_LINE_CHARS) == 0)
        {
            printf_s(
              "%S:�ϊ��G���[(MultiByteToWideChar)\n",
              s);
            return -1;
        }


        // Unicode �� UTF8
        if(WideCharToMultiByte(
             CP_UTF8,
             0,
             wszBuf,
             -1,
             d,
             NUM_OF_LINE_CHARS,
             NULL,
             NULL) == 0)
        {
            printf_s(
              "%S:�ϊ��G���[(WideCharToMultiByte)\n",
              s);
            return -1;
        }


	return 0;
}


bool DBSetting::set_adf_zero1()
{
	int ret = CONV_OTHER_ERROR;
    // SQL��
	char sql[5000];
	memset(sql,NULL,sizeof(sql));

	PGresult *res;

    // SQL���s
	sprintf(sql, UPDATE_ZERO_SET1);
	res = PQexec(con,sql);
	int tes = PQresultStatus(res);

	if (PQresultStatus(res) != PGRES_COMMAND_OK) {
		// SQL�̎��s�Ɏ��s
		//fprintf(stderr,"%s",PQerrorMessage(con));
		printf("ADF�f�[�^�̎{�ݎn�[0�Z�b�g�Ɏ��s���܂����B�e�[�u�����Fm_vicslink_adf�e�[�u��");
		goto fin;
	}

	PQclear(res);

	ret = CONV_SUCCESS;
fin:
    return ret;

}

bool DBSetting::set_adf_zero2()
{
	int ret = CONV_OTHER_ERROR;
    // SQL��
	char sql[5000];
	memset(sql,NULL,sizeof(sql));

	PGresult *res;

    // SQL���s
	sprintf(sql, UPDATE_ZERO_SET2);
	res = PQexec(con,sql);
	int tes = PQresultStatus(res);

	if (PQresultStatus(res) != PGRES_COMMAND_OK) {
		// SQL�̎��s�Ɏ��s
		//fprintf(stderr,"%s",PQerrorMessage(con));
		printf("ADF�f�[�^�̎{�ݎn�[0�Z�b�g�Ɏ��s���܂����B�e�[�u�����Fm_vicslink_adf�e�[�u��");
		goto fin;
	}

	PQclear(res);

	ret = CONV_SUCCESS;
fin:
    return ret;

}
//bool DBSetting::setlinklength();
//bool DBSetting::updatefacildata();